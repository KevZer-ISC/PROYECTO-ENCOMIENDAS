USE [master]
GO
/****** Object:  Database [BDSeguridad]    Script Date: 02/08/2024 12:30:25 ******/
CREATE DATABASE [BDSeguridad]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'BDSeguridad', FILENAME = N'/var/opt/mssql/data/BDSeguridad.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'BDSeguridad_log', FILENAME = N'/var/opt/mssql/data/BDSeguridad_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [BDSeguridad] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [BDSeguridad].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [BDSeguridad] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [BDSeguridad] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [BDSeguridad] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [BDSeguridad] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [BDSeguridad] SET ARITHABORT OFF 
GO
ALTER DATABASE [BDSeguridad] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [BDSeguridad] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [BDSeguridad] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [BDSeguridad] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [BDSeguridad] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [BDSeguridad] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [BDSeguridad] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [BDSeguridad] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [BDSeguridad] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [BDSeguridad] SET  DISABLE_BROKER 
GO
ALTER DATABASE [BDSeguridad] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [BDSeguridad] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [BDSeguridad] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [BDSeguridad] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [BDSeguridad] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [BDSeguridad] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [BDSeguridad] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [BDSeguridad] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [BDSeguridad] SET  MULTI_USER 
GO
ALTER DATABASE [BDSeguridad] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [BDSeguridad] SET DB_CHAINING OFF 
GO
ALTER DATABASE [BDSeguridad] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [BDSeguridad] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [BDSeguridad] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [BDSeguridad] SET QUERY_STORE = OFF
GO
USE [BDSeguridad]
GO

/****** Object:  Table [dbo].[agencia]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[agencia](
	[IdAgencia] [int] IDENTITY(1,1) NOT NULL,
	[NombreAgencia] [varchar](50) NULL,
	[DireccionAgencia] [varchar](500) NULL,
	[HorarioInicio] [varchar](20) NULL,
	[HorarioTermino] [varchar](50) NULL,
	[FK_EstadoAgencia] [int] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_agencia] PRIMARY KEY CLUSTERED 
(
	[IdAgencia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AgenciaTipoComprobante]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AgenciaTipoComprobante](
	[IdAgenciaComprobante] [int] IDENTITY(1,1) NOT NULL,
	[IdAgencia] [int] NULL,
	[IdTipoComprobante] [int] NULL,
	[Serie] [varchar](6) NULL,
	[Correlativo] [bigint] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_AgenciaTipoComprobante] PRIMARY KEY CLUSTERED 
(
	[IdAgenciaComprobante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[chofer]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[chofer](
	[ID_Chofer] [int] IDENTITY(1,1) NOT NULL,
	[FK_Trabajador] [int] NOT NULL,
	[NumeroLicenciaConducir] [varchar](10) NOT NULL,
	[FechaExpiracionLicencia] [datetime] NOT NULL,
	[TipoLicencia] [varchar](20) NOT NULL,
	[Estado] [varchar](10) NOT NULL,
	[Horario] [date] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_chofer] PRIMARY KEY CLUSTERED 
(
	[ID_Chofer] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[cliente]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[cliente](
	[IdCliente] [int] IDENTITY(1,1) NOT NULL,
	[FK_Departamento] [int] NULL,
	[FK_TipoDocumento] [int] NULL,
	[FK_Sucursal] [int] NULL,
	[Documento] [varchar](15) NULL,
	[Nombres] [varchar](60) NULL,
	[Apellidos] [varchar](60) NULL,
	[NombreCompleto] [varchar](120) NULL,
	[Direccion] [varchar](120) NULL,
	[Ubigeo] [varchar](8) NULL,
	[Telefono] [varchar](15) NULL,
	[Correo] [varchar](120) NULL,
	[Contacto] [varchar](500) NULL,
	[Credito] [bit] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_cliente] PRIMARY KEY CLUSTERED 
(
	[IdCliente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClienteContacto]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClienteContacto](
	[IdClienteContacto] [bigint] IDENTITY(1,1) NOT NULL,
	[IdCliente] [int] NULL,
	[NumeroDocumento] [varchar](20) NULL,
	[NombreContacto] [varchar](500) NULL,
	[TelefonoContacto] [varchar](20) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_ClienteContacto] PRIMARY KEY CLUSTERED 
(
	[IdClienteContacto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClienteDireccion]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClienteDireccion](
	[IdClienteDireccion] [bigint] IDENTITY(1,1) NOT NULL,
	[IdCliente] [int] NULL,
	[Direccion] [varchar](500) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_ClienteDireccion] PRIMARY KEY CLUSTERED 
(
	[IdClienteDireccion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClienteNoDeseado]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClienteNoDeseado](
	[IdClienteNoDeseado] [int] IDENTITY(1,1) NOT NULL,
	[IdTipoDocumento] [int] NULL,
	[NumeroDocumento] [varchar](20) NULL,
	[NombreCompleto] [varchar](500) NULL,
	[Observacion] [varchar](max) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED 
(
	[IdClienteNoDeseado] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[comprobante]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[comprobante](
	[Id_Comprobante] [int] IDENTITY(1,1) NOT NULL,
	[FK_Orden] [int] NOT NULL,
	[FK_Cajero] [int] NOT NULL,
	[FechaRegistro] [datetime] NOT NULL,
	[Serie] [varchar](14) NOT NULL,
	[Numero] [varchar](14) NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_comprobante] PRIMARY KEY CLUSTERED 
(
	[Id_Comprobante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Departamento]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Departamento](
	[IdDepartamento] [int] IDENTITY(1,1) NOT NULL,
	[NombreDepartamento] [varchar](500) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_Departamento] PRIMARY KEY CLUSTERED 
(
	[IdDepartamento] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[detallepago]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[detallepago](
	[id_DetallePago] [int] NOT NULL,
	[PK_OrdeServicio] [int] NOT NULL,
	[PK_Comprobante] [int] NOT NULL,
	[FechaPago] [datetime] NOT NULL,
	[TipoPago] [int] NOT NULL,
	[TipoTarjeta] [int] NOT NULL,
	[MontoPagado] [int] NOT NULL,
	[Lote] [varchar](4) NULL,
	[Digito] [varchar](4) NULL,
	[Referencia] [varchar](20) NULL,
	[Monto] [real] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[documento_referencia]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[documento_referencia](
	[idDocumento_Referencia] [int] NOT NULL,
	[Descripcion_DocumentoReferencia] [varchar](45) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_documento_referencia] PRIMARY KEY CLUSTERED 
(
	[idDocumento_Referencia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[embarque]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[embarque](
	[id_Embarque] [int] IDENTITY(1,1) NOT NULL,
	[FK_Orden] [int] NOT NULL,
	[FK_Usuario] [int] NOT NULL,
	[FechaRegistro] [datetime] NOT NULL,
	[Ruta_Origen] [int] NOT NULL,
	[Ruta_Destino] [int] NOT NULL,
	[FK_TipoProgramacion] [smallint] NOT NULL,
	[FK_Programacion] [int] NOT NULL,
	[FK_Estado_Embarque] [smallint] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_embarque] PRIMARY KEY CLUSTERED 
(
	[id_Embarque] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormaPago]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormaPago](
	[IdFormaPago] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionFormaPago] [varchar](250) NULL,
	[RemitenteJuridico] [bit] NULL,
	[ConsignadoJuridico] [bit] NULL,
	[RemitenteNatural] [bit] NULL,
	[ConsignadoNatural] [bit] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_FormaPago] PRIMARY KEY CLUSTERED 
(
	[IdFormaPago] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[menu]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[menu](
	[IdMenu] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar](500) NOT NULL,
	[Ruta] [varchar](500) NULL,
	[IdPadre] [int] NULL,
	[Icono] [varchar](500) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_menu] PRIMARY KEY CLUSTERED 
(
	[IdMenu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[nota_credito]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[nota_credito](
	[idNotaCredito] [int] IDENTITY(1,1) NOT NULL,
	[FK_Orden] [int] NOT NULL,
	[FK_Usuario] [int] NOT NULL,
	[FechaRegistro] [datetime] NOT NULL,
	[Serie] [varchar](15) NOT NULL,
	[NumeroOrden] [varchar](15) NOT NULL,
	[FK_comprobante] [int] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_nota_credito] PRIMARY KEY CLUSTERED 
(
	[idNotaCredito] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ordenservicio]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ordenservicio](
	[Id_Orden] [int] IDENTITY(1,1) NOT NULL,
	[Serie] [varchar](6) NULL,
	[Correlativo] [varchar](10) NULL,
	[IdOrigen] [int] NOT NULL,
	[IdDestino] [int] NOT NULL,
	[IdTipoServicio] [int] NOT NULL,
	[IdTipoRecepcion] [int] NULL,
	[IdTipoEntrega] [int] NOT NULL,
	[IdRemitente] [int] NULL,
	[IdDestinatario] [int] NOT NULL,
	[PersonaContacto] [bit] NOT NULL,
	[IdPersonaContacto] [int] NOT NULL,
	[DireccionRecepcion] [varchar](500) NULL,
	[DireccionEntrega] [varchar](500) NOT NULL,
	[IdFormaPago] [int] NOT NULL,
	[IdResponsablePago] [int] NULL,
	[TotalUnidades] [decimal](18, 3) NULL,
	[TotalPeso] [decimal](18, 3) NULL,
	[TotalBulto] [decimal](18, 3) NULL,
	[TotalVolumen] [decimal](18, 3) NULL,
	[TotalDescuento] [decimal](18, 3) NOT NULL,
	[TotalImporte] [decimal](18, 3) NOT NULL,
	[IGV] [decimal](18, 3) NULL,
	[SubTotal] [decimal](18, 3) NULL,
	[FechaOrden] [datetime] NULL,
	[IdUsuario] [int] NULL,
	[IdEstado] [int] NULL,
	[Anulado] [bit] NULL,
	[FechaAnulacion] [datetime] NULL,
	[IdUsuarioAnula] [int] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_ordenservicio] PRIMARY KEY CLUSTERED 
(
	[Id_Orden] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ordenservicio_item]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ordenservicio_item](
	[id_Item] [int] NOT NULL,
	[FK_OrdenServicio] [int] NOT NULL,
	[FK_TipoServicio] [int] NOT NULL,
	[Descripcion] [varchar](200) NOT NULL,
	[Unidad] [varchar](10) NULL,
	[Numero] [int] NULL,
	[Peso] [float] NULL,
	[Factor] [float] NULL,
	[PrecioUnitario] [float] NOT NULL,
	[PrecioTotal] [float] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NOT NULL,
	[FechaCreacion] [datetime] NOT NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_ordenservicio_item] PRIMARY KEY CLUSTERED 
(
	[id_Item] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ordenservicioconsignado]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ordenservicioconsignado](
	[FK_OrdenServicio] [int] NOT NULL,
	[FK_Consignado] [int] NOT NULL,
	[FechaRegistro] [datetime] NOT NULL,
	[FK_Usuario] [int] NOT NULL,
	[Estado_Baja] [bit] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[perfil]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[perfil](
	[IdPerfil] [int] IDENTITY(1,1) NOT NULL,
	[NombrePerfil] [varchar](100) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_perfil] PRIMARY KEY CLUSTERED 
(
	[IdPerfil] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[perfil_menu_rol]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[perfil_menu_rol](
	[IdMenu] [int] NOT NULL,
	[IdPerfil] [int] NOT NULL,
	[IdsRol] [varchar](100) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[programacion]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[programacion](
	[Id_Programacion] [int] IDENTITY(1,1) NOT NULL,
	[Fecha_Registro] [datetime] NOT NULL,
	[FK_Usuario] [int] NOT NULL,
	[FK_TipoProgramacion] [smallint] NOT NULL,
	[FK_Origen] [int] NOT NULL,
	[FK_Destino] [int] NOT NULL,
	[FechaViaje] [datetime] NOT NULL,
	[FK_Trayectoria] [int] NOT NULL,
	[FK_Piloto] [int] NOT NULL,
	[FK_Copiloto] [int] NULL,
	[FK_Vehiculo] [int] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_programacion] PRIMARY KEY CLUSTERED 
(
	[Id_Programacion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[rol]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[rol](
	[IdRol] [int] IDENTITY(1,1) NOT NULL,
	[Rol] [varchar](100) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_rol] PRIMARY KEY CLUSTERED 
(
	[IdRol] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoComprobante]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoComprobante](
	[IdTipoComprobante] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionTipoComprobante] [varchar](500) NULL,
	[CodSunat] [varchar](4) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_TipoComprobante] PRIMARY KEY CLUSTERED 
(
	[IdTipoComprobante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoDocumento]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoDocumento](
	[idTipoDocumento] [int] NOT NULL,
	[Descripcion_TipoDocumento] [varchar](50) NOT NULL,
	[Tipo] [char](1) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_tipodocumento] PRIMARY KEY CLUSTERED 
(
	[idTipoDocumento] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoEntrega]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoEntrega](
	[IdTipoEntrega] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionTipoEntrega] [varchar](250) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_TipoEntrega] PRIMARY KEY CLUSTERED 
(
	[IdTipoEntrega] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoPago]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoPago](
	[IdTipoPago] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionTipoPago] [varchar](250) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_TipoPago] PRIMARY KEY CLUSTERED 
(
	[IdTipoPago] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoServicio]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoServicio](
	[IdTipoServicio] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionTipoServicio] [varchar](250) NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_TipoServicio] PRIMARY KEY CLUSTERED 
(
	[IdTipoServicio] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tipovehiculo]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tipovehiculo](
	[Id_TipoVehiculo] [smallint] IDENTITY(1,1) NOT NULL,
	[ConsumoCombustible] [varchar](15) NOT NULL,
	[Descripcion] [varchar](25) NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_tipovehiculo] PRIMARY KEY CLUSTERED 
(
	[Id_TipoVehiculo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[trabajador]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[trabajador](
	[IdTrabajador] [int] IDENTITY(1,1) NOT NULL,
	[Nombre_Completo] [varchar](150) NOT NULL,
	[Genero] [varchar](14) NOT NULL,
	[Estado] [int] NOT NULL,
	[TipoDocumento] [smallint] NOT NULL,
	[DocumentoIdentidad] [varchar](20) NOT NULL,
	[Clave] [varchar](50) NOT NULL,
	[FechaContratacion] [datetime] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_trabajador] PRIMARY KEY CLUSTERED 
(
	[IdTrabajador] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trayectoria]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trayectoria](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar](100) NOT NULL,
	[FK_Origen] [int] NOT NULL,
	[FK_Destino] [int] NOT NULL,
	[TotalTiempoAcumulado] [int] NOT NULL,
	[TotalOficinas] [int] NOT NULL,
	[Orientacion_Id] [tinyint] NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_Desplasamiento] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trayectoria_Detalle]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trayectoria_Detalle](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Trayectoria_Id] [int] NOT NULL,
	[Orden] [int] NOT NULL,
	[PasaPor_IdSucursalVenta] [int] NOT NULL,
	[TiempoLlegadaMinutos] [int] NULL,
	[TiempoEstibaDesestibaMinutos] [int] NULL,
	[TotalTiempoAcumulado] [int] NULL,
	[TrayectoriaTipo_Id] [smallint] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [PK_Trayectoria_Detalle] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[usuario]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[usuario](
	[IdUsuario] [int] IDENTITY(1,1) NOT NULL,
	[FK_Trabajador] [int] NOT NULL,
	[FK_Agencia] [int] NOT NULL,
	[Fk_Perfil] [int] NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_usuario] PRIMARY KEY CLUSTERED 
(
	[IdUsuario] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[vehiculo]    Script Date: 02/08/2024 12:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[vehiculo](
	[Id_Vehiculo] [int] IDENTITY(1,1) NOT NULL,
	[FK_VehiculoTipo] [smallint] NOT NULL,
	[FK_Usuario] [int] NOT NULL,
	[Fecha_Registro] [datetime] NOT NULL,
	[ejes] [int] NOT NULL,
	[Fecha_Inscripción] [int] NOT NULL,
	[Placa] [varchar](10) NOT NULL,
	[Serie_Vehiculo] [varchar](40) NOT NULL,
	[Marca] [varchar](50) NOT NULL,
	[Modelo] [varchar](50) NOT NULL,
	[Estado] [varchar](10) NOT NULL,
	[id_Estado_Vehiculo] [smallint] NOT NULL,
	[FK_Chofer] [int] NOT NULL,
	[Serie_Motor] [varchar](50) NOT NULL,
	[Activo] [bit] NULL,
	[UsuarioCreacion] [int] NULL,
	[FechaCreacion] [datetime] NULL,
	[UsuarioUltimaModificacion] [int] NULL,
	[FechaUltimaModificacion] [datetime] NULL,
 CONSTRAINT [pk_vehiculo] PRIMARY KEY CLUSTERED 
(
	[Id_Vehiculo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 99) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[agencia] ON 
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Lima', NULL, N'06:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Renovación', NULL, N'06:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Los Olivos', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Nuevo Chimbote', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Chimbote', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Chao', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, N'Trujillo', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, N'Chepen', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, N'Chiclayo', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, N'Piura', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, N'Sullana', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (12, N'Huamachuco', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (13, N'Cajabamba', NULL, N'08:00 a.m.', N'10:00 p.m.', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (14, N'prueba', N'prueba', N'10:00', N'20:00', 1, 1, 0, CAST(N'2024-06-18T20:05:27.667' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[agencia] ([IdAgencia], [NombreAgencia], [DireccionAgencia], [HorarioInicio], [HorarioTermino], [FK_EstadoAgencia], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (15, N'prueba', N'prueba', N'10:00', N'20:00', 1, 1, 11, CAST(N'2024-06-18T20:28:20.357' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[agencia] OFF
GO
SET IDENTITY_INSERT [dbo].[AgenciaTipoComprobante] ON 
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, 1, 1, N'BE01', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 1, 2, N'FE01', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 1, 3, N'OS01', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, 2, 1, N'BE02', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, 2, 2, N'FE02', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, 2, 3, N'OS02', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, 3, 1, N'BE03', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, 3, 2, N'FE03', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, 3, 3, N'OS03', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, 4, 1, N'BE04', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, 4, 2, N'FE04', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (12, 4, 3, N'OS04', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (13, 5, 1, N'BE05', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (14, 5, 2, N'FE05', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (15, 5, 3, N'OS05', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (16, 6, 1, N'BE06', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (17, 6, 2, N'FE06', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (18, 6, 3, N'OS06', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (19, 7, 1, N'BE07', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (20, 7, 2, N'FE07', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (21, 7, 3, N'OS07', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (22, 8, 1, N'BE08', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (23, 8, 2, N'FE08', 1, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[AgenciaTipoComprobante] ([IdAgenciaComprobante], [IdAgencia], [IdTipoComprobante], [Serie], [Correlativo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (24, 8, 3, N'OS08', 1, NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[AgenciaTipoComprobante] OFF
GO
SET IDENTITY_INSERT [dbo].[cliente] ON 
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (30, 1, 1, 1, N'73617110', N'Harry', N'Ore Lara', N'Harry Ore Lara', N'Trujillo', N'ABVDD', N'931070632', N'harry@gmail.com', N'Harry', NULL, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (31, 1, 1, 0, N'78451225', N'Jenifer', N'Castillo', N'Jenifer Castillo', N'Trujillo', N'XYZ', N'952150634', N'jenni@gmail.com', N'Jenni', NULL, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (36, 15, 1, 0, N'12345678', N'Juan', N'Perez', N'Perez Corp', N'Av. Larco 123', N'150101', N'987654321', N'juan.perez@example.com', N'Juan Perez', NULL, 1, 11, CAST(N'2024-06-19T21:22:24.410' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (41, 1, 1, 0, N'12345679', N'Juan', N'Perez', N'Perez Corp', N'Actualiznado a perez', N'150101', N'987654321', N'juan.perez@example.com', NULL, 0, 0, 11, CAST(N'2024-06-19T22:57:45.900' AS DateTime), 12, CAST(N'2024-07-16T10:01:11.170' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (42, 0, 0, 0, N'string', N'string', N'string', N'string', N'string', N'string', N'string', N'string', N'string', NULL, 1, 11, CAST(N'2024-06-24T15:01:17.443' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (44, 2, 2, 0, N'31231231231', N'', N'', N'Peruvian SAC', N'28 de Julio', N'WE51', N'952514252', N'peruvian@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:04:26.230' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (45, 1, 2, 0, N'32423423433', N'', N'', N'Babel SAC', N'Laredo', N'ER1515', N'945152515', N'babel@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (46, 1, 1, 0, N'36252522', N'Liam', N'Ore Lara', N'Liam Ore Lara', N'El Porvenir', N'ASD152', N'931515152', N'liam@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:13:01.587' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (47, 3, 3, 0, N'1212121212', N'Sandra', N'Guevara Rojas', N'Sandra Guevara Rojas', N'Av Argentina', N'ASD5151', N'951536515', N'sandra@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:18:16.773' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (48, 2, 3, 0, N'15515155411', N'Sergio', N'Paredes', N'Sergio Paredes', N'Av Peru', N'ASD5151', N'951525120', N'sergio@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:19:42.580' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (49, 1, 1, 0, N'23223232', N'Dante', N'Pelaez', N'Dante Pelaez', N'Florencia', N'ASD25', N'951152632', N'dante@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:23:47.310' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (50, 1, 1, 0, N'45656556', N'Dante', N'Pelaez', N'Dante Pelaez', N'Florencia', N'ASD25', N'951152632', N'dante@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:46:08.507' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (51, 1, 1, 0, N'41414141', N'Deck', N'Ore', N'Deck Ore', N'Trujillo', N'asd51', N'931070632', N'deck@4gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:50:45.330' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (52, 1, 1, 0, N'56565656', N'Jack', N'Ore Lara', N'Jack Ore Lara', N'Trujillo', N'ASD521', N'951524152', N'jack@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:52:02.430' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (53, 1, 1, 0, N'56262622', N'Juan', N'Ore', N'Juan Ore', N'Trujillo', N'LHJH41', N'945262626', N'juan@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:53:25.360' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (54, 1, 1, 0, N'34343434', N'Maria', N'Sanchez', N'Maria Sanchez', N'Sauces', N'FDF25', N'925152563', N'maria@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:56:10.357' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (55, 1, 1, 0, N'85858585', N'Dane', N'Ponce', N'Dane Ponce', N'Trujillo', N'IKD25', N'978451365', N'dane@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T20:59:32.080' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (56, 2, 2, 0, N'79659595959', N'', N'', N'Termx', N'Miraflores', N'SDSD45', N'945451515', N'termx@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:04:32.207' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (57, 1, 1, 0, N'74415812', N'Sandra', N'Siccha', N'Sandra Siccha', N'Florencia', N'SDSD452', N'962151251', N'sandra@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:08:42.823' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (58, 2, 1, 0, N'52525478', N'Melva', N'Molina', N'Melva Molina', N'Miraflores', N'SDFS1', N'945812656', N'melva@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:09:42.453' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (59, 1, 1, 0, N'58526210', N'Deckard', N'Ore Lara', N'Deckard Ore Lara', N'Trujillo', N'151AS', N'951526354', N'deckard@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:40:10.773' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (60, 2, 2, 0, N'12345815264', N'', N'', N'BairesDev', N'Miraflores', N'SDSD25', N'925142635', N'bairesdev@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:43:04.400' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (61, 1, 3, 0, N'78456262', N'Pedro', N'Garcia', N'Pedro Garcia', N'Av Larco', N'5215', N'952415256', N'pedrito@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T21:43:55.237' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (62, 1, 1, 0, N'46521551', N'Ethan', N'Lujan', N'Ethan Lujan', N'Florencia', N'1515', N'955151525', N'ethan@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T22:29:29.623' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (63, 1, 1, 0, N'25107000', N'Johan', N'Capristan Diaz', N'Johan Capristan Diaz', N'La Esperanza', N'1515', N'931515205', N'johan@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T22:47:31.443' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (64, 2, 2, 0, N'15152151515', NULL, NULL, N'CMH', N'Miraflores', N'58218', N'945151262', N'cmh@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (65, 1, 3, 0, N'56262512', N'Dazzle', N'Fernan', N'Dazzle Fernan', N'Trujillo', N'25898', N'945162102', N'dazzle@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (66, 1, 2, 0, N'45151515151', N'', N'', N'Itsa', N'Trujillo', N'45156', N'925251230', N'itsa@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-25T20:24:49.050' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (67, 1, 2, 0, N'60230540374', N'', N'', N'America', N'Moche', N'151A', N'925210212', N'america@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-25T20:52:46.457' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (68, 1, 2, 0, N'45682210420', N'', N'', N'Dorado', N'Trujillo', N'515ASD', N'922554126', N'dorado@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-25T21:03:22.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (69, 1, 2, 0, N'46000036521', N'', N'', N'Civa la Empresa Actualizada', N'Lima', N'15AS', N'925152315', N'civa@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-06-25T21:06:39.443' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (70, 1, 1, 0, N'73617112', N'Pedro', N'Cares', N'Pedro Cares', N'Lima', N'15asd', N'952152051', N'pedro@gmail.cim', NULL, NULL, 1, 12, CAST(N'2024-07-03T22:35:42.203' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (71, 1, 1, 0, N'45251325', N'Adrian', N'Perez Barrera', N'Adrian Perez Barrera', N'Trujillo', N'15AS', N'952141515', N'adrian@gmail.com', NULL, NULL, 1, 12, CAST(N'2024-07-05T23:04:56.153' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (72, 1, 2, 0, N'65151111111', N'', N'', N'Flores Transportes Con Message 2', N'Trujillo', N'ASD15', N'955151511', N'flores@gmail.com', NULL, 1, 1, 12, CAST(N'2024-07-08T21:47:57.413' AS DateTime), 12, CAST(N'2024-07-09T15:45:29.120' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (75, NULL, 1, NULL, N'44050058', N'FRANCISCO ANTONIO', N'VILCHEZ QUISPE', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 11, CAST(N'2024-07-11T18:19:01.323' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (76, NULL, NULL, NULL, N'44050058', N'FRANCISCO ANTONIO', N'VILCHEZ QUISPE', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 11, CAST(N'2024-07-11T18:21:49.503' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (77, NULL, 2, NULL, N'20133605291', NULL, NULL, N'EMPRESA DE TRANSPORTES AVE FENIX S.A.C.', N'AV. TUPAC AMARU NRO 185 URB. HUERTA GRANDE ', NULL, NULL, NULL, NULL, 0, 0, 11, CAST(N'2024-07-11T18:34:15.770' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (78, NULL, 1, NULL, N'73617111', N'ESTEFANY BRIGGIET', N'BOCANEGRA GOMEZ', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-13T10:09:57.067' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (79, NULL, 1, NULL, N'55555555', N'', N' ', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-13T10:13:42.570' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (80, NULL, 1, NULL, N'73617100', N'NAYELY ROSARIO', N'RODRIGUEZ LARA', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T11:44:05.390' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (81, NULL, 1, NULL, N'71521500', N'DEIVID JHORDAN', N'QUISPE HUARACCALLO', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T11:44:29.863' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (82, NULL, 1, NULL, N'11111111', N'', N' ', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T11:44:48.347' AS DateTime), 12, CAST(N'2024-07-15T17:50:15.563' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (83, NULL, 1, NULL, N'73617114', N'NIXI DENISSE', N'GARCIA RAMOS', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T11:45:53.463' AS DateTime), 12, CAST(N'2024-07-15T17:50:10.767' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (84, NULL, 1, NULL, N'73617120', N'KAREN BEATRIZ', N'COSME BERROSPI', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T11:46:01.353' AS DateTime), 12, CAST(N'2024-07-15T17:50:06.783' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (85, 1, 1, 0, N'71217120', N'KEINDER', N'MORENO COELLO', N'KEINDER MORENO COELLO', N'Keinder direcction', N'ASDS', N'9515121515', N'keinder@gmail.com', NULL, 0, 0, 12, CAST(N'2024-07-15T11:46:10.410' AS DateTime), 12, CAST(N'2024-07-16T10:03:09.010' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (86, NULL, 1, NULL, N'43425643', N'JUAN JOSE', N'ORE LESCANO', N'JUAN JOSE ORE LESCANO', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-15T11:49:39.757' AS DateTime), 12, CAST(N'2024-07-15T17:49:54.920' AS DateTime))
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (87, NULL, 1, NULL, N'73617150', N'CLEVER', N'MENDOZA MENDIETA', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T16:17:21.463' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (88, NULL, 1, NULL, N'73617160', N'XIOMARA MEDALEY', N'TARAZONA MORALES', N'XIOMARA MEDALEY TARAZONA MORALES', NULL, NULL, NULL, NULL, NULL, 0, 0, 12, CAST(N'2024-07-15T17:20:04.477' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (89, NULL, 1, NULL, N'73617160', N'XIOMARA MEDALEY', N'TARAZONA MORALES', N'XIOMARA MEDALEY TARAZONA MORALES', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T12:57:35.320' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (90, NULL, 1, NULL, N'73617180', N'AHINOR', N'CHURA HUARANCCA', N'AHINOR CHURA HUARANCCA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T12:57:41.613' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (91, NULL, 1, NULL, N'73617190', N'DAVID PELAYO', N'GALINDO RAMOS', N'DAVID PELAYO GALINDO RAMOS', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T12:59:10.467' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (92, NULL, 1, NULL, N'73617170', N'MARX CRISTIAN', N'CISNEROS TENORIO', N'MARX CRISTIAN CISNEROS TENORIO', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T12:59:47.400' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (93, NULL, 1, NULL, N'73617130', N'MARI MAR', N'ZUÑIGA BRAVO', N'MARI MAR ZUÑIGA BRAVO', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T13:03:09.590' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (94, NULL, 1, NULL, N'73617150', N'CLEVER', N'MENDOZA MENDIETA', N'CLEVER MENDOZA MENDIETA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T16:39:20.343' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (95, NULL, 1, NULL, N'73617950', N'REYNALDO JAIME', N'GUZMAN RAMOS', N'REYNALDO JAIME GUZMAN RAMOS', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T16:39:35.877' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (96, NULL, 1, NULL, N'73617650', N'JHAN CARLOS', N'PALOMINO LOA', N'JHAN CARLOS PALOMINO LOA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-16T16:39:38.400' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (97, 2, 2, 0, N'22100212010', N'', N'', N'Prueba para RUC', N'Lima', N'ASD41', N'922120210', N'prueba@gmail.com', NULL, 1, 1, 12, CAST(N'2024-07-16T17:27:15.657' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (98, NULL, 1, NULL, N'73617140', N'NATALY EUGENIA', N'LEON ALVAREZ', N'NATALY EUGENIA LEON ALVAREZ', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-17T12:40:00.023' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (99, NULL, 1, NULL, N'73617140', N'NATALY EUGENIA', N'LEON ALVAREZ', N'NATALY EUGENIA LEON ALVAREZ', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-17T12:40:00.160' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (100, 1, 1, 0, N'00002222', N'Test', N'testAp', N'Test testAp', N'Trujillo', N'ASd', N'932501200', N'test@gmail.com', NULL, 0, 1, 12, CAST(N'2024-07-17T12:50:12.923' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (101, 2, 1, 0, N'00003333', N'test2', N'testAp2', N'test2 testAp2', N'Miraflores', N'asd', N'952152005', N'test2@gmail.com', NULL, 0, 1, 12, CAST(N'2024-07-17T13:00:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (102, 3, 2, 0, N'00000444444', NULL, NULL, N'EMPRESA TEST ', N'America', N'ASWQQ', N'981500000', N'empresatest@gmail.com', NULL, 1, 1, 12, CAST(N'2024-07-17T13:01:31.017' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (103, 1, 1, 0, N'00005555', N'test3', N'test3App', N'test3 test3App', N'Otuzco', N'123', N'922200011', N'test3@gmail.com', NULL, 0, 1, 12, CAST(N'2024-07-17T14:24:41.287' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (104, 2, 2, 0, N'00000666666', NULL, NULL, N'Empresa Test 2', N'Miraflores', N'1212', N'900033322', N'empresatest2@gmail.com', NULL, 1, 1, 12, CAST(N'2024-07-17T14:33:01.167' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (105, NULL, 1, NULL, N'73617118', N'DEYFFER DAVID', N'MENDOZA LEYVA', N'DEYFFER DAVID MENDOZA LEYVA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T12:22:49.370' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (106, NULL, 1, NULL, N'73617122', N'ANDHERSON LENDHY', N'ARGANDOÑA HUAPALLA', N'ANDHERSON LENDHY ARGANDOÑA HUAPALLA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T12:23:03.263' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (107, NULL, 1, NULL, N'73617124', N'MAYFORI MAYLI', N'FLORES ALEJANDRO', N'MAYFORI MAYLI FLORES ALEJANDRO', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T12:29:05.597' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (108, NULL, 1, NULL, N'73617128', N'NIDIA CAROLINA', N'ALVARADO MARTEL', N'NIDIA CAROLINA ALVARADO MARTEL', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T12:33:43.410' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (109, NULL, 1, NULL, N'71050520', N'KATY', N'FLOREZ CERVANTES', N'KATY FLOREZ CERVANTES', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T12:36:08.530' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[cliente] ([IdCliente], [FK_Departamento], [FK_TipoDocumento], [FK_Sucursal], [Documento], [Nombres], [Apellidos], [NombreCompleto], [Direccion], [Ubigeo], [Telefono], [Correo], [Contacto], [Credito], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (110, NULL, 1, NULL, N'73617166', N'ERICK GABRIEL', N'SIERRALAYA SAAVEDRA', N'ERICK GABRIEL SIERRALAYA SAAVEDRA', NULL, NULL, NULL, NULL, NULL, 0, 1, 12, CAST(N'2024-07-30T15:26:56.687' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[cliente] OFF
GO
SET IDENTITY_INSERT [dbo].[ClienteContacto] ON 
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 41, N'44050058', N'francisco Vilchez', N'', 1, 11, CAST(N'2024-06-19T22:57:45.900' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 42, N'string', N'string', N'string', 1, 11, CAST(N'2024-06-24T15:01:17.443' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, 44, N'45251525', N'Pedro Lopez', N'952142563', 1, 12, CAST(N'2024-06-24T20:04:26.230' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, 45, N'45124512', N'Natalia Bravo', N'951524251', 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, 45, N'62515252', N'Alexander', N'962514251', 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, 64, N'25563001', N'Luis Calderon Bazan', N'952151526', 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, 64, N'36201002', N'Emely Incil', N'952415262', 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, 65, N'25563001', N'Luis Calderon Bazan', N'952151526', 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, 65, N'36201002', N'Emely Incil', N'952415262', 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, 66, N'55516326', N'Juan Esquivel', N'926151521', 1, 12, CAST(N'2024-06-25T20:24:49.050' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (12, 67, N'545151512', N'Luis Suarez', N'925202515', 1, 12, CAST(N'2024-06-25T20:52:46.457' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (13, 68, N'5225155', N'Pedro', N'921523154', 1, 12, CAST(N'2024-06-25T21:03:22.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (19, 69, N'451515', N'Pedro Lopez', N'951151241', 1, 12, CAST(N'2024-07-04T17:42:10.060' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (20, 72, N'Pedro', N'Flores Linares', N'952151511', 1, 12, CAST(N'2024-07-08T21:47:57.413' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (21, 102, N'965211125', N'Sonia Alcantara', N'936352511', 1, 12, CAST(N'2024-07-17T13:01:31.017' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteContacto] ([IdClienteContacto], [IdCliente], [NumeroDocumento], [NombreContacto], [TelefonoContacto], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (22, 104, N'45265251', N'Sandra Siccha', N'900021154', 1, 12, CAST(N'2024-07-17T14:33:01.167' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[ClienteContacto] OFF
GO
SET IDENTITY_INSERT [dbo].[ClienteDireccion] ON 
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, 36, N'pruebadirecion1', 1, 11, CAST(N'2024-06-19T21:22:24.410' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 36, N'pruebadirecion2', 1, 11, CAST(N'2024-06-19T21:22:24.410' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 36, N'pruebadirecion2', 1, 11, CAST(N'2024-06-19T21:22:24.410' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (16, 41, N'pruebadirecion1', 1, 11, CAST(N'2024-06-19T22:57:45.900' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (17, 41, N'pruebadirecion2', 1, 11, CAST(N'2024-06-19T22:57:45.900' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (18, 41, N'pruebadirecion2', 1, 11, CAST(N'2024-06-19T22:57:45.900' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (19, 42, N'string', 1, 11, CAST(N'2024-06-24T15:01:17.443' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (20, 44, N'Miraflores', 1, 12, CAST(N'2024-06-24T20:04:26.230' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (21, 44, N'San Isidro', 1, 12, CAST(N'2024-06-24T20:04:26.230' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (22, 45, N'Trujillo', 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (23, 45, N'Larco', 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (24, 45, N'Buenos Aires', 1, 12, CAST(N'2024-06-24T20:10:00.970' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (25, 64, N'Av Larco', 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (26, 64, N'Casuarinas', 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (27, 64, N'28 Julio', 1, 12, CAST(N'2024-06-24T22:49:40.290' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (28, 65, N'Av Larco', 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (29, 65, N'Casuarinas', 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (30, 65, N'28 Julio', 1, 12, CAST(N'2024-06-24T22:51:02.630' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (31, 66, N'Trujillo', 1, 12, CAST(N'2024-06-25T20:24:49.050' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (32, 66, N'Limaa', 1, 12, CAST(N'2024-06-25T20:24:49.050' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (33, 66, N'Chiclayo', 1, 12, CAST(N'2024-06-25T20:24:49.050' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (34, 67, N'Moche', 1, 12, CAST(N'2024-06-25T20:52:46.457' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (35, 67, N'Ov La Marina', 1, 12, CAST(N'2024-06-25T20:52:46.457' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (36, 68, N'Trujillo', 1, 12, CAST(N'2024-06-25T21:03:22.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (37, 68, N'Limaa', 1, 12, CAST(N'2024-06-25T21:03:22.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (38, 68, N'Piura', 1, 12, CAST(N'2024-06-25T21:03:22.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (44, 60, N'Desde Postman actualizando', 1, 11, CAST(N'2024-07-03T16:36:46.800' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (80, 69, N'Lima probando actualizacion version 2', 1, 12, CAST(N'2024-07-04T12:06:17.770' AS DateTime), 12, CAST(N'2024-07-05T18:05:47.687' AS DateTime))
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (86, 69, N'Trujillo en actualizacion de nuevo', 1, 12, CAST(N'2024-07-04T17:13:04.510' AS DateTime), 12, CAST(N'2024-07-05T18:05:47.687' AS DateTime))
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (104, 69, N'Otra direccion mas', 1, 12, CAST(N'2024-07-05T18:05:47.687' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (105, 72, N'Lima', 1, 12, CAST(N'2024-07-08T21:47:57.413' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (106, 72, N'Trujillo', 1, 12, CAST(N'2024-07-08T21:47:57.413' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (107, 72, N'Tumbes', 1, 12, CAST(N'2024-07-08T21:47:57.413' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (108, 102, N'Trujillo', 1, 12, CAST(N'2024-07-17T13:01:31.017' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (109, 102, N'Lima', 1, 12, CAST(N'2024-07-17T13:01:31.017' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (110, 104, N'San Juan Lurigancho', 1, 12, CAST(N'2024-07-17T14:33:01.167' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteDireccion] ([IdClienteDireccion], [IdCliente], [Direccion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (111, 104, N'Carabaillo', 1, 12, CAST(N'2024-07-17T14:33:01.167' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[ClienteDireccion] OFF
GO
SET IDENTITY_INSERT [dbo].[ClienteNoDeseado] ON 
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, 1, N'11112222', N'Arles Prueba', N'Probando el no deseado', 1, 11, CAST(N'2024-07-09T18:11:50.247' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 1, N'11112223', N'Arles Pruebasss', N'Probando el no deseado', 1, 11, CAST(N'2024-07-10T15:57:59.487' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 1, N'11112224', N'Arles Pruebasss', N'Probando el no deseado', 1, 11, CAST(N'2024-07-10T16:32:32.880' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, 1, N'42142541', N'Pedro del Rio', N'Probando a guardar desde el front', 1, 12, CAST(N'2024-07-10T16:33:39.163' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, 1, N'11114444', N'Jason Shaw', N'Probando por segunda vez', 1, 12, CAST(N'2024-07-11T15:10:42.557' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, 2, N'36262121555', N'Albaly Imports', N'Probando por 3ra vez', 1, 12, CAST(N'2024-07-11T15:13:00.707' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[ClienteNoDeseado] ([IdClienteNoDeseado], [IdTipoDocumento], [NumeroDocumento], [NombreCompleto], [Observacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, 2, N'61616515151', N'Probando RUC', N'Probando Final
', 1, 12, CAST(N'2024-07-11T17:51:08.130' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[ClienteNoDeseado] OFF
GO
SET IDENTITY_INSERT [dbo].[Departamento] ON 
GO
INSERT [dbo].[Departamento] ([IdDepartamento], [NombreDepartamento], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'La Libertad', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Departamento] ([IdDepartamento], [NombreDepartamento], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Lima', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Departamento] ([IdDepartamento], [NombreDepartamento], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Chiclayo', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[Departamento] OFF
GO
SET IDENTITY_INSERT [dbo].[FormaPago] ON 
GO
INSERT [dbo].[FormaPago] ([IdFormaPago], [DescripcionFormaPago], [RemitenteJuridico], [ConsignadoJuridico], [RemitenteNatural], [ConsignadoNatural], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Contado', 1, NULL, 1, NULL, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[FormaPago] ([IdFormaPago], [DescripcionFormaPago], [RemitenteJuridico], [ConsignadoJuridico], [RemitenteNatural], [ConsignadoNatural], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Contra Entrega', NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[FormaPago] ([IdFormaPago], [DescripcionFormaPago], [RemitenteJuridico], [ConsignadoJuridico], [RemitenteNatural], [ConsignadoNatural], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Credito', 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[FormaPago] OFF
GO
SET IDENTITY_INSERT [dbo].[menu] ON 
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Operaciones', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Nueva Orden', N'/dashboard/operaciones/nueva-orden', 1, N'pi pi-home', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Orden Servicio', N'/dashboard/operaciones/orden-servicio', 1, N'pi pi-list', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Guia Transportista', N'/dashboard/operaciones/guia-transportista', 1, N'pi pi-map', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Trabajador', N'/dashboard/personal/trabajadores', 2, N'pi pi-users', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, N'Maestros', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, N'Cliente', N'/dashboard/maestros/cliente', 7, N'pi pi-users', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, N'Vehiculo', N'/dashboard/maestros/vehiculo', 7, N'pi pi-car', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, N'Traslado', NULL, 1, N'pi pi-calendar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, N'Cliente no Deseado', N'/dashboard/operaciones/cliente-no-deseado', 1, N'pi pi-exclamation-triangle', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (12, N'Programaciones', N'/dashboard/operaciones/traslado/programaciones', 10, N'pi pi-times', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (13, N'Embarque', N'/dashboard/operaciones/traslado/embarque', 10, N'pi pi-clock', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[menu] ([IdMenu], [Nombre], [Ruta], [IdPadre], [Icono], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (14, N'Manifiesto', N'/dashboard/operaciones/traslado/manifiesto', 10, N'pi pi-times', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[menu] OFF
GO
SET IDENTITY_INSERT [dbo].[perfil] ON 
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Administrador', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Resgistro', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Supervisor', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Administrador', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Administrador', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil] ([IdPerfil], [NombrePerfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Administrador', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[perfil] OFF
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, 6, N'', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 6, N'', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 6, N'1;2', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, 6, N'1;4', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, 6, N'3;2', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[perfil_menu_rol] ([IdMenu], [IdPerfil], [IdsRol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, 6, N'1;2;3;4;5', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[rol] ON 
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Insertar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Actualizar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Eliminar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Visualizar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Autorizar', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Rol_6', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, N'Rol_7', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[rol] ([IdRol], [Rol], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, N'Rol_8', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[rol] OFF
GO
SET IDENTITY_INSERT [dbo].[TipoComprobante] ON 
GO
INSERT [dbo].[TipoComprobante] ([IdTipoComprobante], [DescripcionTipoComprobante], [CodSunat], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Boleta Electronica', NULL, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoComprobante] ([IdTipoComprobante], [DescripcionTipoComprobante], [CodSunat], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Factura Electonica', NULL, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoComprobante] ([IdTipoComprobante], [DescripcionTipoComprobante], [CodSunat], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Orden de Servicio', NULL, 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[TipoComprobante] OFF
GO
INSERT [dbo].[TipoDocumento] ([idTipoDocumento], [Descripcion_TipoDocumento], [Tipo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Documento nacional de Identidad', N'N', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoDocumento] ([idTipoDocumento], [Descripcion_TipoDocumento], [Tipo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Registro Unico Contribuyente', N'J', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoDocumento] ([idTipoDocumento], [Descripcion_TipoDocumento], [Tipo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Passaporte', N'N', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoDocumento] ([idTipoDocumento], [Descripcion_TipoDocumento], [Tipo], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Carnet Extranjeria', N'N', 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[TipoEntrega] ON 
GO
INSERT [dbo].[TipoEntrega] ([IdTipoEntrega], [DescripcionTipoEntrega], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Agencia', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoEntrega] ([IdTipoEntrega], [DescripcionTipoEntrega], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Delivery', 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[TipoEntrega] OFF
GO
SET IDENTITY_INSERT [dbo].[TipoPago] ON 
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Efectivo', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Tarjeta Credito o Debito visa', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Yape', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Plin', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Tranf. Banc. BCP CTA CORRIENTE', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Tranf. Banc. BCP CTA AHOR. LIMA', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, N'Tranf. Banc. BCP CTA DOLARES', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, N'Tranf. Banc. BBVA SOLES', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, N'Tranf. Banc. SCOTIABANK SOLES', 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[TipoPago] ([IdTipoPago], [DescripcionTipoPago], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, N'Tranf. Banc. INTERBANK SOLES', 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[TipoPago] OFF
GO
SET IDENTITY_INSERT [dbo].[TipoServicio] ON 
GO
INSERT [dbo].[TipoServicio] ([IdTipoServicio], [DescripcionTipoServicio], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Carga', 1, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[TipoServicio] OFF
GO
SET IDENTITY_INSERT [dbo].[trabajador] ON 
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (1, N'Francisco Vilchez', N'M', 1, 1, N'44050057', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2020-02-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, N'Luis Rodriguez', N'M', 1, 1, N'98765432', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2020-02-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, N'Crithian Chavez', N'M', 1, 1, N'45632189', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2020-02-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, N'Anthony Pantoja', N'M', 1, 1, N'85236974', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2020-02-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, N'Cristhian Chavez', N'M', 1, 1, N'44050056', N'aaAA11++', CAST(N'2024-05-21T18:31:07.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (6, N'Cristhian Chavez', N'M', 1, 1, N'44050050', N'aaAA11++', CAST(N'2024-05-21T18:33:58.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (7, N'Cristhian Chavez', N'M', 1, 1, N'44050052', N'aaAA11++', CAST(N'2024-05-21T18:38:06.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (8, N'Cristhian Chavez 2', N'M', 1, 1, N'44050055', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2022-01-02T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (9, N'Cristhian Chavez 3', N'M', 1, 1, N'44050058', N'NhsPBXl14F8d7qimX+Ic3Q==', CAST(N'2022-01-02T00:00:00.000' AS DateTime), NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (10, N'rrrrrr', N'm', 2, 2, N'85264', N'string', CAST(N'2024-06-26T20:32:28.713' AS DateTime), 0, 0, CAST(N'2024-06-26T20:32:28.713' AS DateTime), 0, CAST(N'2024-06-26T20:32:28.713' AS DateTime))
GO
INSERT [dbo].[trabajador] ([IdTrabajador], [Nombre_Completo], [Genero], [Estado], [TipoDocumento], [DocumentoIdentidad], [Clave], [FechaContratacion], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, N'fghdfghfg', N'f', 1, 1, N'52638794', N'', CAST(N'2024-06-25T04:09:43.217' AS DateTime), 1, 11, CAST(N'2024-06-24T23:10:38.730' AS DateTime), NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[trabajador] OFF
GO
SET IDENTITY_INSERT [dbo].[usuario] ON 
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (2, 1, 1, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (3, 1, 4, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (4, 1, 3, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (5, 1, 2, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (11, 9, 2, 6, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[usuario] ([IdUsuario], [FK_Trabajador], [FK_Agencia], [Fk_Perfil], [Activo], [UsuarioCreacion], [FechaCreacion], [UsuarioUltimaModificacion], [FechaUltimaModificacion]) VALUES (12, 9, 1, 3, NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[usuario] OFF
GO
ALTER TABLE [dbo].[cliente] ADD  CONSTRAINT [DF__cliente__Nombre___589C25F3]  DEFAULT ('NOT NULL') FOR [Telefono]
GO
ALTER TABLE [dbo].[AgenciaTipoComprobante]  WITH CHECK ADD  CONSTRAINT [FK_AgenciaTipoComprobante_agencia] FOREIGN KEY([IdAgencia])
REFERENCES [dbo].[agencia] ([IdAgencia])
GO
ALTER TABLE [dbo].[AgenciaTipoComprobante] CHECK CONSTRAINT [FK_AgenciaTipoComprobante_agencia]
GO
ALTER TABLE [dbo].[AgenciaTipoComprobante]  WITH CHECK ADD  CONSTRAINT [FK_AgenciaTipoComprobante_TipoComprobante] FOREIGN KEY([IdTipoComprobante])
REFERENCES [dbo].[TipoComprobante] ([IdTipoComprobante])
GO
ALTER TABLE [dbo].[AgenciaTipoComprobante] CHECK CONSTRAINT [FK_AgenciaTipoComprobante_TipoComprobante]
GO
ALTER TABLE [dbo].[chofer]  WITH CHECK ADD  CONSTRAINT [chofer_trabajador_FK] FOREIGN KEY([FK_Trabajador])
REFERENCES [dbo].[trabajador] ([IdTrabajador])
GO
ALTER TABLE [dbo].[chofer] CHECK CONSTRAINT [chofer_trabajador_FK]
GO
ALTER TABLE [dbo].[ClienteContacto]  WITH CHECK ADD  CONSTRAINT [FK_ClienteContacto_cliente] FOREIGN KEY([IdCliente])
REFERENCES [dbo].[cliente] ([IdCliente])
GO
ALTER TABLE [dbo].[ClienteContacto] CHECK CONSTRAINT [FK_ClienteContacto_cliente]
GO
ALTER TABLE [dbo].[ClienteDireccion]  WITH CHECK ADD  CONSTRAINT [FK_ClienteDireccion_cliente] FOREIGN KEY([IdCliente])
REFERENCES [dbo].[cliente] ([IdCliente])
GO
ALTER TABLE [dbo].[ClienteDireccion] CHECK CONSTRAINT [FK_ClienteDireccion_cliente]
GO
ALTER TABLE [dbo].[ClienteNoDeseado]  WITH CHECK ADD  CONSTRAINT [FK_Table_1_TipoDocumento] FOREIGN KEY([IdTipoDocumento])
REFERENCES [dbo].[TipoDocumento] ([idTipoDocumento])
GO
ALTER TABLE [dbo].[ClienteNoDeseado] CHECK CONSTRAINT [FK_Table_1_TipoDocumento]
GO
ALTER TABLE [dbo].[comprobante]  WITH CHECK ADD  CONSTRAINT [comprobante_ordenservicio_FK] FOREIGN KEY([Id_Comprobante])
REFERENCES [dbo].[ordenservicio] ([Id_Orden])
GO
ALTER TABLE [dbo].[comprobante] CHECK CONSTRAINT [comprobante_ordenservicio_FK]
GO
ALTER TABLE [dbo].[embarque]  WITH CHECK ADD  CONSTRAINT [embarque_programacion_FK] FOREIGN KEY([FK_Programacion])
REFERENCES [dbo].[programacion] ([Id_Programacion])
GO
ALTER TABLE [dbo].[embarque] CHECK CONSTRAINT [embarque_programacion_FK]
GO
ALTER TABLE [dbo].[embarque]  WITH CHECK ADD  CONSTRAINT [embarque_usuario_FK] FOREIGN KEY([FK_Usuario])
REFERENCES [dbo].[usuario] ([IdUsuario])
GO
ALTER TABLE [dbo].[embarque] CHECK CONSTRAINT [embarque_usuario_FK]
GO
ALTER TABLE [dbo].[nota_credito]  WITH CHECK ADD  CONSTRAINT [nota_credito_comprobante_FK] FOREIGN KEY([FK_comprobante])
REFERENCES [dbo].[comprobante] ([Id_Comprobante])
GO
ALTER TABLE [dbo].[nota_credito] CHECK CONSTRAINT [nota_credito_comprobante_FK]
GO
ALTER TABLE [dbo].[nota_credito]  WITH CHECK ADD  CONSTRAINT [nota_credito_ordenservicio_FK] FOREIGN KEY([FK_Orden])
REFERENCES [dbo].[ordenservicio] ([Id_Orden])
GO
ALTER TABLE [dbo].[nota_credito] CHECK CONSTRAINT [nota_credito_ordenservicio_FK]
GO
ALTER TABLE [dbo].[nota_credito]  WITH CHECK ADD  CONSTRAINT [nota_credito_usuario_FK] FOREIGN KEY([FK_Usuario])
REFERENCES [dbo].[usuario] ([IdUsuario])
GO
ALTER TABLE [dbo].[nota_credito] CHECK CONSTRAINT [nota_credito_usuario_FK]
GO
ALTER TABLE [dbo].[ordenservicio]  WITH CHECK ADD  CONSTRAINT [ordenservicio_cliente_FK] FOREIGN KEY([IdTipoServicio])
REFERENCES [dbo].[cliente] ([IdCliente])
GO
ALTER TABLE [dbo].[ordenservicio] CHECK CONSTRAINT [ordenservicio_cliente_FK]
GO
ALTER TABLE [dbo].[ordenservicio]  WITH CHECK ADD  CONSTRAINT [ordenservicio_cliente_FK_1] FOREIGN KEY([IdTipoEntrega])
REFERENCES [dbo].[cliente] ([IdCliente])
GO
ALTER TABLE [dbo].[ordenservicio] CHECK CONSTRAINT [ordenservicio_cliente_FK_1]
GO
ALTER TABLE [dbo].[ordenservicio_item]  WITH CHECK ADD  CONSTRAINT [paquete_ordenservicio_FK] FOREIGN KEY([FK_OrdenServicio])
REFERENCES [dbo].[ordenservicio] ([Id_Orden])
GO
ALTER TABLE [dbo].[ordenservicio_item] CHECK CONSTRAINT [paquete_ordenservicio_FK]
GO
ALTER TABLE [dbo].[ordenservicioconsignado]  WITH CHECK ADD  CONSTRAINT [ordenservicioconsignado_cliente_FK] FOREIGN KEY([FK_Consignado])
REFERENCES [dbo].[cliente] ([IdCliente])
GO
ALTER TABLE [dbo].[ordenservicioconsignado] CHECK CONSTRAINT [ordenservicioconsignado_cliente_FK]
GO
ALTER TABLE [dbo].[ordenservicioconsignado]  WITH CHECK ADD  CONSTRAINT [ordenservicioconsignado_ordenservicio_FK] FOREIGN KEY([FK_OrdenServicio])
REFERENCES [dbo].[ordenservicio] ([Id_Orden])
GO
ALTER TABLE [dbo].[ordenservicioconsignado] CHECK CONSTRAINT [ordenservicioconsignado_ordenservicio_FK]
GO
ALTER TABLE [dbo].[ordenservicioconsignado]  WITH CHECK ADD  CONSTRAINT [ordenservicioconsignado_usuario_FK] FOREIGN KEY([FK_Usuario])
REFERENCES [dbo].[usuario] ([IdUsuario])
GO
ALTER TABLE [dbo].[ordenservicioconsignado] CHECK CONSTRAINT [ordenservicioconsignado_usuario_FK]
GO
ALTER TABLE [dbo].[perfil_menu_rol]  WITH CHECK ADD  CONSTRAINT [FK_perfil_menu_rol_menu] FOREIGN KEY([IdMenu])
REFERENCES [dbo].[menu] ([IdMenu])
GO
ALTER TABLE [dbo].[perfil_menu_rol] CHECK CONSTRAINT [FK_perfil_menu_rol_menu]
GO
ALTER TABLE [dbo].[perfil_menu_rol]  WITH CHECK ADD  CONSTRAINT [FK_perfil_menu_rol_perfil] FOREIGN KEY([IdPerfil])
REFERENCES [dbo].[perfil] ([IdPerfil])
GO
ALTER TABLE [dbo].[perfil_menu_rol] CHECK CONSTRAINT [FK_perfil_menu_rol_perfil]
GO
ALTER TABLE [dbo].[programacion]  WITH CHECK ADD  CONSTRAINT [programacion_chofer_FK] FOREIGN KEY([FK_Piloto])
REFERENCES [dbo].[chofer] ([ID_Chofer])
GO
ALTER TABLE [dbo].[programacion] CHECK CONSTRAINT [programacion_chofer_FK]
GO
ALTER TABLE [dbo].[programacion]  WITH CHECK ADD  CONSTRAINT [programacion_chofer_FK_1] FOREIGN KEY([FK_Copiloto])
REFERENCES [dbo].[chofer] ([ID_Chofer])
GO
ALTER TABLE [dbo].[programacion] CHECK CONSTRAINT [programacion_chofer_FK_1]
GO
ALTER TABLE [dbo].[programacion]  WITH CHECK ADD  CONSTRAINT [programacion_usuario_FK] FOREIGN KEY([FK_Usuario])
REFERENCES [dbo].[usuario] ([IdUsuario])
GO
ALTER TABLE [dbo].[programacion] CHECK CONSTRAINT [programacion_usuario_FK]
GO
ALTER TABLE [dbo].[programacion]  WITH CHECK ADD  CONSTRAINT [programacion_vehiculo_FK] FOREIGN KEY([FK_Vehiculo])
REFERENCES [dbo].[vehiculo] ([Id_Vehiculo])
GO
ALTER TABLE [dbo].[programacion] CHECK CONSTRAINT [programacion_vehiculo_FK]
GO
ALTER TABLE [dbo].[usuario]  WITH CHECK ADD  CONSTRAINT [usuario_agencia_FK] FOREIGN KEY([FK_Agencia])
REFERENCES [dbo].[agencia] ([IdAgencia])
GO
ALTER TABLE [dbo].[usuario] CHECK CONSTRAINT [usuario_agencia_FK]
GO
ALTER TABLE [dbo].[usuario]  WITH CHECK ADD  CONSTRAINT [usuario_trabajador_FK] FOREIGN KEY([FK_Trabajador])
REFERENCES [dbo].[trabajador] ([IdTrabajador])
GO
ALTER TABLE [dbo].[usuario] CHECK CONSTRAINT [usuario_trabajador_FK]
GO
ALTER TABLE [dbo].[vehiculo]  WITH CHECK ADD  CONSTRAINT [vehiculo_tipovehiculo_FK] FOREIGN KEY([FK_VehiculoTipo])
REFERENCES [dbo].[tipovehiculo] ([Id_TipoVehiculo])
GO
ALTER TABLE [dbo].[vehiculo] CHECK CONSTRAINT [vehiculo_tipovehiculo_FK]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia', @level2type=N'COLUMN',@level2name=N'IdAgencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia', @level2type=N'COLUMN',@level2name=N'NombreAgencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia', @level2type=N'COLUMN',@level2name=N'HorarioInicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia', @level2type=N'COLUMN',@level2name=N'HorarioTermino'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia', @level2type=N'COLUMN',@level2name=N'FK_EstadoAgencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'agencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'ID_Chofer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'FK_Trabajador'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'NumeroLicenciaConducir'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'FechaExpiracionLicencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'TipoLicencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'Estado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer', @level2type=N'COLUMN',@level2name=N'Horario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'chofer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'IdCliente'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'FK_TipoDocumento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Documento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Nombres'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Apellidos'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'NombreCompleto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Direccion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Ubigeo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Telefono'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Correo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente', @level2type=N'COLUMN',@level2name=N'Contacto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'cliente'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'Id_Comprobante'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'FK_Orden'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'FK_Cajero'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'FechaRegistro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'Serie'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante', @level2type=N'COLUMN',@level2name=N'Numero'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'comprobante'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'id_DetallePago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'PK_OrdeServicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'PK_Comprobante'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'FechaPago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'TipoPago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'TipoTarjeta'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'MontoPagado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'Lote'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'Digito'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'Referencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago', @level2type=N'COLUMN',@level2name=N'Monto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'detallepago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'documento_referencia', @level2type=N'COLUMN',@level2name=N'idDocumento_Referencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'documento_referencia', @level2type=N'COLUMN',@level2name=N'Descripcion_DocumentoReferencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'documento_referencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'id_Embarque'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FK_Orden'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FK_Usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FechaRegistro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'Ruta_Origen'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'Ruta_Destino'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FK_TipoProgramacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FK_Programacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque', @level2type=N'COLUMN',@level2name=N'FK_Estado_Embarque'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'embarque'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu', @level2type=N'COLUMN',@level2name=N'IdMenu'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu', @level2type=N'COLUMN',@level2name=N'Nombre'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu', @level2type=N'COLUMN',@level2name=N'Ruta'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu', @level2type=N'COLUMN',@level2name=N'IdPadre'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu', @level2type=N'COLUMN',@level2name=N'Icono'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'menu'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'idNotaCredito'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'FK_Orden'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'FK_Usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'FechaRegistro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'Serie'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'NumeroOrden'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito', @level2type=N'COLUMN',@level2name=N'FK_comprobante'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'nota_credito'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'Id_Orden'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdOrigen'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdDestino'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdTipoServicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdTipoEntrega'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdRemitente'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdDestinatario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'PersonaContacto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdPersonaContacto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'DireccionEntrega'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdFormaPago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IdResponsablePago'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalUnidades'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalPeso'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalBulto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalVolumen'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalDescuento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'TotalImporte'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio', @level2type=N'COLUMN',@level2name=N'IGV'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'id_Item'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'FK_OrdenServicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'Descripcion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'Unidad'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'Numero'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'Peso'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'Factor'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'PrecioUnitario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item', @level2type=N'COLUMN',@level2name=N'PrecioTotal'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicio_item'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado', @level2type=N'COLUMN',@level2name=N'FK_OrdenServicio'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado', @level2type=N'COLUMN',@level2name=N'FK_Consignado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado', @level2type=N'COLUMN',@level2name=N'FechaRegistro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado', @level2type=N'COLUMN',@level2name=N'FK_Usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado', @level2type=N'COLUMN',@level2name=N'Estado_Baja'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ordenservicioconsignado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil', @level2type=N'COLUMN',@level2name=N'IdPerfil'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil', @level2type=N'COLUMN',@level2name=N'NombrePerfil'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil_menu_rol', @level2type=N'COLUMN',@level2name=N'IdMenu'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil_menu_rol', @level2type=N'COLUMN',@level2name=N'IdPerfil'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil_menu_rol', @level2type=N'COLUMN',@level2name=N'IdsRol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'perfil_menu_rol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'Id_Programacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'Fecha_Registro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FK_Usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FK_TipoProgramacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FechaViaje'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FK_Piloto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FK_Copiloto'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion', @level2type=N'COLUMN',@level2name=N'FK_Vehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'programacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'rol', @level2type=N'COLUMN',@level2name=N'IdRol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'rol', @level2type=N'COLUMN',@level2name=N'Rol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'rol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TipoDocumento', @level2type=N'COLUMN',@level2name=N'idTipoDocumento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TipoDocumento', @level2type=N'COLUMN',@level2name=N'Descripcion_TipoDocumento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TipoDocumento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tipovehiculo', @level2type=N'COLUMN',@level2name=N'Id_TipoVehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tipovehiculo', @level2type=N'COLUMN',@level2name=N'ConsumoCombustible'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tipovehiculo', @level2type=N'COLUMN',@level2name=N'Descripcion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tipovehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'IdTrabajador'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'Nombre_Completo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'Genero'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'Estado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'TipoDocumento'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'DocumentoIdentidad'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'Clave'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'FechaContratacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador', @level2type=N'COLUMN',@level2name=N'FechaCreacion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'trabajador'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'usuario', @level2type=N'COLUMN',@level2name=N'IdUsuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'usuario', @level2type=N'COLUMN',@level2name=N'FK_Trabajador'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'usuario', @level2type=N'COLUMN',@level2name=N'FK_Agencia'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'usuario', @level2type=N'COLUMN',@level2name=N'Fk_Perfil'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Id_Vehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'FK_VehiculoTipo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'FK_Usuario'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Fecha_Registro'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'ejes'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Fecha_Inscripción'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Placa'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Serie_Vehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Marca'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Modelo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Estado'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'id_Estado_Vehiculo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'FK_Chofer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo', @level2type=N'COLUMN',@level2name=N'Serie_Motor'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'TRIAL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'vehiculo'
GO
USE [master]
GO
ALTER DATABASE [BDSeguridad] SET  READ_WRITE 
GO
