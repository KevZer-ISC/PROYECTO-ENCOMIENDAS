## Dev

1. Clonar el repositorio
2. Create un .env basado en el .env.template
3. Ejecutar el comando `git submodule update --init --recursive` para reconstruir los sub-módulos
4. Ejecutar el comando `docker compose up --build`


### Pasos para crear los Git Submodules


1. Crear un nuevo repositorio en GitHub
2. Clonar el repositorio en la máquina local
3. Añadir el submodule, donde `repository_url` es la url del repositorio y `directory_name` es el nombre de la carpeta donde quieres que se guarde el sub-módulo (no debe de existir en el proyecto)
```
git submodule add <repository_url> <directory_name>
```
4. Añadir los cambios al repositorio (git add, git commit, git push)
Ej:
```
git add .
git commit -m "Add submodule"
git push
```
5. Inicializar y actualizar Sub-módulos, cuando alguien clona el repositorio por primera vez, debe de ejecutar el siguiente comando para inicializar y actualizar los sub-módulos
```
git submodule update --init --recursive
```
6. Para actualizar las referencias de los sub-módulos
```
git submodule update --remote
```


## Base de Datos
La base de datos se encuentra dentro de la carpeta `DB`, en dicha carpeta esta el script que debera de ejecutarse cada vez que la imagen se elimine o se genere una nueva

Recordar que la base de datos contiene los volumenes en Docker para su respectivo respaldo, asi que asi se elimine la base de datos, puede restaurase, eso sirve en produccion, pero en desarrollo no es tan frecuente.


## Ymls
Contiene el archivo `docker-compose.yml` el cual tiene como servicios principales las imagenes docker que vienen desde docker hub.

Tener en cuenta que las imagenes DockerHub son del codigo, entonces cada vez que se genere una imagen tiene que:
1. Generar la imagen
2. Generar la Release con el tagname

Si se quiere levantar el proyecto solo con imagenes y no con el codigo entonces ejecutar este archivo con `docker compose up --build` y luego conectarse a la base de datos y ejecutar el script respectivo.

## Credenciales
Contiene las credenciales de acceso a la base de datos.

Recordar:
1. Si en caso quiera conectarse a la base de datos en windows con el Managment Studio o con Azure Data Studio y tiene instalado los servicios de SQLServer, entonces desactivelos en los servicios y windows y conectese a la base de datos con las credenciales
2. SI en caso quiera conectarse a la base de datos y no tiene instalado los servicios de SQLServer en su maquina, puede descargar solo Azure Data Studio y conectarse con las credenciales, asi se evita descargas innecesarias


## Pasos para crear las imagenes
1. Primero realiza un el frontend `git fetch origin main` y un `git pull origin main`. Esto servira para traer todos los cambios desde el main de GitLab(Recuerda que debes hacer merge a los cambios antes)
2. El backend la cadena de conexion y el Dockerfile esta en la rama `ore` entonces necesitas navegar a esa rama y traer todo lo nuevo desde el main, por eso ejecutaras `git checkout origin ore`, `git fetch origin main` y un `git pull origin main`. Con eso traeras toda la data desde el main.
3. Ejecuta `docker compose up --build` para verificar que el proyecto se levante solo
4. Ahora en el archivo `docker-compose.yml` cambia las etiquetas de cada imagen a la version que necesites, por ejemplo:
```
image: front-andeskar:2.0.0
```
Como se observa la release es el 2.0.0

Eso servira para crear la imagen local con el numero de version.

5. Ahora se debe etiquetar la imagen para que podamos subirla a dockerhub asi que se usara el comando de docker, presentare un cuadro en donde estara el comando respectivo para cada imagen. 

Estos son los pasos que se debe hacer, primero se ejecuta el comando para etiquetar a la imagen, luego se carga con el segundo comando a dockerhub.

Recordar que esto se debe hacer en la ruta raiz del proyecto `.launcher-andeskar` y que en cada version que se hafa en los comandos tambien debe cambiarse el numero, esta demas decirlo si estas leyendo eso eres desarrollador.

Proyecto | Comando | DockerHub
------------ | ------------- | -------------
[Andeskar-Front](https://gitlab.com/proyectoandeskar/andeskar-front.git) | docker tag front-andeskar:2.0.0 andeskarperu/front-andeskar:2.0.0 | docker push andeskarperu/front-andeskar:2.0.0
[Proyecto-Seguridad](https://gitlab.com/proyectoandeskar/backendandeskar.git) | docker tag proyecto-seguridad:2.0.0 andeskarperu/proyecto-seguridad:2.0.0 | docker push andeskarperu/proyecto-api-mysql:2.0.0
[Proyecto-Api-Mysql](https://gitlab.com/proyectoandeskar/backendandeskar.git) | docker tag proyecto-api-mysql:2.0.0 andeskarperu/proyecto-api-mysql:2.0.0 | docker push andeskarperu/proyecto-seguridad:2.0.0

6. Para que no haya conflicto con los submodulos, cargar primero los submodulos y verificar las ramas, hacerlo desde el mismo git en visual studio code.
7. Luego cargar el proyecto principal a gitlab, pero recuerda que que esta cargando a la rama `ore` o en la rama que se este desarrollando, luego despues de cargar todo hacer un merge a main para ver los cambios respectivos.
8. Recordar que toda rama debe apuntar al ultimo commit de su repositorio y al cerrar este proyecto debe estar en sus main, todas, sobretodo el backend, porque el front ya estara apuntando al frontend porque desde el inicio se esta haciendo merge al main del frontend y etamos sincronizando los cambios, pero por otro lado el backend lo estamos haciendo que primero navegemos a la rama que tiene la conexion a la bd y de ahi hacemos un pull al main
`TENER EN CUENTA EL PASO 8`



