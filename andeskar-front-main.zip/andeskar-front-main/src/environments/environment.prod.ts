export const environment = {
  production: true,
  // URL_BACKEND:'https://localhost:7098',
  // URL_AUTH:'https://localhost:7262/api',

  ////Puertos Para Docker en Produccion
  URL_BACKEND: 'http://localhost:7098/api',
  URL_AUTH: 'http://localhost:7262/api', 
};
