// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  ////Puertos para el Backend Local
  URL_BACKEND:'https://localhost:7098/api',
  URL_AUTH:'https://localhost:7262/api',



  ////Puertos para la nube de prueba
  // URL_BACKEND:'http://www.emtrafesa.com:69/api',
  // URL_AUTH:'http://www.emtrafesa.com:68/api'


  ////Puertos Para Docker
  // URL_BACKEND:'http://localhost:5000/api',
  // URL_AUTH:'http://localhost:5001/api'


   //Puertos Para Docker en Produccion
  // URL_BACKEND: 'http://localhost:7098/api',
  // URL_AUTH: 'http://localhost:7262/api',   


  ////Puertos para el IIS Local
  // URL_BACKEND:'http://localhost:4223/api',
  // URL_AUTH:'http://localhost:4222/api'


};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
