import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateUtilService {
  constructor() {}

  formatFechaAPI(fecha: string): string {
    const dateObject = new Date(fecha + 'T00:00:00'); // Agregar la hora para asegurar la zona horaria
    const dia = dateObject.getUTCDate(); // Utilizar métodos UTC para obtener la fecha en UTC
    const mes = dateObject.getUTCMonth() + 1;
    const año = dateObject.getUTCFullYear();

    return `${dia < 10 ? '0' : ''}${dia}/${mes < 10 ? '0' : ''}${mes}/${año}`;
  }

  formatFechaParams(fechaOriginal: string) {
    const fecha = new Date(fechaOriginal);

    const dia = fecha.getDate();
    const mes = fecha.getMonth() + 1;
    const anio = fecha.getFullYear();

    const fechaFormateada = `${anio}-${mes.toString().padStart(2, '0')}-${dia
      .toString()
      .padStart(2, '0')}`;

    return fechaFormateada;
  }

  getCurrentFormattedDate(): string {
    const currentDate = new Date();
    return this.formatDate(currentDate);
  }

  private formatDate(date: Date): string {
    const day = this.padZero(date.getDate());
    const month = this.padZero(date.getMonth() + 1); // Los meses en JavaScript son 0-11
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  private padZero(value: number): string {
    return value < 10 ? `0${value}` : value.toString();
  }
}
