import { TestBed } from '@angular/core/testing';

import { SuscribersTestingService } from './suscribers-testing.service';

describe('SuscribersTestingService', () => {
  let service: SuscribersTestingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SuscribersTestingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
