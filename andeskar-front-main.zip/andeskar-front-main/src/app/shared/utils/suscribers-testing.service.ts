import { Injectable } from '@angular/core';
import { interval, Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SuscribersTestingService {
  private subscription: Subscription = new Subscription();
  counterValue: number = 0;

  constructor() { }


  startCounter(): void {
    const counter$ = interval(1000); // Crea un observable que emite valores cada segundo

    this.subscription.add(
      counter$.subscribe({
        next: (value) => {
          this.counterValue = value;
          console.log(`Counter Value: ${value}`);
        },
        complete: () => {
          console.log('Counter completed');
        },
      })
    );
  }

}
