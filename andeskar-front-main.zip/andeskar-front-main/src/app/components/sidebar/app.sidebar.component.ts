import { Component, Input, OnInit } from '@angular/core';
import { IMenu } from 'src/app/core/interfaces/menu/IMenu.interface';
import { MenuService } from 'src/app/core/service/service.core';
import { CustomErrorService } from 'src/app/shared/shared';

@Component({
  selector: 'app-sidebar',
  templateUrl: './app.sidebar.component.html',
  styleUrls: ['./app.sidebar.component.css'],
})
export class AppSidebarComponent implements OnInit {
  @Input() usuario: any | null;
  menuItems: IMenu[] = [];
  isLoading: boolean = false;

  constructor(
    private readonly menuService: MenuService,
    private customErrorService: CustomErrorService
  ) {}

  ngOnInit(): void {
    this.menuService.listarMenuOrdenadoService$().subscribe({
      next: (res) => {
        this.isLoading = true;
        this.menuItems = res;
      },
      error: (error) => this.customErrorService.listError(error),
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  // listar(items:any){
  //   console.log(items);
  // }
}
