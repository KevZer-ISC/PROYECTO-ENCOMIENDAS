import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { CTRABAJADOR_CONSTANT } from 'src/app/core/constants/personal/CTrabajador.constant';
import { CUSERS_CONSTANT } from 'src/app/core/constants/personal/CUsers.constant';
import { IUsers } from 'src/app/core/interfaces/personal/IUsers.interface';
import { ITrabajador } from 'src/app/core/interfaces/personal/Itrabajadores.interface';

@Component({
  selector: 'app-trabajadores',
  templateUrl: './trabajadores.component.html',
  styleUrls: ['./trabajadores.component.css'],
})
export class TrabajadoresComponent implements OnInit {
  items: MenuItem[] = [
    { label: 'New', icon: 'pi pi-plus' },
    { label: 'Search', icon: 'pi pi-search' },
  ];
  isVisibleModal: boolean = false;
  isVisibleSidebar: boolean = false;
  isNewUser: boolean = false;


  users: IUsers[] = CUSERS_CONSTANT;
  trabajadores: ITrabajador[] = CTRABAJADOR_CONSTANT;
  first1: number = 0;

  rows1: number = 10;

  first2: number = 0;

  rows2: number = 10;

  first3: number = 0;

  rows3: number = 10;

  totalRecords: number = 120;
  ngOnInit(): void {}

  showModal() {
    this.isVisibleModal = !this.isVisibleModal;
  }

  showSidebar() {
    this.isVisibleSidebar = !this.isVisibleSidebar;
  }

  showFormNewUser() {
    this.isNewUser = !this.isNewUser;
  }

  onPageChange1(event: any) {
    this.first1 = event.first;
    this.rows1 = event.rows;
}
}
