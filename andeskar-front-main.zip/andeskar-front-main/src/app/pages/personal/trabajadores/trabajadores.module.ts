import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TrabajadoresRoutingModule } from './trabajadores-routing.module';
import { TrabajadoresComponent } from './trabajadores.component';
import { PersonalPrimeNgModule } from 'src/app/core/themes/modules/modules';


@NgModule({
  declarations: [
    TrabajadoresComponent
  ],
  imports: [
    CommonModule,
    TrabajadoresRoutingModule,
    PersonalPrimeNgModule
  ]
})
export class TrabajadoresModule { }
