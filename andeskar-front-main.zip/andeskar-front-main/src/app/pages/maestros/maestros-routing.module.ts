import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path:'cliente',
    loadChildren:()=>import('./cliente/cliente.module').then(m=>m.ClienteModule)
  },
  {
    path:'vehiculo',
    loadChildren:()=>import('./vehiculo/vehiculo.module').then(m=>m.VehiculoModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MaestrosRoutingModule { }
