import { Component, OnDestroy, ViewChild } from '@angular/core';
import { CCLIENTE_CONSTANT } from 'src/app/core/constants/maestros/CCliente.constant';
import { ICliente } from 'src/app/core/interfaces/maestros/ICliente.interface';
import { AlertService } from 'src/app/shared/components/alert.service';
import { TablaClienteComponent } from './card-cliente/tabla-cliente/tabla-cliente.component';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidatorsService } from 'src/app/shared/shared';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
})
export class ClienteComponent implements OnDestroy {
  clientes: ICliente[] = CCLIENTE_CONSTANT;
  visible: boolean = false;
  isContactSidebarVisible: boolean = false;
  isDirectionSidebarVisible: boolean = false;
  direccionesArray: any[];

  @ViewChild(TablaClienteComponent) tablaCliente: TablaClienteComponent;

  direccionForm: FormGroup;
  contactosForm: FormGroup;

  direccionesSubmited: any[];
  contactosSubmited: any[];

  constructor(
    private alertService: AlertService,
    private readonly fb: FormBuilder,
    private readonly validatorsService: ValidatorsService
  ) {
    this.direccionForm = this.fb.group({
      direcciones: this.fb.array([this.createDireccion()]),
    });

    this.contactosForm = fb.group({
      contactos: fb.array([this.createContactos()]),
    });
  }

  get direcciones(): FormArray {
    return this.direccionForm.get('direcciones') as FormArray;
  }

  get contactos(): FormArray {
    return this.contactosForm.get('contactos') as FormArray;
  }

  createDireccion(): FormGroup {
    return this.fb.group({
      direccion: [
        '',
        [Validators.required, this.validatorsService.validateAddress],
      ],
    });
  }

  createContactos(): FormGroup {
    return this.fb.group({
      documento: [
        '',
        [Validators.required, this.validatorsService.validateForeignerCard],
      ],
      nombre: [
        '',
        [Validators.required, this.validatorsService.validateFullname],
      ],
      telefono: [
        '',
        [Validators.required, this.validatorsService.validatePhone],
      ],
    });
  }

  generateMoreDirections(): void {
    this.direcciones.push(this.createDireccion());
  }

  generateMoreContacts(): void {
    this.contactos.push(this.createContactos());
  }

  removeDireccion(index: number): void {
    this.direcciones.removeAt(index);
  }

  removeContacts(index: number): void {
    this.contactos.removeAt(index);
  }

  submitFormDirections(): void {
    if (this.direccionForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const direccionesArray = this.direccionForm.value.direcciones.map(
      (direccion: any) => ({
        idDireccion: 0,
        idCliente: 0,
        direccion: direccion.direccion,
      })
    );

    this.direccionesSubmited = direccionesArray;
    this.isDirectionSidebarVisible = !this.isDirectionSidebarVisible;
  }

  submitFormContacts() {
    const contactsArray = this.contactosForm.value.contactos.map(
      (contacto: any) => ({
        idContacto: 0,
        idCliente: 0,
        documento: contacto.documento,
        nombre: contacto.nombre,
        telefono: contacto.telefono,
      })
    );

    if (this.contactosForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    this.contactosSubmited = contactsArray;
    this.isContactSidebarVisible = !this.isContactSidebarVisible;
  }

  showDialog() {
    this.visible = !this.visible;
  }

  /**
   * Este mensaje sucede para emitir si el cliente se creo correctamente o no
   * @param isSuccess Es el parametro de entrada
   */
  messageEmited(isSuccess: boolean) {
    if (isSuccess) {
      this.alertService.showSuccess('Exito!!', 'Cliente Creado Exitosamente');
      this.showDialog();
      this.tablaCliente.loadClientes();
      this.direccionForm.reset({
        direcciones: this.fb.array([this.createDireccion()]),
      });
      this.contactosForm.reset({
        contactos: this.fb.array([this.createContactos()]),
      });
    } else {
      this.alertService.showError(
        'Error',
        'Ups!!.. Sucedio algo al crear el Cliente'
      );
      this.showDialog();
    }
  }

  contactoSidebarEmited() {
    this.isContactSidebarVisible = !this.isContactSidebarVisible;
  }

  directionSidebarEmited() {
    this.isDirectionSidebarVisible = !this.isDirectionSidebarVisible;
  }

  ngOnDestroy(): void {}
}
