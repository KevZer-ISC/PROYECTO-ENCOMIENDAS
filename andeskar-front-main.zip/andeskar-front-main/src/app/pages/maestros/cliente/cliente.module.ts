import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClienteRoutingModule } from './cliente-routing.module';
import { ClienteComponent } from './cliente.component';
import { MaestrosPrimeNgModule } from 'src/app/core/themes/modules/maestros/maestros_primeng.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgenciaService, ClienteService, DepartamentoService } from 'src/app/services/service.root';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';

import { BuscarClienteComponent } from './card-cliente/buscar-cliente/buscar-cliente.component';
import { TablaClienteComponent } from './card-cliente/tabla-cliente/tabla-cliente.component';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { SharedClienteModule } from 'src/app/core/components/cliente/shared-cliente.module';

@NgModule({
  declarations: [
    ClienteComponent,
    BuscarClienteComponent,
    TablaClienteComponent,
  ],
  imports: [
    CommonModule,
    ClienteRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaestrosPrimeNgModule,
    SharedClienteModule
  ],
  providers: [
    MessageService,
    AlertService,
    ClienteService,
    CustomErrorService,
    ValidatorsService,
    TipoDocumentoService,
    DepartamentoService,
    AgenciaService,

  ],
})
export class ClienteModule {}
