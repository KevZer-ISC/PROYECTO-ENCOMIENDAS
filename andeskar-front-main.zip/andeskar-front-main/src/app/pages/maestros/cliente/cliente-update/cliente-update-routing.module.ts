import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClienteUpdateComponent } from './cliente-update.component';

const routes: Routes = [
  {
    path:':id',
    component: ClienteUpdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClienteUpdateRoutingModule { }
