import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { of, Subject, Subscription } from 'rxjs';
import {
  IAgency,
  ICliente,
  IDepartamento,
  ITypeDocument,
} from 'src/app/core/interfaces/interfaces';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import {
  AgenciaService,
  ClienteService,
  DepartamentoService,
} from 'src/app/services/service.root';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { delay, switchMap, takeUntil } from 'rxjs/operators';
import { DireccionesClienteComponent } from 'src/app/core/components/sidebars/direcciones-cliente/direcciones-cliente.component';
import { ContactosClienteComponent } from 'src/app/core/components/sidebars/contactos-cliente/contactos-cliente.component';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-cliente-update',
  templateUrl: './cliente-update.component.html',
  styleUrls: ['./cliente-update.component.css'],
})
export class ClienteUpdateComponent implements OnInit, OnDestroy {
  clienteId: string;
  private destroy$ = new Subject<void>();
  cliente: ICliente;

  @ViewChild(DireccionesClienteComponent)
  direccionesCliente: DireccionesClienteComponent;
  @ViewChild(ContactosClienteComponent)
  contactoCliente: ContactosClienteComponent;

  /**
   * Supscripciones activas para cada evento
   */
  docSubscriber: Subscription;
  departamentoSubscriber: Subscription;
  agenciaSubscriber: Subscription;

  /**
   * Variables para los ids de los dropdowns seleccionados
   */
  private _idDocumento!: number;
  private _idDepartamento!: number;
  private _idAgencia!: number;

  /**
   * Variables de dropdowns
   */
  tipoDocumento: ITypeDocument[];
  departamento: IDepartamento[];
  agencia: IAgency[];

  isVisibleSidebar: boolean = true;
  isDniSelected = true;
  isRucSelected = false;
  isLoading: boolean = false;

  updateclientForm: FormGroup = this.fb.group({
    tipoDocumento: ['', []],
    documento: ['', []],
    nombre: ['', []],
    apellidos: ['', []],
    razonSocial: ['', []],
    departamento: ['', []],
    direccion: ['', []],
    telefono: ['', []],
    correo: ['', [Validators.required, Validators.email]],
    ubigeo: ['', []],
    credito: [],
  });



  @Output() contactoSidebarEmit: EventEmitter<void> = new EventEmitter<void>();

  constructor(
    private fb: FormBuilder,
    private readonly clienteService: ClienteService,
    private customErrorService: CustomErrorService,
    private readonly customValidatorsService: ValidatorsService,
    private readonly tipoDocumentoService: TipoDocumentoService,
    private readonly departamentoService: DepartamentoService,
    private readonly agenciaService: AgenciaService,
    private readonly route: ActivatedRoute,
    private readonly alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.inits();
  }

  inits() {
    this.loadAgency();
    this.loadDepartment();
    this.loadDocument();
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe((params) => {
      this.clienteId = params.get('id')!;
      this.loadClient(this.clienteId);
    });
  }

  loadDocument() {
    this.docSubscriber = this.tipoDocumentoService
      .listarTipoDocumentoService$()
      .subscribe({
        next: (res: ITypeDocument[]) => {
          this.tipoDocumento = res;
        },
        error: (error) => this.customErrorService.listError(error),
      });
  }

  loadDepartment() {
    this.departamentoSubscriber = this.departamentoService
      .listarDepartamentosService$()
      .subscribe({
        next: (res: IDepartamento[]) => {
          this.departamento = res;
        },
        error: (error) => this.customErrorService.listError(error),
      });
  }

  loadAgency() {
    this.agenciaSubscriber = this.agenciaService
      .listarAgenciaService$()
      .subscribe({
        next: (res: IAgency[]) => {
          this.agencia = res;
        },
        error: (error) => this.customErrorService.listError(error),
      });
  }

  loadClient(id: string) {
    this.clienteService.obtenerClienteService$(+id).subscribe({
      next: (res: ICliente) => {
        this.cliente = res;

        this.updateclientForm.patchValue({
          tipoDocumento: this.cliente.tipoDocumento,
          documento: this.cliente.documento,
          nombre: this.cliente.nombre,
          departamento: this.cliente.departamento,
          apellidos: this.cliente.apellidos,
          razonSocial: this.cliente.nombreCompleto,
          direccion: this.cliente.direccion,
          telefono: this.cliente.telefono,
          correo: this.cliente.correo,
          ubigeo: this.cliente.ubigeo,
          credito: this.cliente.credito,
        });
        this.onDocumentSelect();
      },
      error: (error) => this.customErrorService.listError(error),
    });
  }

  onDocumentSelect() {
    const {
      tipoDocumento: { descripcion_TipoDocumento },
    } = this.updateclientForm.value;
    this.isDniSelected =
      descripcion_TipoDocumento !== 'Registro Unico Contribuyente';
    this.isRucSelected = !this.isDniSelected;
  }

  get showDniFields(): boolean {
    return this.isDniSelected;
  }

  get showRucField(): boolean {
    return this.isRucSelected;
  }

  showContacSidebarEmit() {
    this.contactoCliente.loadContactsByIdClient();
    this.contactoCliente.isContactSidebarVisible =
      !this.contactoCliente.isContactSidebarVisible;
  }

  showDirectionSidebarEmit() {
    this.direccionesCliente.loadDirectionByIdClient();
    this.direccionesCliente.isDirectionSidebarVisible =
      !this.direccionesCliente.isDirectionSidebarVisible;
  }

  updateClient() {
    if (this.updateclientForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const {
      tipoDocumento: { idTipoDocumento },
      departamento: { idDepartamento },
      ...resto
    } = this.updateclientForm.value;

    const nuevoCliente = {
      ...resto,
      id: this.clienteId,
      tipoDocumento: idTipoDocumento,
      departamento: idDepartamento,
    };
    this.clienteService
      .updateClienteService$(nuevoCliente)
      .pipe(
        switchMap(() => {
          this.isLoading = true;
          return of(true).pipe(delay(2000));
        })
      )
      .subscribe({
        next: () => {
          this.alertService.showSuccess(
            'Exito!!',
            'Cliente actualizado correctamente'
          );
        },
        error: (error) => {
          this.customErrorService.listError(error);
          this.alertService.showError(
            'Ups..',
            'Sucedio un error en la conexion, contacte con un administrador'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  ngOnDestroy(): void {
    // Emitir un valor para indicar que el componente se está destruyendo
    this.destroy$.next();
    this.destroy$.complete();
  }
}
