import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClienteUpdateRoutingModule } from './cliente-update-routing.module';
import { MaestrosPrimeNgModule } from 'src/app/core/themes/modules/maestros/maestros_primeng.module';
import { ClienteUpdateComponent } from './cliente-update.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DireccionesClienteModule } from 'src/app/core/components/sidebars/direcciones-cliente/direcciones-cliente.module';
import { ContactosClienteModule } from 'src/app/core/components/sidebars/contactos-cliente/contactos-cliente.module';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService } from 'src/app/shared/shared';


@NgModule({
  declarations: [
    ClienteUpdateComponent
  ],
  imports: [
    
    CommonModule,
    ClienteUpdateRoutingModule,
    MaestrosPrimeNgModule,
    FormsModule,
    ReactiveFormsModule,
    DireccionesClienteModule,
    ContactosClienteModule
  ],
  providers:[
    MessageService,
    AlertService,
    ConfirmationService,
    CustomErrorService,
  ]
})
export class ClienteUpdateModule { }
