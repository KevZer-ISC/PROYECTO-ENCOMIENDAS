import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Table } from 'primeng/table';
import { interval, Subscription } from 'rxjs';
import { ICliente } from 'src/app/core/interfaces/maestros/ICliente.interface';
import { ClienteService } from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService } from 'src/app/shared/shared';

@Component({
  selector: 'app-tabla-cliente',
  templateUrl: './tabla-cliente.component.html',
  styleUrls:['./tabla-cliente.component.css']
})
export class TablaClienteComponent implements OnInit, OnDestroy {
  loadingTable: boolean = false;
  isLoading:boolean = false;
  private _idCliente: number;
  clientes: ICliente[];

  counterValue: number = 0;

  clienteSuscriber: Subscription;
  private subscription: Subscription = new Subscription();


  items: MenuItem[] = [
    {
      label: 'Actualizar',
      icon: 'pi pi-refresh',
      command: () => {
        this.update();
      },
    },
    {
      label: 'Eliminar',
      icon: 'pi pi-times',
      command: () => {
        this.delete();
      },
    },
    {
      label: 'Mas información',
      icon: 'pi pi-info',
      command: () => {
        this.info();
      },
    },
  ];

  constructor(
    private readonly clienteService: ClienteService,
    private readonly customErrorService: CustomErrorService,
    private readonly router: Router,
    private readonly alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadClientes();
  }

  cargar(id: number) {
    this._idCliente = id;
  }

  update() {
    this.router.navigate([
      `/dashboard/maestros/cliente/cliente-update/${this._idCliente}`,
    ]);
  }

  delete() {
    this.subscription.add(
      this.clienteService.deleteClienteService$(this._idCliente).subscribe({
        next:(res)=>{
          this.isLoading=true;
          this.loadClientes();
         
        },
        error:(err)=>{
        
        },
        complete:()=>{
          this.isLoading = false;
        }
      })
    )
   
  }

  info() {
    console.log(`Informe del cliente ${this._idCliente}`);
  }

  loadClientes(): void {
    this.clienteSuscriber = this.clienteService
      .listarClienteService$()
      .subscribe({
        next: (res: ICliente[]) => {
          this.isLoading = true;
          this.clientes = res;
        },
        error: (error) => {
          this.customErrorService.listError(error);
          this.alertService.showError(
            'ERROR',
            'Verifique su conexion a internet o contacte al administrador'
          );
        },
        complete:()=>{
          this.isLoading= false;
        }
      });
  }

  clear(table: Table) {
    table.clear();
  }

  getSeverity(status: boolean) {
    switch (status) {
      case true:
        return 'success';
      case false:
        return 'danger';
      default:
        return 'warn';
    }
  }

  ngOnDestroy(): void {
    this.clienteSuscriber.unsubscribe();
  }
}
