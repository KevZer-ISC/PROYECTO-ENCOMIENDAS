import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { IAgency, IDepartamento } from 'src/app/core/interfaces/interfaces';
import {
  AgenciaService,
  DepartamentoService,
} from 'src/app/services/service.root';
import { CustomErrorService } from 'src/app/shared/shared';

@Component({
  selector: 'app-buscar-cliente',
  templateUrl: './buscar-cliente.component.html',
})
export class BuscarClienteComponent implements OnInit {
  subscriber: Subscription;
  departamentos: IDepartamento[];
  agencias: IAgency[];

  constructor(
    private readonly customErrorService: CustomErrorService,
    private readonly departamentoService: DepartamentoService,
    private readonly agenciaService: AgenciaService
  ) {}

  ngOnInit(): void {
    this.loadAgencia();
    this.loadDepartamento();
  }

  loadDepartamento() {
    this.departamentoService.listarDepartamentosService$().subscribe({
      next: (res: IDepartamento[]) => {
        this.departamentos = res;
      },
      error: (error) => this.customErrorService.listError(error),
    });
  }

  loadAgencia() {
    this.agenciaService.listarAgenciaService$().subscribe({
      next: (res: IAgency[]) => {
        this.agencias = res;
      },
      error: (error) => this.customErrorService.listError(error),
    });
  }

  ngOnDestroy(): void {
    if (this.subscriber) {
      this.subscriber.unsubscribe();
    }
  }
}
