import { Component } from '@angular/core';

@Component({
  selector: 'app-vehiculo',
  templateUrl: './vehiculo.component.html',
  styleUrls: ['./vehiculo.component.css']
})
export class VehiculoComponent {
  vechiculos:any[] = []
  first = 0;

  rows = 10;
  ngOnInit(): void {}

  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  pageChange(event: any) {
    this.first = event.first;
    this.rows = event.rows;
  }

  isLastPage(): boolean {
    return this.vechiculos ? this.first === this.vechiculos.length - this.rows : true;
  }

  isFirstPage(): boolean {
    return this.vechiculos ? this.first === 0 : true;
  }
}
