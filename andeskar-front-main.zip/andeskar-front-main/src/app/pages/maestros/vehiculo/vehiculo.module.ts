import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VehiculoRoutingModule } from './vehiculo-routing.module';
import { VehiculoComponent } from './vehiculo.component';
import { MaestrosPrimeNgModule } from 'src/app/core/themes/modules/maestros/maestros_primeng.module';


@NgModule({
  declarations: [
    VehiculoComponent
  ],
  imports: [
    CommonModule,
    VehiculoRoutingModule,
    MaestrosPrimeNgModule
  ]
})
export class VehiculoModule { }
