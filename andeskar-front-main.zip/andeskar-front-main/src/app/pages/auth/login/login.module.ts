import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthPrimengModule } from 'src/app/core/themes/modules/modules';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { ValidatorsService } from 'src/app/shared/validators/validators.service';
import { AuthService } from 'src/app/services/auth/auth.service';
import { AgenciaService } from 'src/app/services/agencia/agencia.service';
import { AuthCookieService } from 'src/app/core/service/cookie/cookie.service';
import { MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';

@NgModule({
  declarations: [LoginComponent],
  imports: [
    CommonModule,
    LoginRoutingModule,
    AuthPrimengModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers:[
    MessageService,
    AlertService,
    CustomErrorService,
    ValidatorsService,
    AuthService,
    AgenciaService,
    AuthCookieService
  ]
})
export class LoginModule {}
