import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { debounceTime, distinctUntilChanged } from 'rxjs';

import { IAgency, IAuth } from 'src/app/core/interfaces/interfaces';
import { AuthCookieService } from 'src/app/core/service/service.core';
import { AgenciaService, AuthService } from 'src/app/services/service.root';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  private _idAgencia!: number;
  agencias: IAgency[] = [];

  loginForm: FormGroup = this.fb.group({
    documento: ['', [Validators.required]],
    contraseña: ['', [Validators.required]],
  });


  constructor(
    private fb: FormBuilder,
    private readonly agenciaService: AgenciaService,
    private readonly customErrorService: CustomErrorService,
    private readonly validatorService: ValidatorsService,
    private readonly authService: AuthService,
    private authCookieServie: AuthCookieService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.onDocumentChange();
  }

  onDocumentChange(): void {
    this.loginForm
      .get('documento')
      ?.valueChanges.pipe(
        debounceTime(300), // espera 300ms después del último evento antes de ejecutar la solicitud
        distinctUntilChanged() // solo ejecuta si el valor ha cambiado
      )
      .subscribe((documento) => {
        if (documento) {
          this.agenciaService
            .listarAgenciaByDocTrabajadorService$(documento)
            .subscribe({
              next: (res: IAgency[]) => {
                this.agencias = res;
              },
              error: (error) => this.customErrorService.listError(error),
            });
        } else {
          this.agencias = [];
        }
      });
  }

  onAgenciaSelect(event: any) {
    let id = event.value.idAgencia;
    return (this._idAgencia = id);
  }

  login() {
    let data = {
      ...this.loginForm.value,
      idAgencia: this._idAgencia,
    };

    if (this.loginForm.invalid) return;

    this.authService.loginService$(data).subscribe({
      next: (res: IAuth) => {
        this.authCookieServie.setToken(res.token);

        let params = {
          idUsuario: res.idUsuario,
          nombre_Completo: res.nombre_Completo,
          genero: res.genero,
          documentoIdentidad: res.documentoIdentidad,
          agencia: res.agencia,
          perfil: res.perfil,
        };

        this.router.navigate(['/dashboard']);
      },
      error: (error) => this.customErrorService.listError(error),
    });
  }

  logout() {
    this.authService.logoutService$();
  }
}
