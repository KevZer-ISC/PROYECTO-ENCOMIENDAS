import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'nueva-orden', loadChildren:()=>import('./new-orden/new-orden.module').then(m=>m.NewOrdenModule)},
  {path:'orden-servicio', loadChildren:()=>import('./orden-servicio/orden-servicio.module').then(m=>m.OrdenServicioModule)},
  {path:'guia-transportista', loadChildren:()=>import('./guia-transportista/guia-transportista.module').then(m=>m.GuiaTransportistaModule)},


  {path:'traslado', loadChildren:()=>import('./traslado/traslado.module').then(m=>m.TrasladoModule)},



  {path:'cliente-no-deseado', loadChildren:()=>import('./cliente-no-deseado/cliente-no-deseado.module').then(m=>m.ClienteNoDeseadoModule)},



  {path:'guia-remitente', loadChildren:()=>import('./guia-remitente/guia-remitente.module').then(m=>m.GuiaRemitenteModule)},
  {path:'constancia-pesos', loadChildren:()=>import('./constancia-pesos/constancia-pesos.module').then(m=>m.ConstanciaPesosModule)},
  {path:'desembarque', loadChildren:()=>import('./desembarque/desembarque.module').then(m=>m.DesembarqueModule)},
  {path:'reparto', loadChildren:()=>import('./reparto/reparto.module').then(m=>m.RepartoModule)},
  {path:'entrega-reparto', loadChildren:()=>import('./entrega-reparto/entrega-reparto.module').then(m=>m.EntregaRepartoModule)},
  {path:'rendicion-gastos', loadChildren:()=>import('./rendicion-gastos/rendicion-gastos.module').then(m=>m.RendicionGastosModule)},
  {path:'vales-pago', loadChildren:()=>import('./vales-pago/vales-pago.module').then(m=>m.ValesPagoModule)},
  {path:'inventario-ev', loadChildren:()=>import('./inventario-ev/inventario-ev.module').then(m=>m.InventarioEvModule)},
  {path:'incidencias', loadChildren:()=>import('./incidencias/incidencias.module').then(m=>m.IncidenciasModule)},
  {path:'reportes', loadChildren:()=>import('./reportes/reportes.module').then(m=>m.ReportesModule)},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OperacionesRoutingModule { }
