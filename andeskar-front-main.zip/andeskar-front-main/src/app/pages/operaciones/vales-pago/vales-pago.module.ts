import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ValesPagoRoutingModule } from './vales-pago-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ValesPagoRoutingModule
  ]
})
export class ValesPagoModule { }
