import { Component, OnInit } from '@angular/core';
import { Table } from 'primeng/table';
import { CORDEN_SERVICIO } from 'src/app/core/constants/operaciones/COrdenServicio.contant';
import { IOrdenServicio } from 'src/app/core/interfaces/operaciones/IOrdenServicio.interface';

@Component({
  selector: 'app-orden-servicio',
  templateUrl: './orden-servicio.component.html',
  styleUrls: ['./orden-servicio.component.css'],
})
export class OrdenServicioComponent implements OnInit {
  orden: IOrdenServicio[] = CORDEN_SERVICIO;

  first = 0;

  rows = 10;
  ngOnInit(): void {}

  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  pageChange(event: any) {
    this.first = event.first;
    this.rows = event.rows;
  }

  isLastPage(): boolean {
    return this.orden ? this.first === this.orden.length - this.rows : true;
  }

  isFirstPage(): boolean {
    return this.orden ? this.first === 0 : true;
  }
}
