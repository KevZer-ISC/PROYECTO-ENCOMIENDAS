import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrdenServicioComponent } from './orden-servicio.component';

const routes: Routes = [
  {
    path:'', component: OrdenServicioComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrdenServicioRoutingModule { }
