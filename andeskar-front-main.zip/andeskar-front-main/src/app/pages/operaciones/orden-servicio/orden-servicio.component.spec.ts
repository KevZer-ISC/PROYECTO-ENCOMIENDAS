import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdenServicioComponent } from './orden-servicio.component';

describe('OrdenServicioComponent', () => {
  let component: OrdenServicioComponent;
  let fixture: ComponentFixture<OrdenServicioComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OrdenServicioComponent]
    });
    fixture = TestBed.createComponent(OrdenServicioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
