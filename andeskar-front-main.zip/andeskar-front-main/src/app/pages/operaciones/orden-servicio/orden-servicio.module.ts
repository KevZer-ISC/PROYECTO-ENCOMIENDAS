import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrdenServicioRoutingModule } from './orden-servicio-routing.module';
import { OrdenServicioComponent } from './orden-servicio.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/operaciones/operaciones_primeng.module';



@NgModule({
  declarations: [
    OrdenServicioComponent
  ],
  imports: [
    CommonModule,
    OrdenServicioRoutingModule,
    OperacionesPrimeNgModule
  ]
})
export class OrdenServicioModule { }
