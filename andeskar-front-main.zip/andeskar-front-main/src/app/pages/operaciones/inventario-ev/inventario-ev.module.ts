import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventarioEvRoutingModule } from './inventario-ev-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InventarioEvRoutingModule
  ]
})
export class InventarioEvModule { }
