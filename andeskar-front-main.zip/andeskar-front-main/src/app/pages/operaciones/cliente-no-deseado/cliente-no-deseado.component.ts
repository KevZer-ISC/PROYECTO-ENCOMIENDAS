import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import {
  IClienteNoDeseado,
  ITypeDocument,
} from 'src/app/core/interfaces/interfaces';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { ClienteNoDeseadoService } from 'src/app/services/cliente-no-deseado/cliente-no-deseado.service';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { ReactiveValidatorsService } from 'src/app/shared/validators/reactive-validators.service';

@Component({
  selector: 'app-cliente-no-deseado',
  templateUrl: './cliente-no-deseado.component.html',
  styleUrls: ['./cliente-no-deseado.component.css'],
})
export class ClienteNoDeseadoComponent implements OnInit, OnDestroy {

  /**
   * Subscripciones para cada evento realizado
   */
  private docSubscriber: Subscription;
  private searchSubscriber: Subscription;

  /**
   * Tipos para los componentes en el html
   */
  tipoDocumento: ITypeDocument[] = [];
  clienteNoDeseado: IClienteNoDeseado;
  nulleableClient: IClienteNoDeseado;

  /**
   * Boleanos para manejar la visibilidad de la informacionm, formularios y cards
   */
  showCardClienteNoDeseado = false;
  showNuevoClienteNoDeseado = false;
  isLoading: boolean = false;

  /**
   * Id para validar cada campo del formulario ingresado de acuerdo al tipo de documento
   */
  private _idDocumento: number;


  /**
   * Inicio del Formulario Reactivo
   */
  noDeseadoForm: FormGroup = this.fb.group({
    tipoDocumento: [''],
    documento: ['', [Validators.required]],
  });

  /**
   * Inyeccion de Dependencias
   * 
   * @param tipoDocumentoService Inyecta la clase de tipo de documeento
   * @param customErrorService Inyecta la clase para controlar los errores
   * @param fb Inyecta el uso del formulario reactivo
   * @param reactiveValidators Inyecta los validadores reactivos
   * @param clienteNoDeseadoService Inyecta los servicios para hacer peticiones API
   * @param alertService Inyecta las Alertas para cada situacion del componente
   */
  constructor(
    private readonly tipoDocumentoService: TipoDocumentoService,
    private readonly customErrorService: CustomErrorService,
    private readonly fb: FormBuilder,
    private reactiveValidators: ReactiveValidatorsService,
    private clienteNoDeseadoService: ClienteNoDeseadoService,
    private alertService: AlertService
  ) {}


  ngOnInit(): void {
    /**
     * Inicializa el tipo de documento guardandolo en una variable de subscripcion
     */
    this.docSubscriber = this.tipoDocumentoService
      .listarTipoDocumentoService$()
      .subscribe({
        next: (res: ITypeDocument[]) => {
          this.tipoDocumento = res;
        },
        error: (error) => this.customErrorService.listError(error),
      });
  }

  /**
   * Por cada seleccion se envie tanto el documento completo como el id para poder validarlo en el servicio reactivo
   * @param event Trae toda la informacion revenate del evento en donde solo queremos el idTipoDocumento
   * @returns el id seleccionado es el documento
   */
  onDocumentSelect(event: any):number {
    let id = event.value.idTipoDocumento;
    this.reactiveValidators.updateValidators(this.noDeseadoForm, id);
    return (this._idDocumento = id);
  }

  /**
   * Validara el formulario de acuerdo a las clases de validaciones
   * Luego desestructurara a el fromulario para obtener el ID
   * El id se cargara a un objeto 
   * Luego ese objeto se enviara por el metodo del serivicio subscribiendose a los cambios
   * EXITO: Hallo un cliente y lo muestra
   * ERROR: No hallo un cliente, hace que la variable del cliente no deseado sea null y la muestra
   * @returns 
   */
  findUnwantedClient() {
    if (this.noDeseadoForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const {tipoDocumento: { idTipoDocumento },...resto} = this.noDeseadoForm.value;

    const findClient = {...resto, idTipoDocumento: idTipoDocumento, estado: 1};

    this.searchSubscriber = this.clienteNoDeseadoService
      .obtenerClienteByDocumentoService$(findClient)
      .subscribe({
        next: (res: IClienteNoDeseado) => {
          this.clienteNoDeseado = res;
          this.showCardClienteNoDeseado = true;
          this.showNuevoClienteNoDeseado = false;
        },
        error: (error) => {
          this.clienteNoDeseado = this.nulleableClient;
          this.showCardClienteNoDeseado = true;
          this.showNuevoClienteNoDeseado = false;
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  /**
   * Cuando se de click al boton de nuevo pero desde el padre
   */
  changeVisibilityNew():void {
    this.showNuevoClienteNoDeseado = true;
    this.showCardClienteNoDeseado = false;
  }

  /**
   * Cuando se de click al boton de nuevo cliente no deseado pero desde la card
   */
  onButtonClick():void {
    this.showCardClienteNoDeseado = false;
    this.showNuevoClienteNoDeseado = true;
  }

  /**
   * Destruccion de las subscripciones cuando el componente se destruya
   */
  ngOnDestroy(): void {
    if (this.docSubscriber) {
      this.docSubscriber.unsubscribe();
    }
    if (this.searchSubscriber) {
      this.searchSubscriber.unsubscribe();
    }
  }
}
