import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClienteNoDeseadoRoutingModule } from './cliente-no-deseado-routing.module';
import { ClienteNoDeseadoComponent } from './cliente-no-deseado.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { NuevoClienteNoDeseadoComponent } from './nuevo-cliente-no-deseado/nuevo-cliente-no-deseado.component';
import { CardClienteNoDeseadoComponent } from './card-cliente-no-deseado/card-cliente-no-deseado.component';
import { MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ClienteNoDeseadoComponent,
    NuevoClienteNoDeseadoComponent,
    CardClienteNoDeseadoComponent
  ],
  imports: [
    CommonModule,
    ClienteNoDeseadoRoutingModule,
    OperacionesPrimeNgModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:[MessageService,AlertService]
})
export class ClienteNoDeseadoModule { }
