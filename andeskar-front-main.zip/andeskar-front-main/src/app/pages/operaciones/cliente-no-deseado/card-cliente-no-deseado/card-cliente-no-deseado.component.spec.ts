import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardClienteNoDeseadoComponent } from './card-cliente-no-deseado.component';

describe('CardClienteNoDeseadoComponent', () => {
  let component: CardClienteNoDeseadoComponent;
  let fixture: ComponentFixture<CardClienteNoDeseadoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardClienteNoDeseadoComponent]
    });
    fixture = TestBed.createComponent(CardClienteNoDeseadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
