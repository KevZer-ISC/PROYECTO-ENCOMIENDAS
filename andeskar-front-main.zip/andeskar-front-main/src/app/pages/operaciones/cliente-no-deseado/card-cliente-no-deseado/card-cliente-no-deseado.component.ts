import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IClienteNoDeseado } from 'src/app/core/interfaces/interfaces';

@Component({
  selector: 'app-card-cliente-no-deseado',
  templateUrl: './card-cliente-no-deseado.component.html',
  styleUrls: ['./card-cliente-no-deseado.component.css']
})
export class CardClienteNoDeseadoComponent {
  @Input() clienteNoDeseado?:IClienteNoDeseado;
  @Output() buttonClick = new EventEmitter<void>();

  onButtonClick() {
    this.buttonClick.emit();
  }
}
