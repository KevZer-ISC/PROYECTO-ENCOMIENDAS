import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClienteNoDeseadoComponent } from './cliente-no-deseado.component';

const routes: Routes = [
  {path:'', component: ClienteNoDeseadoComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClienteNoDeseadoRoutingModule { }
