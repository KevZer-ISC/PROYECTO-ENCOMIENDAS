import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ITypeDocument } from 'src/app/core/interfaces/interfaces';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { ClienteNoDeseadoService } from 'src/app/services/cliente-no-deseado/cliente-no-deseado.service';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { ReactiveValidatorsService } from 'src/app/shared/validators/reactive-validators.service';

@Component({
  selector: 'app-nuevo-cliente-no-deseado',
  templateUrl: './nuevo-cliente-no-deseado.component.html',
  styleUrls: ['./nuevo-cliente-no-deseado.component.css'],
})
export class NuevoClienteNoDeseadoComponent implements OnInit, OnDestroy {

  /**
   * Unica variable para el manejo multiple de subscripciones
   */
  private subsciptionGenerally: Subscription = new Subscription();

  /**
   * Variable para manejar las clases en el componente
   */
  tipoDocumento: ITypeDocument[] = [];
  
  /**
   * Variable para guardar el id del documento y para ayudar a las validaciones reactivas
   */
  private _idDocumento: number;

  /**
   * Variable para manejar el estado del snipper de carga
   */
  isLoading:boolean = false;

  /**
   * Formulario para agregar los No Deseados
   */
  clientUnwantedForm: FormGroup = this.fb.group({
    documento: [''],
    nombre: [''],
    tipoDocumento: [''],
    observacion: ['',[Validators.required, Validators.minLength(1), Validators.maxLength(355)],],
  });

  /**
   * Inyeccion de dependencias
   * @param fb 
   * @param tipoDocumentoService 
   * @param customErrorService 
   * @param reactiveValidators 
   * @param clienteNoDeseadoService 
   * @param alertService 
   */
  constructor(
    private readonly fb: FormBuilder,
    private readonly tipoDocumentoService: TipoDocumentoService,
    private readonly customErrorService: CustomErrorService,
    private reactiveValidators: ReactiveValidatorsService,
    private readonly clienteNoDeseadoService:ClienteNoDeseadoService,
    private alertService:AlertService
  ) {}

  ngOnInit(): void {
    this.subsciptionGenerally.add(
      this.tipoDocumentoService.listarTipoDocumentoService$().subscribe({
        next: (res: ITypeDocument[]) => {
          this.tipoDocumento = res;
        },
        error: (error) => this.customErrorService.listError(error),
      })
    );
  }

  /**
   * Por cada seleccion se envie tanto el documento completo como el id para poder validarlo en el servicio reactivo
   * @param event Trae toda la informacion revenate del evento en donde solo queremos el idTipoDocumento
   * @returns el id seleccionado es el documento
   */
  onDocumentSelect(event: any) {
    let id = event.value.idTipoDocumento;
    this.reactiveValidators.updateValidators(this.clientUnwantedForm, id);
    return (this._idDocumento = id);
  }

  /**
   * Verificara que el formulario este valido de acuerdo a la clase de validaciones
   * Luego desestructurara el objeto del formulario para extraer solo el idTipoDocumento
   * Luego se enviara al servicio para poder registrarlo
   * EXITO: Mostrara un mensaje con exito y se limpiara el formulario
   * ERROR: Mostrara un mensaje de error y no se limpiara el formulario
   * @returns 
   */
  insertUnwantedClient() {
    if(this.clientUnwantedForm.invalid){
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const {
      tipoDocumento: { idTipoDocumento },
      ...resto
    } = this.clientUnwantedForm.value;

    const newUnwanted = {
      ...resto,
      idtipoDocumento: idTipoDocumento,
    };


    this.subsciptionGenerally.add(
      this.clienteNoDeseadoService.insertClienteNoDeseadoService$(newUnwanted).subscribe({
        next:(res)=>{
          this.isLoading = true;
          this.alertService.showSuccess('Exito', 'Cliente No Deseado Agregado Correctamente');
          this.clientUnwantedForm.reset();
        },
        error:(error)=>{
          this.alertService.showError('Upss..!!', 'Algo Fallo al agregar el cliente, contacte con el administrador');
        },
        complete:()=>{
          this.isLoading = false;
        }
      })
    )
  }


  /**
   * Desuscribe las subscripciones al destruirse el componente
   */
  ngOnDestroy(): void {
      this.subsciptionGenerally.unsubscribe();
  }
}
