import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoClienteNoDeseadoComponent } from './nuevo-cliente-no-deseado.component';

describe('NuevoClienteNoDeseadoComponent', () => {
  let component: NuevoClienteNoDeseadoComponent;
  let fixture: ComponentFixture<NuevoClienteNoDeseadoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NuevoClienteNoDeseadoComponent]
    });
    fixture = TestBed.createComponent(NuevoClienteNoDeseadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
