import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuiaRemitenteRoutingModule } from './guia-remitente-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GuiaRemitenteRoutingModule
  ]
})
export class GuiaRemitenteModule { }
