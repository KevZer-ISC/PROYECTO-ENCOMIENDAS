import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RendicionGastosRoutingModule } from './rendicion-gastos-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RendicionGastosRoutingModule
  ]
})
export class RendicionGastosModule { }
