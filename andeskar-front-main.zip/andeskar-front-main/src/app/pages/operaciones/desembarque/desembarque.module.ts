import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DesembarqueRoutingModule } from './desembarque-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DesembarqueRoutingModule
  ]
})
export class DesembarqueModule { }
