import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CalculatorOrderService } from 'src/app/core/service/calculator/calculator-order.service';

@Component({
  selector: 'app-nuevo-item',
  templateUrl: './nuevo-item.component.html',
  styleUrls: ['./nuevo-item.component.css'],
})
export class NuevoItemComponent implements OnInit {
  wasItemCancelled: boolean = false;
  wasItemSaved: boolean = false;
  isLoading: boolean = false;

  constructor(
    private readonly fb: FormBuilder,
    private calculatorOrderService: CalculatorOrderService
  ) {}

  itemsList: any[] = [];

  @Output() itemsOrderEmit: EventEmitter<any[]> = new EventEmitter<any[]>();

  itemForm: FormGroup = this.fb.group({
    unidad: [, [Validators.required]],
    nroBultos: [, [Validators.required]],
    peso: [, [Validators.required]],
    precioUnitario: [, [Validators.required]],
    descuento: [, [Validators.required]],
    descripcion: [, [Validators.required]],
  });

  ngOnInit(): void {}

  registrar() {
    //if(this.itemForm.invalid) return;

    //TODO: Corregir, esto no se debe hacer: usar metodo spreed
    this.itemsList.push(this.itemForm.value);
    this.itemsOrderEmit.emit(this.itemsList);

    // this.calculatorOrderService.calculateTotalsOrders(this.itemForm.value)

    // this.itemForm.reset();
  }
  cancel() {}

  save() {}
}
