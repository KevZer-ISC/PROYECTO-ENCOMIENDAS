import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { IAgency } from 'src/app/core/interfaces/interfaces';
import { AlertService } from 'src/app/shared/components/alert.service';
import { ValidatorsService } from 'src/app/shared/shared';

@Component({
  selector: 'app-new-orden',
  templateUrl: './new-orden.component.html',
  styleUrls: ['./new-orden.component.css'],
})
export class NewOrdenComponent implements OnInit {
  //**Seccion de elementos privados para la seleccion de dropdowns */
  private _idsClientContact: number[] = [];

  //**Seccion de ngIf */
  isNewDetail: boolean = false;
  hasnewClient: boolean = false;
  hasPersonContat: boolean = false;
  isContactSidebarVisible: boolean = false;
  isDirectionSidebarVisible: boolean = false;
  isVisibleCardDetail: boolean = false;
  isVisibleCardService: boolean = false;

  itemsOrder: any[] = [];
  idSenderEmited: number = 0;
  idConsignedEmited: number = 0;

  orderForm: FormGroup;

  directionForm: FormGroup;
  contactForm: FormGroup;
  directionsSubmited: any[] = [];
  contactsSubmited: any[] = [];

  personPayment: any[] = [];
  isLoading: boolean = false;

  // agency: IAgency[] = [
  //   {
  //     idAgencia: 1,
  //     nombreAgencia: 'Lima',
  //     horarioInicio: '06:00 a.m.',
  //     horarioTermino: '10:00 p.m.',
  //     fK_EstadoAgencia: 1,
  //     fechaCreacion: '0001-01-01T00:00:00',
  //     usuarioCreacion: 0,
  //     usuarioUltimaModificacion: 0,
  //     activo: false,
  //   },
  // ];

  constructor(
    private readonly fb: FormBuilder,
    private alertService: AlertService,
    private validatorsService: ValidatorsService
  ) {
    this.orderForm = this.fb.group({
      cabecera: this.fb.group({
        origen: ['', [Validators.required]],
        destino: ['', [Validators.required]],
        tipoServicio: ['', [Validators.required]],
        tipoRecepcion: ['', [Validators.required]],
        tipoEntrega: ['', [Validators.required]],
        direccionRecepcion: ['', []],
        direccionEntrega: ['', []],
      }),
      remitente: [''],
      consignado: [''],
      detalleCarga: this.fb.group({}),
      pago: this.fb.group({
        pagador: ['', []],
        formaPago: ['', []],
      }),
    });
    this.directionForm = this.fb.group({
      direcciones: this.fb.array([this.createDirection()]),
    });

    this.contactForm = fb.group({
      contactos: fb.array([this.createContacts()]),
    });
  }

  ngOnInit(): void {}

  selectedNewClient() {
    this.hasnewClient = !this.hasnewClient;
  }

  get headboardForm(): FormGroup {
    return this.orderForm.get('cabecera') as FormGroup;
  }

  get detailChargedForm(): FormGroup {
    return this.orderForm.get('detalleCarga') as FormGroup;
  }

  get paymentForm(): FormGroup {
    return this.orderForm.get('pago') as FormGroup;
  }

  get directions(): FormArray {
    return this.directionForm.get('direcciones') as FormArray;
  }

  get contacts(): FormArray {
    return this.contactForm.get('contactos') as FormArray;
  }

  /**
   * SIDEBARS
   * @returns
   */
  createDirection(): FormGroup {
    return this.fb.group({
      direccion: [
        '',
        [Validators.required, this.validatorsService.validateAddress],
      ],
    });
  }

  createContacts(): FormGroup {
    return this.fb.group({
      documento: [
        '',
        [Validators.required, this.validatorsService.validateForeignerCard],
      ],
      nombre: [
        '',
        [Validators.required, this.validatorsService.validateFullname],
      ],
      telefono: [
        '',
        [Validators.required, this.validatorsService.validatePhone],
      ],
    });
  }

  generateMoreDirections(): void {
    this.directions.push(this.createDirection());
  }

  generateMoreContacts(): void {
    this.contacts.push(this.createContacts());
  }

  removeDireccion(index: number): void {
    this.directions.removeAt(index);
  }

  removeContacts(index: number): void {
    this.contacts.removeAt(index);
  }

  /**
   * EMISIONES
   */
  contactoSidebarEmited() {
    this.isContactSidebarVisible = !this.isContactSidebarVisible;
  }

  directionSidebarEmited() {
    this.isDirectionSidebarVisible = !this.isDirectionSidebarVisible;
  }

  // Método que contiene el id del remitente
  getIdSenderEmited(event: any) {
    this.paymentForm.reset();
    this.idSenderEmited = event;

    this.orderForm.patchValue({ remitente: this.idSenderEmited });

    // Buscar el índice del objeto con pagador 'Remitente'
    const index = this.personPayment.findIndex(
      (payment) => payment.pagador === 'Remitente'
    );

    // Si el objeto existe, actualizar su idCliente, de lo contrario, agregar un nuevo objeto
    if (index !== -1) {
      this.personPayment[index].idCliente = this.idSenderEmited;
    } else {
      const newPayment = {
        idCliente: this.idSenderEmited,
        pagador: 'Remitente',
      };
      this.personPayment = [...this.personPayment, newPayment];
    }
  }

  // Método que contiene el id del consignado
  getIdConsignedEmited(event: any) {
    this.paymentForm.reset();

    this.idConsignedEmited = event;
    this.orderForm.patchValue({ consignado: this.idConsignedEmited });

    // Buscar el índice del objeto con pagador 'Consignado'
    const index = this.personPayment.findIndex(
      (payment) => payment.pagador === 'Destinatario'
    );

    // Si el objeto existe, actualizar su idCliente, de lo contrario, agregar un nuevo objeto
    if (index !== -1) {
      this.personPayment[index].idCliente = this.idConsignedEmited;
    } else {
      const newPayment = {
        idCliente: this.idConsignedEmited,
        pagador: 'Destinatario',
      };
      this.personPayment = [...this.personPayment, newPayment];
    }
  }

  hasPersonaContactEmited() {
    this.hasPersonContat = !this.hasPersonContat;
  }

  arrayIdClientsEmited(event: any) {
    this._idsClientContact = event;
  }

  itemsOrderEmited(event: any) {
    console.log(event);
    this.itemsOrder = event;

    //TODO: ACA ME QUEDE EN EL TEMA DE CALCULAR EL TOTAL
  }

  newDetail() {
    this.isNewDetail = !this.isNewDetail;
  }

  showListDetailsOrder() {
    this.isVisibleCardDetail = !this.isVisibleCardDetail;
  }

  showServicesAdd() {
    this.isVisibleCardService = !this.isVisibleCardService;
  }

  /**
   * Este mensaje sucede para emitir si el cliente se creo correctamente o no
   * @param isSuccess Es el parametro de entrada
   */
  messageEmited(isSuccess: boolean) {
    if (isSuccess) {
      this.alertService.showSuccess('Exito!!', 'Cliente Creado Exitosamente');
      this.selectedNewClient();
      this.directionForm.reset({
        direcciones: this.fb.array([this.createDirection()]),
      });
      this.contactForm.reset({
        contactos: this.fb.array([this.createContacts()]),
      });
    } else {
      this.alertService.showError(
        'Error',
        'Ups!!.. Sucedio algo al crear el Cliente'
      );
      this.selectedNewClient();
    }
  }

  /**
   * REGISTRO
   * @returns
   */
  submitFormDirections(): void {
    if (this.directionForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const direccionesArray = this.directionForm.value.direcciones.map(
      (direccion: any) => ({
        idDireccion: 0,
        idCliente: 0,
        direccion: direccion.direccion,
      })
    );

    this.directionsSubmited = direccionesArray;
    this.isDirectionSidebarVisible = !this.isDirectionSidebarVisible;
  }

  submitFormContacts() {
    const contactsArray = this.contactForm.value.contactos.map(
      (contacto: any) => ({
        idContacto: 0,
        idCliente: 0,
        documento: contacto.documento,
        nombre: contacto.nombre,
        telefono: contacto.telefono,
      })
    );

    if (this.contactForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    this.contactsSubmited = contactsArray;
    this.isContactSidebarVisible = !this.isContactSidebarVisible;
  }

  createNewOrder() {
    // if (this.orderForm.invalid) {
    //   this.alertService.showWarn(
    //     'Alerta!!',
    //     'Verifique que los datos esten correctos'
    //   );
    //   return;
    // }

    let data = {
      ...this.orderForm.value,
      idpersonaContacto: this._idsClientContact,
    };

    console.log(data);
  }
}
