import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewOrdenComponent } from './new-orden.component';

const routes: Routes = [
  {path:'', component: NewOrdenComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewOrdenRoutingModule { }
