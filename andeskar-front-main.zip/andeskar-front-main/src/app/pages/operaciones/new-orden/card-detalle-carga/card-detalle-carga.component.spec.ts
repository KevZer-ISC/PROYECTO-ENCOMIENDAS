import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardDetalleCargaComponent } from './card-detalle-carga.component';

describe('CardDetalleCargaComponent', () => {
  let component: CardDetalleCargaComponent;
  let fixture: ComponentFixture<CardDetalleCargaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardDetalleCargaComponent]
    });
    fixture = TestBed.createComponent(CardDetalleCargaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
