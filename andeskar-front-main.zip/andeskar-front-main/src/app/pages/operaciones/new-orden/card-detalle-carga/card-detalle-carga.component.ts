import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-card-detalle-carga',
  templateUrl: './card-detalle-carga.component.html',
  styleUrls: ['./card-detalle-carga.component.css']
})
export class CardDetalleCargaComponent {
  isLoading: boolean = false;

  @Input() detailChargedForm:FormGroup = this.fb.group({})
  @Output() newChargeEmit:EventEmitter<void> = new EventEmitter<void>();

  
  constructor(private fb:FormBuilder){}

  showNewCharge() {
    this.newChargeEmit.emit();
  }
}
