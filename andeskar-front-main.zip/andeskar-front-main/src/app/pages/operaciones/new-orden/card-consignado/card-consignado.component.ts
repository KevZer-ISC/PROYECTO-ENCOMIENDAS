import {
  Component,
  ElementRef,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import { ITypeDocument, ICliente } from 'src/app/core/interfaces/interfaces';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { ClienteService } from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { ReactiveValidatorsService } from 'src/app/shared/validators/reactive-validators.service';

@Component({
  selector: 'app-card-consignado',
  templateUrl: './card-consignado.component.html',
  styleUrls: ['./card-consignado.component.css'],
})
export class CardConsignadoComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  consignedForm: FormGroup = this.fb.group({
    tipoDocumento: ['', [Validators.required]],
    documento: ['', [Validators.required]],
  });

  @Output() idConsignadoEmit: EventEmitter<number> = new EventEmitter<number>();
  @Output() hasPersonContatEmit: EventEmitter<void> = new EventEmitter<void>();

  @ViewChild('nombreDestinatarioInput') nombreDestinatarioInput: ElementRef;
  @ViewChild('direccionDestinatarioInput')
  direccionDestinatarioInput: ElementRef;
  isLoading: boolean = false;
  isPersonContact: boolean = false;

  //**Seccion de elementos privados para la seleccion de dropdowns */
  _idTypeDocConsigned: string;

  //**Seccion de combos o dropdowns */
  typeDocument: ITypeDocument[] = [];

  //**Objetos de las peticiones al servicio */
  consigned: ICliente;

  constructor(
    private clienteService: ClienteService,
    private readonly typeDocumentService: TipoDocumentoService,
    private fb: FormBuilder,
    private reactiveValidator: ReactiveValidatorsService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadTypeDocument();
  }

  loadTypeDocument() {
    this.subscription.add(
      this.typeDocumentService.listarTipoDocumentoService$().subscribe({
        next: (res: ITypeDocument[]) => {
          this.isLoading = true;
          this.typeDocument = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'Los documentos no cargaron correctamente. Contacte con el administrador'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  onDocConsignadoSelect({ value }: { value: any }) {
    this.reactiveValidator.updateValidators(
      this.consignedForm,
      value.idTipoDocumento
    );
    return (this._idTypeDocConsigned = value.idTipoDocumento);
  }

  searchClientByDocument() {
    if (this.consignedForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Antes de buscar complete los datos'
      );
      return;
    }

    const {
      tipoDocumento: { idTipoDocumento },
      documento,
    } = this.consignedForm.value;

    let data = {
      idTipoDocumento,
      documento,
      estado: 1,
    };

    this.subscription.add(
      this.clienteService.buscarClienteByDocService$(data).subscribe({
        next: (res: ICliente) => {
          this.isLoading = true;
          this.consigned = res;
          this.consigned
            ? (this.nombreDestinatarioInput.nativeElement.value = `${this.consigned.razonSocial}`)
            : (this.nombreDestinatarioInput.nativeElement.value = '');

          this.consigned
            ? (this.direccionDestinatarioInput.nativeElement.value =
                this.consigned.direccion)
            : (this.direccionDestinatarioInput.nativeElement.value = '');

          this.idConsignadoEmit.emit(this.consigned.id);
          if (data.idTipoDocumento == 2) {
            this.isPersonContact = true;
          }
        },
        error: (err) => {
          this.nombreDestinatarioInput.nativeElement.value = '';
          this.direccionDestinatarioInput.nativeElement.value = '';
          this.isPersonContact = false;

          const { error } = err;
          console.log(error);

          if (error.status == 500) {
            this.alertService.showError(
              'Ups..!!',
              'No se encontraron resultados'
            );
            return;
          }

          if (error.message) {
            this.alertService.showError('Ups..!!', error.message);
            return;
          }
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  personContactSelect() {
    this.hasPersonContatEmit.emit();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
