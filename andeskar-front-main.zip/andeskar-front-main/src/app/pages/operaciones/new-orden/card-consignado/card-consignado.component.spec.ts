import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardConsignadoComponent } from './card-consignado.component';

describe('CardConsignadoComponent', () => {
  let component: CardConsignadoComponent;
  let fixture: ComponentFixture<CardConsignadoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardConsignadoComponent]
    });
    fixture = TestBed.createComponent(CardConsignadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
