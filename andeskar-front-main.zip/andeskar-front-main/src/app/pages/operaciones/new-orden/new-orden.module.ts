import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewOrdenRoutingModule } from './new-orden-routing.module';
import { NewOrdenComponent } from './new-orden.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { SharedClienteModule } from 'src/app/core/components/cliente/shared-cliente.module';
import { AgenciaService, ClienteService } from 'src/app/services/service.root';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { NuevoItemComponent } from './nuevo-item/nuevo-item.component';
import { TipoServicioService } from 'src/app/services/tipo-servicio/tipo-servicio.service';
import { TipoPagoService } from 'src/app/services/tipo-pago/tipo-pago.service';
import { TipoEntregaService } from 'src/app/services/tipo-entrega/tipo-entrega.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedPersonaContactoModule } from 'src/app/core/components/persona-contacto/persona-contacto.module';
import { DateUtilService } from 'src/app/shared/utils/date-util.service';
import { CalculatorOrderService } from 'src/app/core/service/calculator/calculator-order.service';
import { CardCabeceraComponent } from './card-cabecera/card-cabecera.component';
import { CardRemitenteComponent } from './card-remitente/card-remitente.component';
import { CardConsignadoComponent } from './card-consignado/card-consignado.component';
import { CardDetalleCargaComponent } from './card-detalle-carga/card-detalle-carga.component';
import { CardPagoComponent } from './card-pago/card-pago.component';
import { ContactosClienteModule } from '../../../core/components/sidebars/contactos-cliente/contactos-cliente.module';
import { DireccionesClienteModule } from '../../../core/components/sidebars/direcciones-cliente/direcciones-cliente.module';
import { DetalleOrdenModule } from 'src/app/core/components/orden-servicio/detalle-orden/detalle-orden.module';
import { ServiciosAdicionalesModule } from 'src/app/core/components/orden-servicio/servicios-adicionales/servicios-adicionales.module';

@NgModule({
  declarations: [
    NewOrdenComponent,
    NuevoItemComponent,
    CardCabeceraComponent,
    CardRemitenteComponent,
    CardConsignadoComponent,
    CardDetalleCargaComponent,
    CardPagoComponent,
  ],
  imports: [
    CommonModule,
    NewOrdenRoutingModule,
    OperacionesPrimeNgModule,
    SharedClienteModule,
    SharedPersonaContactoModule,
    ReactiveFormsModule,
    FormsModule,
    ContactosClienteModule,
    DireccionesClienteModule,
    DetalleOrdenModule,
    ServiciosAdicionalesModule,
  ],
  providers: [
    ClienteService,
    CustomErrorService,
    AgenciaService,
    ValidatorsService,
    TipoDocumentoService,
    MessageService,
    AlertService,
    TipoServicioService,
    TipoPagoService,
    TipoEntregaService,
    DateUtilService,
    CalculatorOrderService,
  ],
})
export class NewOrdenModule {}
