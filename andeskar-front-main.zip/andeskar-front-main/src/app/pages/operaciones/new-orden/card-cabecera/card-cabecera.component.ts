import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import {
  IAgency,
  ITypeDelivery,
  ITypePayment,
  ITypeService,
} from 'src/app/core/interfaces/interfaces';
import {
  AgenciaService,
  TipoEntregaService,
  TipoServicioService,
} from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-card-cabecera',
  templateUrl: './card-cabecera.component.html',
  styleUrls: ['./card-cabecera.component.css'],
})
export class CardCabeceraComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  isLoading: boolean = false;

  @Input() headboardForm: FormGroup;

  //**Seccion de ngIf */
  isDeliverySelected: boolean = false;
  isReceptionSelected: boolean = false;

  //**Seccion de combos o dropdowns */
  agency: IAgency[];
  typePayment: ITypePayment[];
  typeService: ITypeService[];
  typeDelivery: ITypeDelivery[];
  defaultValue: any ={
    "idAgencia": 1,
    "nombreAgencia": "Lima",
    "horarioInicio": "06:00 a.m.",
    "horarioTermino": "10:00 p.m.",
    "fK_EstadoAgencia": 1,
    "fechaCreacion": "0001-01-01T00:00:00",
    "usuarioCreacion": 0,
    "usuarioUltimaModificacion": 0,
    "activo": false
};



  constructor(
    private readonly agencyService: AgenciaService,
    private readonly typeServService: TipoServicioService,
    private readonly typeDeliveryService: TipoEntregaService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadAgency();
    this.loadTypeService();
    this.loadTypeDelivery();

  }

  private loadAgency(): void {
    this.subscription.add(
      this.agencyService.listarAgenciaService$().subscribe({
        next: (res: IAgency[]) => {
          this.isLoading = true;
          this.agency = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'Las Agencias no pueden cargar. Contacte al administrador, para solucionar el problema'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  private loadTypeService(): void {
    this.subscription.add(
      this.typeServService.listaTipoServicioService$().subscribe({
        next: (res: ITypeService[]) => {
          this.isLoading = true;
          this.typeService = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'El Tipo de Servicio no puede cargar. Contacte al administrador, para solucionar el problema'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  private loadTypeDelivery(): void {
    this.subscription.add(
      this.typeDeliveryService.listarTipoEntregaService$().subscribe({
        next: (res: ITypeDelivery[]) => {
          this.isLoading = true;
          this.typeDelivery = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'El Tipo de Entrega no puede cargar. Contacte al administrador, para solucionar el problema'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  private checkIfSelected(value: any, flag: 'reception' | 'delivery'): void {
    const isSelected = value.id === 2;
    if (flag === 'reception') {
      this.isReceptionSelected = isSelected;
    } else if (flag === 'delivery') {
      this.isDeliverySelected = isSelected;
    }
  }

  // private updateAvailableOrigins() {
  //   if (this.agency) { // Verificación para evitar errores de undefined
  //     this.availableOrigins = this.agency.filter(
  //       (ag) => ag !== this.headboardForm.get('destino')?.value
  //     );
  //   }
  // }

  // private updateAvailableDestinations() {
  //   if (this.agency) { // Verificación para evitar errores de undefined
  //     this.availableDestinations = this.agency.filter(
  //       (ag) => ag !== this.headboardForm.get('origen')?.value
  //     );
  //   }
  // }




  // // En tu componente TS
  // get availableDestinations(): IAgency[] {
  //   return this.agency.filter(
  //     (ag) => ag !== this.headboardForm.get('origen')?.value
  //   );
  // }

  // get availableOrigins(): IAgency[] {
  //   return this.agency.filter(
  //     (ag) => ag !== this.headboardForm.get('destino')?.value
  //   );
  // }










  selectedTypeReception(event: any): void {
    this.checkIfSelected(event.value, 'reception');
  }

  selectedTypeDelivery(event: any): void {
    this.checkIfSelected(event.value, 'delivery');
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
