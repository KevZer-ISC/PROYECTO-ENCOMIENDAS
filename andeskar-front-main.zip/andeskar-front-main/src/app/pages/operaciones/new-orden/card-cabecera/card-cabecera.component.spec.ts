import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardCabeceraComponent } from './card-cabecera.component';

describe('CardCabeceraComponent', () => {
  let component: CardCabeceraComponent;
  let fixture: ComponentFixture<CardCabeceraComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardCabeceraComponent]
    });
    fixture = TestBed.createComponent(CardCabeceraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
