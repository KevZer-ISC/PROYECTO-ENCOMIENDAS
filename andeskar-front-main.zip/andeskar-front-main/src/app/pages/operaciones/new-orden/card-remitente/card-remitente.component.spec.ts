import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardRemitenteComponent } from './card-remitente.component';

describe('CardRemitenteComponent', () => {
  let component: CardRemitenteComponent;
  let fixture: ComponentFixture<CardRemitenteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardRemitenteComponent]
    });
    fixture = TestBed.createComponent(CardRemitenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
