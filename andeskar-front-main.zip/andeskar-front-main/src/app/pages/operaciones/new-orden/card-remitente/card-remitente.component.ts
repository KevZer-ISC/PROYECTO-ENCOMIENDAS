import {
  Component,
  ElementRef,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ICliente, ITypeDocument } from 'src/app/core/interfaces/interfaces';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import { ClienteService } from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { ReactiveValidatorsService } from 'src/app/shared/validators/reactive-validators.service';

@Component({
  selector: 'app-card-remitente',
  templateUrl: './card-remitente.component.html',
  styleUrls: ['./card-remitente.component.css'],
})
export class CardRemitenteComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  senderForm: FormGroup = this.fb.group({
    tipoDocumento: ['', [Validators.required]],
    documento: ['', [Validators.required]],
  });

  @Output() idRemitenteEmit: EventEmitter<number> = new EventEmitter<number>();

  @ViewChild('nombreRemitenteInput') nombreRemitenteInput: ElementRef;
  typeDocument: ITypeDocument[] = [];
  isLoading: boolean = false;
  _idTipoDocRemitente: number;
  remitente: ICliente;

  constructor(
    private clienteService: ClienteService,
    private fb: FormBuilder,
    private readonly typeDocumentService: TipoDocumentoService,
    private alertService: AlertService,
    private reactiveValidator: ReactiveValidatorsService
  ) {}

  ngOnInit(): void {
    this.loadTypeDocument();
  }

  loadTypeDocument() {
    this.subscription.add(
      this.typeDocumentService.listarTipoDocumentoService$().subscribe({
        next: (res: ITypeDocument[]) => {
          this.isLoading = true;
          this.typeDocument = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'Los documentos no cargaron correctamente. Contacte con el administrador'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  onDocRemitenteSelect({ value }: { value: any }) {
    this.reactiveValidator.updateValidators(
      this.senderForm,
      value.idTipoDocumento
    );
    return (this._idTipoDocRemitente = value.idTipoDocumento);
  }

  searchClientByDocument() {
    if (this.senderForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Antes de buscar complete los datos'
      );
      return;
    }

    const {
      tipoDocumento: { idTipoDocumento },
      documento,
    } = this.senderForm.value;

    let data = {
      idTipoDocumento,
      documento,
      estado: 1,
    };

    this.subscription.add(
      this.clienteService.buscarClienteByDocService$(data).subscribe({
        next: (res: ICliente) => {
          this.isLoading = true;
          this.remitente = res;
          this.remitente
            ? (this.nombreRemitenteInput.nativeElement.value = `${this.remitente.razonSocial}`)
            : (this.nombreRemitenteInput.nativeElement.value = '');

          this.idRemitenteEmit.emit(this.remitente.id);
        },
        error: (err) => {
          // this.customErrorService.listError(err);
          this.nombreRemitenteInput.nativeElement.value = '';
          const { error } = err;

          if (error.message) {
            this.alertService.showError('Ups..!!', error.message);
          }
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
