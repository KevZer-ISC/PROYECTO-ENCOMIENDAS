import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewOrdenComponent } from './new-orden.component';

describe('NewOrdenComponent', () => {
  let component: NewOrdenComponent;
  let fixture: ComponentFixture<NewOrdenComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewOrdenComponent]
    });
    fixture = TestBed.createComponent(NewOrdenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
