import {
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import {
  IFormPayment,
  IPersonPayment,
} from 'src/app/core/interfaces/interfaces';

import { FormaPagoService } from 'src/app/services/forma-pago/forma-pago.service';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-card-pago',
  templateUrl: './card-pago.component.html',
  styleUrls: ['./card-pago.component.css'],
})
export class CardPagoComponent implements OnInit, OnDestroy, OnChanges {
  private subscription: Subscription = new Subscription();
  isLoading: boolean = false;

  //Formulario
  @Input() paymentForm: FormGroup;

  //Array para el dropdown de Responsable de pago
  @Input() personPayment: IPersonPayment[] = [];

  //Array para el dropdown de Forma de Pago
  formsPayment: IFormPayment[] = [];

  constructor(
    private formaPagoService: FormaPagoService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {}

  watchFormsPayment({ value }: { value: any }) {
    const { pagador } = this.paymentForm.value;


    //CUALQUIER FALLA CON RESPECTO AL FORMA DE PAGO, SE DEBE DE REVISAR ESTE METODO
    const data = {
      idCliente: pagador.idCliente,
      pagador: pagador.pagador == 'Destinatario' ? 'Consignado' : 'Remitente',
    };

    this.subscription.add(
      this.formaPagoService.obtenerFormaPagoService$(data).subscribe({
        next: (res: IFormPayment[]) => {
          this.isLoading = true;
          this.formsPayment = res;
        },
        error: (err) => {
          this.alertService.showError(
            'Ups..!!',
            'Las formas de pago no se cargaron correctamente. Contacte con el administrador'
          );
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
