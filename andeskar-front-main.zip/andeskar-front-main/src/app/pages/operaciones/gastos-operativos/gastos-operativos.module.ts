import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GastosOperativosRoutingModule } from './gastos-operativos-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GastosOperativosRoutingModule
  ]
})
export class GastosOperativosModule { }
