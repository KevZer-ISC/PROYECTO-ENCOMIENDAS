import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrasladoRoutingModule } from './traslado-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TrasladoRoutingModule
  ]
})
export class TrasladoModule { }
