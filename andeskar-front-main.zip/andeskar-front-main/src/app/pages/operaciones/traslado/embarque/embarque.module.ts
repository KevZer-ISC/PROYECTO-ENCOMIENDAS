import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmbarqueRoutingModule } from './embarque-routing.module';
import { EmbarqueComponent } from './embarque.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [EmbarqueComponent],
  imports: [CommonModule, EmbarqueRoutingModule, OperacionesPrimeNgModule, FormsModule],
})
export class EmbarqueModule {}
