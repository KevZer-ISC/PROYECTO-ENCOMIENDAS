import { Component } from '@angular/core';

@Component({
  selector: 'app-embarque',
  templateUrl: './embarque.component.html',
  styleUrls: ['./embarque.component.css']
})
export class EmbarqueComponent {

}
