import { Component } from '@angular/core';

@Component({
  selector: 'app-manifiesto',
  templateUrl: './manifiesto.component.html',
  styleUrls: ['./manifiesto.component.css']
})
export class ManifiestoComponent {

}
