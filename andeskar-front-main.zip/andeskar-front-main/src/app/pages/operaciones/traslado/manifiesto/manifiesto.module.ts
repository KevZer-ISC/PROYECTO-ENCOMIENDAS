import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManifiestoRoutingModule } from './manifiesto-routing.module';
import { ManifiestoComponent } from './manifiesto.component';

@NgModule({
  declarations: [
    ManifiestoComponent
  ],
  imports: [
    CommonModule,
    ManifiestoRoutingModule
  ]
})
export class ManifiestoModule { }
