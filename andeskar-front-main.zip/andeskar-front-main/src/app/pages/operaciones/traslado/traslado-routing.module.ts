import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'programaciones', loadChildren:()=>import('./programacion/programacion.module').then(m=>m.ProgramacionModule)},
  {path:'embarque', loadChildren:()=>import('./embarque/embarque.module').then(m=>m.EmbarqueModule)},
  {path:'manifiesto', loadChildren:()=>import('./manifiesto/manifiesto.module').then(m=>m.ManifiestoModule)},
  {path:'trayectoria', loadChildren:()=>import('./trayectoria/trayectoria.module').then(m=>m.TrayectoriaModule)},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrasladoRoutingModule { }
