import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TrayectoriaRoutingModule } from './trayectoria-routing.module';
import { TrayectoriaComponent } from './trayectoria.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { TrayectoriaService } from 'src/app/services/trayectoria/trayectoria.service';
import { FiltroTrayectoriaComponent } from './filtro-trayectoria/filtro-trayectoria.component';
import { CardCabeceraTrayectoriaComponent } from './card-cabecera-trayectoria/card-cabecera-trayectoria.component';
import { ListDetalleTrayectoriaComponent } from './list-detalle-trayectoria/list-detalle-trayectoria.component';
import { NuevaTrayectoriaComponent } from './nueva-trayectoria/nueva-trayectoria.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TimeFormatPipe } from 'src/app/shared/pipes/time-format/time-format.pipe';

@NgModule({
  declarations: [
    TrayectoriaComponent,
    FiltroTrayectoriaComponent,
    CardCabeceraTrayectoriaComponent,
    ListDetalleTrayectoriaComponent,
    NuevaTrayectoriaComponent,
    TimeFormatPipe

  ],
  imports: [
    CommonModule,
    TrayectoriaRoutingModule,
    OperacionesPrimeNgModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  providers: [MessageService, ConfirmationService,AlertService, TrayectoriaService],
})
export class TrayectoriaModule {}
