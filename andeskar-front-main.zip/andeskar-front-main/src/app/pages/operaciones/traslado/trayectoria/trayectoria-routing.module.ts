import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TrayectoriaComponent } from './trayectoria.component';

const routes: Routes = [{ path: '', component: TrayectoriaComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TrayectoriaRoutingModule {}
