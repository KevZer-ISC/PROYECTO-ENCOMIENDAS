import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SelectButtonOptionClickEvent } from 'primeng/selectbutton';
import { Subscription } from 'rxjs';
import { IAgency, Itrajectory } from 'src/app/core/interfaces/interfaces';
import { AgenciaService } from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { DateUtilService } from 'src/app/shared/utils/date-util.service';

@Component({
  selector: 'app-filtro-trayectoria',
  templateUrl: './filtro-trayectoria.component.html',
  styleUrls: ['./filtro-trayectoria.component.css'],
})
export class FiltroTrayectoriaComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  agency: IAgency[] = [];

  isLoading: boolean = false;

  @Input() listTrajectorys?: Itrajectory[] = []; //variable que recibe la lista de trayectorias
  @Output() isNewTrajectoryEmit: EventEmitter<void> = new EventEmitter<void>(); //evento que se emite cuando se quiere crear una nueva trayectoria
  @Output() searchTrajectoryEmit: EventEmitter<any> = new EventEmitter<any>(); //evento que se emite cuando se quiere buscar una trayectoria

  /**
   * Formulario de busqueda de trayectorias
   */
  searchForm: FormGroup = this.fb.group({
    origen: ['', [Validators.required]],
    destino: ['', [Validators.required]],
    fecha: ['', [Validators.required]],
    estado: [1, []],
  });

  /**
   * Opciones de filtro
   */
  filterOptions: any[] = [
    { name: 'Activos', value: 1 },
    { name: 'Inactivos', value: 0 },
    { name: 'Todos', value: 2 },
  ];

  constructor(
    private readonly agencyService: AgenciaService,
    private fb: FormBuilder,
    private dateUtilService: DateUtilService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadAgency();
  }

  /**
   * Carga las agencias
   */
  loadAgency() {
    this.subscription.add(
      this.agencyService.listarAgenciaService$().subscribe({
        next: (agencys: IAgency[]) => {
          this.isLoading = true;
          this.agency = agencys; //se asigna la lista de agencias
        },
        error: (err) => {
          if (!err.error) {
            this.alertService.showError(
              'Error',
              'Error al cargar las agencias'
            );
            return;
          }
          this.alertService.showError('Error', err.error.message);
        },
        complete: () => (this.isLoading = false),
      })
    );
  }

  //metodos para obtener las agencias disponibles
  get availableDestinations(): IAgency[] {
    return this.agency.filter(
      (ag) => ag !== this.searchForm.get('origen')?.value
    );
  }

  get availableOrigins(): IAgency[] {
    return this.agency.filter(
      (ag) => ag !== this.searchForm.get('destino')?.value
    );
  }

  /**
   * Emite el evento para crear una nueva trayectoria
   */
  newTrajectory() {
    this.isNewTrajectoryEmit.emit();
  }

  /**
   * Busca una trayectoria
   * Si el formulario es invalido muestra un mensaje de alerta
   * Si el formulario es valido emite el evento de busqueda de trayectoria
   */
  searchTrajectory() {
    if (this.searchForm.invalid) {
      this.alertService.showWarn(
        'Formulario inválido',
        'Complete todos los campos'
      );
      return;
    }

    const { origen, destino, fecha, estado } = this.searchForm.value;

    const data = {
      idOrigen: origen.idAgencia,
      idDestino: destino.idAgencia,
      fecha: this.dateUtilService.formatFechaParams(fecha),
      estado,
    };

    this.searchTrajectoryEmit.emit(data); //se emite el evento de busqueda de trayectoria
  }

  /**
   * Este metodo se ejecuta cuando se selecciona una opcion de filtro
   * Emite el evento de busqueda de trayectoria
   * @param event
   */
  optionSelected(event: SelectButtonOptionClickEvent) {
    const { origen, destino, fecha } = this.searchForm.value;

    const data = {
      idOrigen: origen.idAgencia,
      idDestino: destino.idAgencia,
      fecha: this.dateUtilService.formatFechaParams(fecha),
      estado: event.option.value,
    };

    this.searchTrajectoryEmit.emit(data);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
