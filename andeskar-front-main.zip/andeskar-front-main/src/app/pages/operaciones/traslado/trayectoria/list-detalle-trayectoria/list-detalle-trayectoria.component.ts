import { Component, OnDestroy, OnInit } from '@angular/core';
import { IDetailAgencyTrajectory } from 'src/app/core/interfaces/interfaces';
import { TrajectoryHelperService } from '../helpers/trajectory-helper.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-list-detalle-trayectoria',
  templateUrl: './list-detalle-trayectoria.component.html',
  styleUrls: ['./list-detalle-trayectoria.component.css'],
})
export class ListDetalleTrayectoriaComponent implements OnInit, OnDestroy {
  details: IDetailAgencyTrajectory[] = [];
  private subscription: Subscription = new Subscription();

  constructor(private trajectoryHelper: TrajectoryHelperService) {}

  ngOnInit() {
    this.subscription.add(
      this.trajectoryHelper.detail$.subscribe(
        (detail: IDetailAgencyTrajectory[]) => {
          this.details = detail;
        }
      )
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
