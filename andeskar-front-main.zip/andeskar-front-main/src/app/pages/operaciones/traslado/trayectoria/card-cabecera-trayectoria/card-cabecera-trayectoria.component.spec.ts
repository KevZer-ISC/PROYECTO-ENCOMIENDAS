import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardCabeceraTrayectoriaComponent } from './card-cabecera-trayectoria.component';

describe('CardCabeceraTrayectoriaComponent', () => {
  let component: CardCabeceraTrayectoriaComponent;
  let fixture: ComponentFixture<CardCabeceraTrayectoriaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardCabeceraTrayectoriaComponent]
    });
    fixture = TestBed.createComponent(CardCabeceraTrayectoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
