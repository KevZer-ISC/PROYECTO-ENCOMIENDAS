import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevaTrayectoriaComponent } from './nueva-trayectoria.component';

describe('NuevaTrayectoriaComponent', () => {
  let component: NuevaTrayectoriaComponent;
  let fixture: ComponentFixture<NuevaTrayectoriaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NuevaTrayectoriaComponent]
    });
    fixture = TestBed.createComponent(NuevaTrayectoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
