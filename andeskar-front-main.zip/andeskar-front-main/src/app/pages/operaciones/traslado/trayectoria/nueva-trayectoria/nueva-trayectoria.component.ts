import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { AgenciaService } from 'src/app/services/service.root';
import { IAgency, INewTrajectory } from 'src/app/core/interfaces/interfaces';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shared/components/alert.service';
import { ConfirmationService, ConfirmEventType, MenuItem } from 'primeng/api';
import { TrajectoryHelperService } from '../helpers/trajectory-helper.service';
import { TrayectoriaService } from 'src/app/services/trayectoria/trayectoria.service';

@Component({
  selector: 'app-nueva-trayectoria',
  templateUrl: './nueva-trayectoria.component.html',
  styleUrls: ['./nueva-trayectoria.component.css'],
})
export class NuevaTrayectoriaComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  @Output() saveCompleteEmit = new EventEmitter<void>();

  agencyForm: FormGroup = this.fb.group({
    agencia: ['', [Validators.required]],
    viaje: [, [Validators.required]],
    estiba: [, [Validators.required]],
  });

  updatingAgencyForm: FormGroup = this.fb.group({
    agencia: ['', []],
    viaje: [, []],
    estiba: [, []],
  });

  headerTrajectoryForm: FormGroup = this.fb.group({
    origen: ['', [Validators.required]],
    destino: ['', [Validators.required]],
    orientacion: ['', [Validators.required]],
    nombre: [
      '',
      [Validators.required, Validators.minLength(3), Validators.maxLength(50)],
    ],
  });

  orientation: any[] = [
    { id: 1, name: 'Norte' },
    { id: 2, name: 'Sur' },
  ];

  agency: IAgency[] = [];
  agencyDynamic: IAgency[];
  updateAgencyDinamic: IAgency[] = [];
  agencyTrajectoryList: INewTrajectory[] = [];

  isLoading: boolean = false;
  isNewTrajectory: boolean = true;
  isNewAgencyTrajectory: boolean = false;
  isUpdating: boolean = false;

  items: MenuItem[] | undefined;
  agencySelectedUpdate?: INewTrajectory;
  currentIndex?: number = 0;

  constructor(
    private agencyService: AgenciaService,
    private fb: FormBuilder,
    private alertService: AlertService,
    private confirmationService: ConfirmationService,
    private trajectoryHelper: TrajectoryHelperService,
    private trajectoryService: TrayectoriaService
  ) {}

  ngOnInit(): void {
    this.loadAgency();
    this.items = [
      {
        label: 'Actualizar',
        icon: 'pi pi-file-edit',
        command: (event) => {
          this.isUpdating = !this.isUpdating;
          this.updatingAgencyForm.patchValue({
            agencia: this.agencySelectedUpdate?.agencia,
            viaje: this.agencySelectedUpdate?.viaje,
            estiba: this.agencySelectedUpdate?.estiba,
          });
        },
      },
      {
        label: 'Eliminar',
        icon: 'pi pi-times',
        command: (event) => {
          this.removeAgencyTrajectory(this.currentIndex!);
        },
      },
    ];
  }

  loadAgency() {
    this.subscription.add(
      this.agencyService.listarAgenciaService$().subscribe({
        next: (agencys: IAgency[]) => {
          this.isLoading = true;
          this.agency = agencys;
          this.agencyDynamic = agencys;
        },
        error: (err) => {
          if (!err.error) {
            this.alertService.showError(
              'Error',
              'Error al cargar las agencias'
            );
            return;
          }

          this.alertService.showError('Error', err.error.message);
        },
        complete: () => (this.isLoading = false),
      })
    );
  }

  // En tu componente TS
  get availableDestinations(): IAgency[] {
    return this.agency.filter(
      (ag) => ag !== this.headerTrajectoryForm.get('origen')?.value
    );
  }

  get availableOrigins(): IAgency[] {
    return this.agency.filter(
      (ag) => ag !== this.headerTrajectoryForm.get('destino')?.value
    );
  }

  /**
   * Sirve para generar la lista de agencias dinamicas
   * Son las cards que se muestran en la parte inferior
   * @returns
   */
  setTrajectory() {
    if (this.headerTrajectoryForm.invalid) {
      this.alertService.showInfo('Ups..', 'Porfavor complete los campos');
      return;
    }

    this.headerTrajectoryForm.disable();

    const { newOrigen, newDestino, origen, destino } =
      this.trajectoryHelper.setTrajectoryHelper(this.headerTrajectoryForm);

    // Agregar a la lista de trayectorias
    this.agencyTrajectoryList = [
      ...this.agencyTrajectoryList,
      newOrigen,
      newDestino,
    ];

    // Eliminar de agencyDynamic
    this.agencyDynamic = this.agencyDynamic.filter(
      (agency) =>
        agency.idAgencia !== origen.idAgencia &&
        agency.idAgencia !== destino.idAgencia
    );
    this.updateAgencyDinamic = this.agencyDynamic;

    this.isNewAgencyTrajectory = true;
    this.isNewTrajectory = false;
  }

  /**
   * Es el metodo que se encarga de registrar las agencias que se van a agregar a la trayectoria
   * Es decir las agencias que se van a agregar a la lista de trayectorias
   * De la parte inferior
   * Son las cards en otras palabras
   * @returns
   */
  registerAgencyTrajectory() {
    if (this.agencyForm.invalid) {
      this.alertService.showWarn('Adevertencia', 'Complete los campos');
      return;
    }

    const newAgency = this.agencyForm.value;
    const { orientacion } = this.headerTrajectoryForm.value;
    const insertionIndex = this.agencyTrajectoryList.length - 1;

    this.agencyTrajectoryList = [
      ...this.agencyTrajectoryList.slice(0, insertionIndex),
      {
        ...newAgency,
        isFixed: false,
        orientacion: orientacion.name,
        isRemovable: true,
        isUpdating: true,
        trayectoriaTipo: 2,
      },
      ...this.agencyTrajectoryList.slice(insertionIndex),
    ];

    // Eliminar de agencyDynamic
    this.agencyDynamic = this.agencyDynamic.filter(
      (agency) => agency.idAgencia !== newAgency.agencia.idAgencia
    );

    this.agencyForm.reset();
  }

  /**
   * Es el metodo que se encarga de eliminar una agencia de la trayectoria
   * Quita a la agencia de las cards de la parte inferior
   * Pero recordar que solo es el array
   * @param index
   */
  removeAgencyTrajectory(index: number) {
    const agency = this.agencyTrajectoryList.map((agency) => agency)[index];

    if (agency.isRemovable) {
      const removedAgency = this.agencyTrajectoryList.splice(index, 1)[0];
      this.alertService.showInfo(
        'Eliminación Exitosa',
        'Agencia eliminada de la lista'
      );
      // Re-agregar a agencyDynamic
      this.agencyDynamic = [...this.agencyDynamic, removedAgency.agencia];
    } else {
      this.alertService.showInfo('Ups..', 'No se puede eliminar esta agencia');
    }
  }

  /**
   * Es el metodo que se encarga de cancelar la trayectoria
   */
  cancelTrajectory() {
    this.confirmationService.confirm({
      message: 'Perderá sus cambios, Esta seguro que desea continuar?',
      header: 'Mensaje de Confirmación',
      icon: 'pi pi-exclamation-triangle',
      rejectLabel: 'No',
      acceptLabel: 'Si',
      accept: () => {
        this.headerTrajectoryForm.reset();
        this.agencyForm.reset();
        this.agencyTrajectoryList.splice(0, this.agencyTrajectoryList.length);
        this.headerTrajectoryForm.enable();
        this.isNewAgencyTrajectory = false;
        this.isNewTrajectory = true;
        this.alertService.showSuccess(
          'Confirmación Exitosa!!',
          'Usted acepto cancelar la operacion'
        );
      },
      reject: () => {
        this.alertService.showError(
          'Fallo al cancelar',
          'Usted rechazo el cancelar la operacion'
        );
      },
    });
  }

  /**
   * Es el metodo que se encarga de guardar la trayectoria completa
   * y envuarla al backend
   * Este metodo conecta con la API
   */
  saveTrajectory() {
    this.confirmationService.confirm({
      message:
        'Todos los cambios realizados en la nueva Trayectoria se guardaran, Desea continuar?',
      header: 'Mensaje de Confirmación',
      icon: 'pi pi-exclamation-triangle',
      rejectLabel: 'No',
      acceptLabel: 'Si',
      accept: () => {
        const data = this.trajectoryHelper.generateJsonHelper(
          this.headerTrajectoryForm,
          this.agencyTrajectoryList
        );

        this.subscription.add(
          this.trajectoryService.insertarTrayectoria(data).subscribe({
            next: (response) => {
              this.isLoading = true;
              this.headerTrajectoryForm.reset();
              this.agencyForm.reset();
              this.agencyTrajectoryList.splice(
                0,
                this.agencyTrajectoryList.length
              );
              this.headerTrajectoryForm.enable();
              this.isNewAgencyTrajectory = false;
              this.isNewTrajectory = true;
              this.saveCompleteEmit.emit();
              this.alertService.showSuccess(
                'Confirmación Exitosa!!',
                'La trayectoria se guardo correctamente'
              );
            },
            error: (err) => {
              this.alertService.showError(
                'Error',
                'Error al guardar la trayectoria'
              );
            },
            complete: () => {
              this.isLoading = false;
            },
          })
        );
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case 1:
            this.alertService.showError(
              'Rechazo..',
              'Usted rechazó  la operacion'
            );
            break;
          case 2:
            this.alertService.showInfo(
              'Cancelar..',
              'Usted canceló la operacion'
            );
            break;
        }
      },
    });
  }

  /**
   * Este metodo se encarga del al hacer click en el icono de los tres puntos
   * tambien se encarga de cargar current index y la agencia seleccionada para su actualizacion
   * se despliegua un menu con las opciones de editar y eliminar
   * @param data
   * @param index
   */
  showAgencyTrajectory(data: INewTrajectory, index: number) {
    this.currentIndex = index;
    this.agencySelectedUpdate = data;
  }

  updateAgencyTrajectory() {
    // Obtener el objeto existente en el array
    const currentAgency = this.agencyTrajectoryList[this.currentIndex!];

    const updatedAgency = this.updatingAgencyForm.value;

    const agencyChanged =
      currentAgency.agencia.idAgencia !== updatedAgency.agencia.idAgencia;

    const mergedAgency = {
      ...currentAgency, // Propiedades existentes
      ...updatedAgency, // Propiedades actualizadas del formulario
      isFixed: currentAgency.isFixed, // Conservar propiedades no alteradas
      isRemovable: currentAgency.isRemovable,
      isUpdating: currentAgency.isUpdating,
      orientacion: currentAgency.orientacion, // Conservar orientación si no se cambia
    };

    this.alertService.showInfo('Actualización Exitosa', 'Agencia actualizada');

    // Si la agencia ha cambiado, manejar agencyDynamic
    if (agencyChanged) {
      // Re-agregar la antigua agencia a agencyDynamic
      this.agencyDynamic = [...this.agencyDynamic, currentAgency.agencia];

      // Eliminar la nueva agencia de agencyDynamic
      this.agencyDynamic = this.agencyDynamic.filter(
        (agency) => agency.idAgencia !== updatedAgency.agencia.idAgencia
      );
    }

    // Reemplazar el objeto en la posición indicada
    this.agencyTrajectoryList[this.currentIndex!] = mergedAgency;

    this.isUpdating = false;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  viajeFormat(event: any) {
    const input = event.target.value;
    if (input.length === 2 && !input.includes(':')) {
      event.target.value = `${input}:`;
    }
  }

  estibaFormat(event: any) {
    const input = event.target.value;
    if (input.length === 2 && !input.includes(':')) {
      event.target.value = `${input}:`;
    }
    //this.estibaTime = event.target.value;
  }
}
