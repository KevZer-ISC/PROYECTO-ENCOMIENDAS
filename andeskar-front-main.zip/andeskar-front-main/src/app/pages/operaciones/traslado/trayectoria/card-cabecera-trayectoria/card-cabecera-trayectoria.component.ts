import { Component, Input } from '@angular/core';
import {
  IDetailAgencyTrajectory,
  Itrajectory,
} from 'src/app/core/interfaces/interfaces';
import { TrajectoryHelperService } from '../helpers/trajectory-helper.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-card-cabecera-trayectoria',
  templateUrl: './card-cabecera-trayectoria.component.html',
  styleUrls: ['./card-cabecera-trayectoria.component.css'],
})
export class CardCabeceraTrayectoriaComponent {
  items: MenuItem[] = [
    {
      label: 'Actualizar',
      icon: 'pi pi-file-edit',
      command: (event) => {},
    },
    {
      label: 'Desactivar',
      icon: 'pi pi-times',
      command: (event) => {},
    },
  ];

  @Input() trajectoryList: Itrajectory[] = [];

  constructor(private trajectoryHelper: TrajectoryHelperService) {}

  showDetail(detailTrajectory: IDetailAgencyTrajectory[]) {
    this.trajectoryHelper.emitDetail(detailTrajectory);
  }
}
