import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroTrayectoriaComponent } from './filtro-trayectoria.component';

describe('FiltroTrayectoriaComponent', () => {
  let component: FiltroTrayectoriaComponent;
  let fixture: ComponentFixture<FiltroTrayectoriaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FiltroTrayectoriaComponent]
    });
    fixture = TestBed.createComponent(FiltroTrayectoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
