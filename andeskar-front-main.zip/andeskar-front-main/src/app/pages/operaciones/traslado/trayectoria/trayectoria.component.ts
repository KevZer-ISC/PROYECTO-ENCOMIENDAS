import { Component, OnDestroy, OnInit } from '@angular/core';
import { SelectButtonOptionClickEvent } from 'primeng/selectbutton';
import { Subscription } from 'rxjs';
import { IAgency, Itrajectory } from 'src/app/core/interfaces/interfaces';
import { AgenciaService } from 'src/app/services/service.root';
import { TrayectoriaService } from 'src/app/services/trayectoria/trayectoria.service';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-trayectoria',
  templateUrl: './trayectoria.component.html',
  styleUrls: ['./trayectoria.component.css'],
})
export class TrayectoriaComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  isLoading: boolean = false;
  isNewTrajectory: boolean = false;
  isVisibleTrajectorys: boolean = false;
  trajectoryList: Itrajectory[] = [];

  constructor(
    private readonly trajectoryService: TrayectoriaService,
    private readonly alertService: AlertService
  ) {}

  ngOnInit(): void {}

  /**
   * Este metodo recibe el evento del componente de busqueda de trayectorias
   * y llama al servicio de trayectorias para obtener la lista de trayectorias
   * @param event
   */
  searchTrajectoryEmited(event: any) {
    this.loadTrajectory(event);
  }

  /**
   * Este metodo carga la lista de trayectorias
   * @param data
   */
  loadTrajectory(data: any) {
    this.subscription.add(
      this.trajectoryService.listarTrayectoriaService$(data).subscribe({
        next: (res: Itrajectory[]) => {
          this.isLoading = true;
          this.trajectoryList = res;
          this.isVisibleTrajectorys = true;
        },
        error: (err) => {
          this.isVisibleTrajectorys = false;
          if (!err.error) {
            this.alertService.showError(
              'Error',
              'Error al cargar las Trayectorias, Contacte con el administrador'
            );
            return;
          }

          if (data.idOrigen === undefined && data.idDestino === undefined) {
            this.alertService.showError(
              'Error',
              'Debe seleccionar al menos un filtro'
            );
            return;
          }

          this.alertService.showError('Error', err.error.message);
        },
        complete: () => {
          this.isLoading = false;
        },
      })
    );
  }

  isNewTrajectoryEmited(event: any) {
    this.isNewTrajectory = !this.isNewTrajectory;
  }

  saveCompleteEmited(event: any) {
    this.isNewTrajectory = false;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
