import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDetalleTrayectoriaComponent } from './list-detalle-trayectoria.component';

describe('ListDetalleTrayectoriaComponent', () => {
  let component: ListDetalleTrayectoriaComponent;
  let fixture: ComponentFixture<ListDetalleTrayectoriaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListDetalleTrayectoriaComponent]
    });
    fixture = TestBed.createComponent(ListDetalleTrayectoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
