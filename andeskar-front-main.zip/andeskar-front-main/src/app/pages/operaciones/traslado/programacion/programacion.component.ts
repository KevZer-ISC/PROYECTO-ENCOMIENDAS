import { Component } from '@angular/core';
import { PROGRAMACION_CONSTANT } from 'src/app/core/constants/operaciones/CProgramacion.constant';
import { IProgramacion } from 'src/app/core/interfaces/operaciones/IProgramacion.interface';

@Component({
  selector: 'app-programacion',
  templateUrl: './programacion.component.html',
  styleUrls: ['./programacion.component.css']
})
export class ProgramacionComponent {
  programaciones: IProgramacion[] = PROGRAMACION_CONSTANT;
  first = 0;

  rows = 10;
  ngOnInit(): void {}

  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  pageChange(event: any) {
    this.first = event.first;
    this.rows = event.rows;
  }

  isLastPage(): boolean {
    return this.programaciones ? this.first === this.programaciones.length - this.rows : true;
  }

  isFirstPage(): boolean {
    return this.programaciones ? this.first === 0 : true;
  }
}
