import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProgramacionRoutingModule } from './programacion-routing.module';
import { ProgramacionComponent } from './programacion.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
@NgModule({
  declarations: [ProgramacionComponent],
  imports: [CommonModule, ProgramacionRoutingModule, OperacionesPrimeNgModule],
})
export class ProgramacionModule {}
