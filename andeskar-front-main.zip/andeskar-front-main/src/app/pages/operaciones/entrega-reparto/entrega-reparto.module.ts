import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EntregaRepartoRoutingModule } from './entrega-reparto-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EntregaRepartoRoutingModule
  ]
})
export class EntregaRepartoModule { }
