import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConstanciaPesosRoutingModule } from './constancia-pesos-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConstanciaPesosRoutingModule
  ]
})
export class ConstanciaPesosModule { }
