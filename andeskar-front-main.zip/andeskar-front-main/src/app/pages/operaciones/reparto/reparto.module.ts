import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RepartoRoutingModule } from './reparto-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RepartoRoutingModule
  ]
})
export class RepartoModule { }
