import { Component } from '@angular/core';

@Component({
  selector: 'app-guia-transportista',
  templateUrl: './guia-transportista.component.html',
  styleUrls: ['./guia-transportista.component.css']
})
export class GuiaTransportistaComponent {

}
