import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GuiaTransportistaComponent } from './guia-transportista.component';

const routes: Routes = [
  {path:'', component: GuiaTransportistaComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuiaTransportistaRoutingModule { }
