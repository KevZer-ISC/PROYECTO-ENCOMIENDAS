import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuiaTransportistaRoutingModule } from './guia-transportista-routing.module';
import { GuiaTransportistaComponent } from './guia-transportista.component';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';

@NgModule({
  declarations: [
    GuiaTransportistaComponent
  ],
  imports: [
    CommonModule,
    GuiaTransportistaRoutingModule,
    OperacionesPrimeNgModule
  ]
})
export class GuiaTransportistaModule { }
