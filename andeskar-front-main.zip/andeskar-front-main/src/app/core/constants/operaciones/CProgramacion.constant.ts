import { IProgramacion } from "../../interfaces/operaciones/IProgramacion.interface";

export const PROGRAMACION_CONSTANT:IProgramacion[] = [
    {
        serie: "A001",
        numero: 123456,
        fechaGuia: "2023-05-01",
        ruta: "Lima - Cusco",
        remitente: "Empresa A",
        destinatario: "Empresa B",
        nroBultos: 10,
        pesoTotal: 150.5,
        importeFlete: 500.00,
        serieFABV: "F001",
        numeroFABV: 654321,
        formaPago: "Contado"
    },
    {
        serie: "B002",
        numero: 789012,
        fechaGuia: "2023-06-15",
        ruta: "Arequipa - Lima",
        remitente: "Empresa C",
        destinatario: "Empresa D",
        nroBultos: 5,
        pesoTotal: 75.0,
        importeFlete: 250.00,
        serieFABV: "F002",
        numeroFABV: 123789,
        formaPago: "Crédito"
    },
    {
        serie: "C003",
        numero: 345678,
        fechaGuia: "2023-07-20",
        ruta: "Trujillo - Piura",
        remitente: "Empresa E",
        destinatario: "Empresa F",
        nroBultos: 20,
        pesoTotal: 300.0,
        importeFlete: 750.00,
        serieFABV: "F003",
        numeroFABV: 987654,
        formaPago: "Transferencia"
    }
]