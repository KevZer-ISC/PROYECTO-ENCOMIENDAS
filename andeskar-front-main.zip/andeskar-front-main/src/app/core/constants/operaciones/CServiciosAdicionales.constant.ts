import { IServicesAdditional } from '../../interfaces/operaciones/IServiciosAdicionales.interfaces';

export const CSERVICESADDITIONAL: IServicesAdditional[] = [
  {
    id: 1,
    descripcion: 'Reparto',
    state: 'activo',
    value: 1,
    createdAt: '2021-09-01',
  },
  {
    id: 2,
    descripcion: 'Recojo',
    state: 'activo',
    value: 2,
    createdAt: '2021-09-01',
  },
  {
    id: 3,
    descripcion: 'Estiba / Desestiba Adicional',
    state: 'activo',
    value: 3,
    createdAt: '2021-09-01',
  },

  {
    id: 4,
    descripcion: 'Montacarga',
    state: 'activo',
    value: 4,
    createdAt: '2021-09-01',
  },
  {
    id: 5,
    descripcion: 'Embalaje',
    state: 'activo',
    value: 5,
    createdAt: '2021-09-01',
  },
  {
    id: 6,
    descripcion: 'Almacenaje',
    state: 'activo',
    value: 6,
    createdAt: '2021-09-01',
  },
];
