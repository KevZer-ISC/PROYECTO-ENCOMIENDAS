import { NgModule } from "@angular/core";

import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { StyleClassModule } from 'primeng/styleclass';

@NgModule({
    exports:[
        CheckboxModule,
        InputTextModule,
        ButtonModule,
        DropdownModule,
        StyleClassModule
    ]
})
export class AuthPrimengModule{

}