import { NgModule } from '@angular/core';
import { CalendarModule } from 'primeng/calendar';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { RippleModule } from 'primeng/ripple';
import { StyleClassModule } from 'primeng/styleclass';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { FileUploadModule } from 'primeng/fileupload';
import { DialogModule } from 'primeng/dialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { ToastModule } from 'primeng/toast';
import { MultiSelectModule } from 'primeng/multiselect';
import { TagModule } from 'primeng/tag';
import { SliderModule } from 'primeng/slider';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SidebarModule } from 'primeng/sidebar';
import { FieldsetModule } from 'primeng/fieldset';
import { AccordionModule } from 'primeng/accordion';
import { DividerModule } from 'primeng/divider';
import { BadgeModule } from 'primeng/badge';
import { AvatarModule } from 'primeng/avatar';
import { PickListModule } from 'primeng/picklist';
import { SpeedDialModule } from 'primeng/speeddial';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MenuModule } from 'primeng/menu';
import { SelectButtonModule } from 'primeng/selectbutton';
import { RadioButtonModule } from 'primeng/radiobutton';

@NgModule({
  imports: [],
  exports: [
    CalendarModule,
    InputNumberModule,
    InputTextModule,
    CheckboxModule,
    RippleModule,
    StyleClassModule,
    TableModule,
    DropdownModule,
    FileUploadModule,
    InputTextareaModule,
    DialogModule,
    MultiSelectModule,
    SliderModule,
    ToastModule,
    TagModule,
    ProgressSpinnerModule,
    SidebarModule,
    FieldsetModule,
    AccordionModule,
    DividerModule,
    BadgeModule,
    AvatarModule,
    SpeedDialModule,
    PickListModule,
    ConfirmPopupModule,
    ConfirmDialogModule,
    MenuModule,
    SelectButtonModule,
    RadioButtonModule
  ],
})
export class OperacionesPrimeNgModule {}
