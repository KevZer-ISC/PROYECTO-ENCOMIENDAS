export * from './auth/auth_primeng.module'
export * from './operaciones/operaciones_primeng.module'
export * from './personal/personal_primeng.module'