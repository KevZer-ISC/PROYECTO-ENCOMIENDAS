import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';
import { AuthCookieService } from '../service.core';
import { ITypeDocument } from '../../interfaces/maestros/ITipoDocumento.interface';
import { IGenericArrays } from '../../interfaces/interfaces';

@Injectable({
  providedIn: 'root',
})
export class TipoDocumentoService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService,
    private readonly cookieService: AuthCookieService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerTipoDocumentoService$(id: number) {}

  listarTipoDocumentoService$(): Observable<ITypeDocument[]> {
    let direccion = `${this.base_url}/TipoDocumento/ListarTipoDocumentos`;
    return this.httpClient
      .post<IGenericArrays<ITypeDocument>>(direccion, {})
      .pipe(map((response: IGenericArrays<ITypeDocument>) => response.data));
  }

  insertTipoDocumentoService$(data: any) {}

  updateTipoDocumentoService$(data: any) {}

  deleteTipoDocumentoService$(id: number) {}
}
