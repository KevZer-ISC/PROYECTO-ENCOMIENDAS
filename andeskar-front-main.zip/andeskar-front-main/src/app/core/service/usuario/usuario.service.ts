import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  obtenerUsuarioService$(id: number) {}

  listarUsuarioService$() {}

  insertUsuarioService$(data: any) {}

  updateUsuarioService$(data: any) {}
  
  deleteUsuarioService$(id: number) {}
}
