import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ValueStorageService extends AKeyValueStorageService {
  constructor() {
    super();
  }

  override setKeyValue<T>(key: string, value: T): void {
    switch (typeof value) {
      case 'number':
        localStorage.setItem(key, value.toString());
        break;
      case 'string':
        localStorage.setItem(key, value);
        break;
      case 'boolean':
        localStorage.setItem(key, value.toString());
        break;
      case 'object':
        if (value === null) {
          localStorage.removeItem(key);
        } else {
          localStorage.setItem(key, JSON.stringify(value));
        }
        break;
      default:
        throw new Error(`Set not implemented for type ${typeof value}`);
    }
  }

  override getValue<T>(key: string): T | null {
    const value = localStorage.getItem(key);
    if (value === null) {
      return null;
    }
    switch (typeof value) {
      case 'number':
        return Number(value) as unknown as T;
      case 'string':
        return value as unknown as T;
      default:
        try {
          return JSON.parse(value) as T;
        } catch {
          return value as unknown as T;
        }
    }
  }

  override removeKey(key: string): boolean {
    localStorage.removeItem(key);
    return true;
  }
}
