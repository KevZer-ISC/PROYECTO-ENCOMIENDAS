import { TestBed } from '@angular/core/testing';

import { ValueStorageService } from './value-storage.service';

describe('ValueStorageService', () => {
  let service: ValueStorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValueStorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
