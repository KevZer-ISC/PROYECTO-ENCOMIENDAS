abstract class AKeyValueStorageService {
  abstract setKeyValue<T>(key: string, value: T): void;
  abstract getValue<T>(key: string): T | null;
  abstract removeKey(key: string): boolean;
}
