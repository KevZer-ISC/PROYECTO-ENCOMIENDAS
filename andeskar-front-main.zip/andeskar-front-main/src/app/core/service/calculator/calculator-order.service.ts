import { Injectable, OnInit } from '@angular/core';




@Injectable({
  providedIn: 'root'
})
export class CalculatorOrderService {


  itemsForCalculate:any[] = [];


  constructor() { }

  
  calculateTotalsOrders(data:any){
    const {unidad, nroBultos, peso, precioUnitario, subtotal, descuento, descripcion } = data;
    this.itemsForCalculate.push(data)
    console.log(this.itemsForCalculate);
  }


  private calculateSubtotal(){
    this.itemsForCalculate.map((x)=>{
      let subtotal = x.nroBultos * x.precioUnitario
      return subtotal;
    })
  }



}
