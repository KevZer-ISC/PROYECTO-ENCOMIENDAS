import { TestBed } from '@angular/core/testing';

import { CalculatorOrderService } from './calculator-order.service';

describe('CalculatorOrderService', () => {
  let service: CalculatorOrderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculatorOrderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
