import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class PerfilService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  obtenerPerfilService$(id: number) {}

  listarPerfilService$() {}

  insertPerfilService$(data: any) {}

  updatePerfilService$(data: any) {}

  deletePerfilService$(id: number) {}
  
  listarPerfilWithMenyByIdPerfilService$(id: number) {}
}
