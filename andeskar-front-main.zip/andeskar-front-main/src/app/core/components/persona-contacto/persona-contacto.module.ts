import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonaContactoComponent } from './persona-contacto.component';
import { ClienteService } from 'src/app/services/service.root';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { TipoDocumentoService } from '../../service/service.core';
import { OperacionesPrimeNgModule } from '../../themes/modules/modules';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertService } from 'src/app/shared/components/alert.service';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [PersonaContactoComponent],
  providers: [
    MessageService,
    ClienteService,
    ValidatorsService,
    AlertService,
    CustomErrorService,
    TipoDocumentoService,
  ],
  imports: [
    CommonModule,
    OperacionesPrimeNgModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [PersonaContactoComponent],
})
export class SharedPersonaContactoModule {}
