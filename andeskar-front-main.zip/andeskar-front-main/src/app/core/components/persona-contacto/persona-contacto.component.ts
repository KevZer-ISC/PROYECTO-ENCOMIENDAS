import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { CustomErrorService } from 'src/app/shared/shared';
import { Table } from 'primeng/table';
import { ContactoService } from 'src/app/services/contacto/contacto.service';
import { IContacto } from '../../interfaces/maestros/IContacto.interface';
import { AlertService } from 'src/app/shared/components/alert.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-persona-contacto',
  templateUrl: './persona-contacto.component.html',
})
export class PersonaContactoComponent implements OnInit, OnDestroy, OnChanges {
  private subscription: Subscription = new Subscription();

  @Output() arrayClientEmit: EventEmitter<number[]> = new EventEmitter<
    number[]
  >();

  @Input() idConsigned: number;
  idContacts: number[] = [];
  contacts: IContacto[] = [];
  loading: boolean = true;

  activityValues: number[] = [0, 100];
  constructor(
    private readonly customErrorService: CustomErrorService,
    private readonly contactService: ContactoService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadContacts();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['idConsigned'] && !changes['idConsigned'].isFirstChange()) {
      this.loadContacts();
    }
  }

  private loadContacts(): void {
    this.loading = true;
    //console.log('ID Consigned:', this.idConsigned); // Verifica que el valor sea correcto
    this.subscription.add(
      this.contactService
        .listarContactoByIdService(this.idConsigned)
        .subscribe({
          next: (res: IContacto[]) => {
            this.contacts = res;
          },
          error: (err) => {
            this.alertService.showError(
              'Error',
              'Algo sucedio, consulte con el administrador'
            );
            this.customErrorService.listError(err);
          },
          complete: () => {
            this.loading = false;
          },
        })
    );
  }

  clear(table: Table) {
    table.clear();
  }

  selectClient(index: number, id: number) {
    this.contacts[index].activo = !this.contacts[index].activo;

    const idIndex = this.idContacts.indexOf(id);

    if (idIndex > -1) {
      this.idContacts.splice(idIndex, 1);
    } else {
      this.idContacts.push(id);
    }

    this.arrayClientEmit.emit(this.idContacts);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
