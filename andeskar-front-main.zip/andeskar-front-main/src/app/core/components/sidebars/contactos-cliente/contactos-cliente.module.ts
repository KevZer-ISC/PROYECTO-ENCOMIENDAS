import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactosClienteComponent } from './contactos-cliente.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaestrosPrimeNgModule } from 'src/app/core/themes/modules/maestros/maestros_primeng.module';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService } from 'src/app/shared/shared';

@NgModule({
  declarations: [ContactosClienteComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaestrosPrimeNgModule,
  ],
  exports: [ContactosClienteComponent],
  providers: [MessageService, ConfirmationService, AlertService, CustomErrorService],
})
export class ContactosClienteModule {}
