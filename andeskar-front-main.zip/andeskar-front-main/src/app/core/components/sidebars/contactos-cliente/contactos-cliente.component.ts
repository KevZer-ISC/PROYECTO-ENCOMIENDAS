import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { interval, Subscription } from 'rxjs';
import { IContacto } from 'src/app/core/interfaces/maestros/IContacto.interface';
import { ContactoService } from 'src/app/services/contacto/contacto.service';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';

@Component({
  selector: 'app-contactos-cliente',
  templateUrl: './contactos-cliente.component.html',
})
export class ContactosClienteComponent implements OnInit, OnDestroy {
  contactosForm: FormGroup;
  @Input() idCliente: string = '';
  contactosApi: IContacto[] = [];
  
  isNotError: boolean = true;
  isContactSidebarVisible: boolean = false;

  counterValue: number = 0;


  /**
   * Susbscripciones
   */
  private loadSubscription: Subscription = new Subscription();
  private updateSubscription: Subscription = new Subscription();
  private deleteSubscription: Subscription = new Subscription();


  constructor(
    private readonly fb: FormBuilder,
    private readonly validatorsService: ValidatorsService,
    private alertService: AlertService,
    private readonly contactoService: ContactoService,
    private readonly customErrorService: CustomErrorService,
    private confirmationService: ConfirmationService
  ) {
    this.contactosForm = fb.group({
      contactos: fb.array([this.createContactos()]),
    });
  }

  ngOnInit(): void {}

  loadContactsByIdClient() {
    this.loadSubscription.add(
      this.contactoService
        .listarContactoByIdService(+this.idCliente)
        .subscribe({
          next: (res: IContacto[]) => {
            this.contactosApi = res;
            this.setContacts(res);
          },
          error: (error) => {
            this.alertService.showError('Error', 'Contactos no encontrados');
            this.customErrorService.listError(error);
            this.isNotError = false;
          },
        })
    );
  }

  setContacts(contactos: IContacto[]): void {
    const contactoFGs = contactos.map((contacto) =>
      this.fb.group({
        documento: [
          contacto.documento,
          [Validators.required, this.validatorsService.validateForeignerCard],
        ],
        nombre: [
          contacto.nombre,
          [Validators.required, this.validatorsService.validateFullname],
        ],
        telefono: [
          contacto.telefono,
          [Validators.required, this.validatorsService.validatePhone],
        ],
        idContacto: [contacto.idContacto],
        idCliente: [contacto.idCliente],
      })
    );

    const contactoFormArray = this.fb.array(contactoFGs);
    this.contactosForm.setControl('contactos', contactoFormArray);
  }

  get contactos(): FormArray {
    return this.contactosForm.get('contactos') as FormArray;
  }

  createContactos(): FormGroup {
    return this.fb.group({
      documento: [
        '',
        [Validators.required, this.validatorsService.validateForeignerCard],
      ],
      nombre: [
        '',
        [Validators.required, this.validatorsService.validateFullname],
      ],
      telefono: [
        '',
        [Validators.required, this.validatorsService.validatePhone],
      ],
    });
  }

  generateMoreContacts(): void {
    this.contactos.push(this.createContactos());
  }

  submitFormContacts() {
    if (this.contactosForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const contactsArray = this.contactosForm.value.contactos.map(
      (contacto: IContacto) => ({
        idContacto: contacto.idContacto ? contacto.idContacto : 0,
        idCliente: +this.idCliente,
        documento: contacto.documento,
        nombre: contacto.nombre,
        telefono: contacto.telefono,
      })
    );


    if (contactsArray.length == 0) {
      this.alertService.showWarn(
        'Alerta!!',
        'Debe agregar al menos un contacto'
      );
      return;
    }

    this.updateSubscription.add(
      this.contactoService.updateContactoService$(contactsArray).subscribe({
        next: (res) => {
          this.loadContactsByIdClient();
          this.alertService.showSuccess('Exito!!', 'Se Agrego correctamente');
          
        },
        error: (error) => {
          this.alertService.showError(
            'Error',
            'Fallo al guardar, contactese con el administrador'
          );
        },
        complete: () => {this.isContactSidebarVisible = !this.isContactSidebarVisible}
      })
    );
  }



  removeContacts(event: Event, index: number, idContacto: number): void {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Estas seguro?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (!idContacto) {
          this.contactos.removeAt(index);
          this.alertService.showSuccess(
            'Confirmacion',
            'Contacto eliminado localmente'
          );
          return;
        }

        this.deleteSubscription.add(
          this.contactoService.deleteContactoService$(idContacto).subscribe({
            next: (res) => {
              this.loadContactsByIdClient();
              this.alertService.showSuccess(
                'Confirmacion',
                'Eliminaste el contacto correctamente'
              );
            },
            error: (error) => {
              this.alertService.showError(
                'Error',
                'Fallo al eliminar en la base de datos, contactese con el administrador'
              );
            },
          })
        );
      },
      reject: () => {
        this.alertService.showError('Rechazado', 'Direccion no eliminada');
      },
    });
  }

  ngOnDestroy(): void {
    this.loadSubscription.unsubscribe();
    this.deleteSubscription.unsubscribe();
    this.updateSubscription.unsubscribe();
  }
}
