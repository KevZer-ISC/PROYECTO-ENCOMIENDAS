import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DireccionesClienteComponent } from './direcciones-cliente.component';
import { SidebarModule } from 'primeng/sidebar';
import { StyleClassModule } from 'primeng/styleclass';
import { MaestrosPrimeNgModule } from 'src/app/core/themes/modules/maestros/maestros_primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService } from 'src/app/shared/shared';



@NgModule({
  declarations: [
    DireccionesClienteComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaestrosPrimeNgModule
  ],
  exports:[DireccionesClienteComponent],
  providers:[ConfirmationService, MessageService, AlertService, CustomErrorService]
})
export class DireccionesClienteModule { }
