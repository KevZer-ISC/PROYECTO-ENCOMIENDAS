import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { interval, Subscription } from 'rxjs';
import { IDireccion } from 'src/app/core/interfaces/interfaces';
import { DireccionService } from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';

@Component({
  selector: 'app-direcciones-cliente',
  templateUrl: './direcciones-cliente.component.html',
})
export class DireccionesClienteComponent implements OnInit, OnDestroy {
  direccionForm: FormGroup;
  direccionesSubmited: any[];
  isDirectionSidebarVisible: boolean = false;

  @Input() idCliente: string = '';
  direccionesApi: IDireccion[] = [];

  isNotError: boolean = true;

  /**
   * Subscripciones
   */
  private loadSubscription: Subscription = new Subscription();
  private updateSubscription: Subscription = new Subscription();
  private deleteSubscription: Subscription = new Subscription();

  constructor(
    private readonly fb: FormBuilder,
    private readonly validatorsService: ValidatorsService,
    private alertService: AlertService,
    private readonly direccionService: DireccionService,
    private readonly customErrorService: CustomErrorService,
    private confirmationService: ConfirmationService
  ) {
    this.direccionForm = this.fb.group({
      direcciones: this.fb.array([this.createDireccion()]),
    });
  }

  ngOnInit(): void {
  }

  loadDirectionByIdClient() {
    this.loadSubscription.add(
      this.direccionService
        .listarDireccionByIdClienteService$(+this.idCliente)
        .subscribe({
          next: (res: IDireccion[]) => {
            this.direccionesApi = res;
            this.setDirections(res);
          },
          error: (error) => {
            this.alertService.showError('Error', 'Direcciones no encontradas');
            this.customErrorService.listError(error);
            this.isNotError = false;
          },
        })
    );
  }

  setDirections(direcciones: IDireccion[]): void {
    const direccionFGs = direcciones.map((direccion) =>
      this.fb.group({
        direccion: [
          direccion.direccion,
          [Validators.required, this.validatorsService.validateAddress],
        ],
        idDireccion: [direccion.idDireccion],
        idCliente: [direccion.idCliente],
      })
    );
    const direccionFormArray = this.fb.array(direccionFGs);
    this.direccionForm.setControl('direcciones', direccionFormArray);
  }

  get direcciones(): FormArray {
    return this.direccionForm.get('direcciones') as FormArray;
  }

  createDireccion(): FormGroup {
    return this.fb.group({
      direccion: [
        '',
        [Validators.required, this.validatorsService.validateAddress],
      ],
    });
  }

  generateMoreDirections(): void {
    this.direcciones.push(this.createDireccion());
  }

  submitFormDirections(): void {
    if (this.direccionForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    const directionsArray = this.direccionForm.value.direcciones.map(
      (direccion: IDireccion) => ({
        idDireccion: direccion.idDireccion ? direccion.idDireccion : 0,
        idCliente: +this.idCliente,
        direccion: direccion.direccion,
      })
    );

    if (directionsArray.length == 0) {
      this.alertService.showWarn(
        'Alerta!!',
        'Debe agregar al menos una dirección'
      );
      return;
    }

    this.updateSubscription.add(
      this.direccionService.updateDireccionService$(directionsArray).subscribe({
        next: (res) => {
          this.loadDirectionByIdClient();
          this.alertService.showSuccess(
            'Exito!!',
            'Direccion Agregada correctamente'
          );
        },
        error: (error) => {
          this.alertService.showError(
            'Error',
            'Fallo al guardar, contactese con el administrador'
          );
        },
        complete: () => {
          this.isDirectionSidebarVisible = !this.isDirectionSidebarVisible;
        },
      })
    );
  }

  removeDireccion(event: Event, index: number, idDireccion: number) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Estas seguro?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (!idDireccion) {
          this.direcciones.removeAt(index);
          this.alertService.showSuccess(
            'Confirmacion',
            'Dirección eliminada localmente'
          );
          return;
        }

        this.deleteSubscription.add(
          this.direccionService.deleteDireccionService$(idDireccion).subscribe({
            next: (res) => {
              this.loadDirectionByIdClient();
              this.alertService.showSuccess(
                'Confirmacion',
                'Eliminaste la direccion correctamente'
              );
            },
            error: (error) => {
              this.alertService.showError(
                'Error',
                'Fallo al eliminar en la base de datos, contactese con el administrador'
              );
            },
          })
        );
      },
      reject: () => {
        this.alertService.showError('Rechazado', 'Direccion no eliminada');
      },
    });
  }

  ngOnDestroy(): void {
    this.loadSubscription.unsubscribe();
    this.deleteSubscription.unsubscribe();
    this.updateSubscription.unsubscribe();
  }
}
