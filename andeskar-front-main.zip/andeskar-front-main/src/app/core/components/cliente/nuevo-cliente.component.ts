import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { IDepartamento } from 'src/app/core/interfaces/interfaces';
import { ITypeDocument } from 'src/app/core/interfaces/maestros/ITipoDocumento.interface';
import { TipoDocumentoService } from 'src/app/core/service/service.core';
import {
  ClienteService,
  DepartamentoService,
} from 'src/app/services/service.root';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';
import { ReactiveValidatorsService } from 'src/app/shared/validators/reactive-validators.service';

@Component({
  selector: 'app-nuevo-cliente',
  templateUrl: './nuevo-cliente.component.html',
  styleUrls:['./nuevo-cliente-component.css']
})
export class NuevoClienteComponent implements OnInit {
  /**
   * Supscripciones activas para cada evento
   */
  docSubscriber: Subscription;
  departamentoSubscriber: Subscription;
  agencySubscriber: Subscription;

  /**
   * Variables de dropdowns
   */
  tipoDocumento: ITypeDocument[];
  departamento: IDepartamento[];

  isLoading: boolean = false;
  isDniSelected = true;
  isRucSelected = false;
  isCredito: boolean = true;

  @Output() messageEmit: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() contactoSidebarEmit: EventEmitter<void> = new EventEmitter<void>();
  @Output() directionSidebarEmit: EventEmitter<void> = new EventEmitter<void>();

  @Input() direcciones: any[] = [];
  @Input() contactos: any[] = [];

  clienteForm: FormGroup = this.fb.group({
    tipoDocumento: ['', []],
    documento: ['', []],
    nombre: ['', []],
    apellidos: ['', []],
    razonSocial: ['', []],
    ubigeo: ['', [Validators.required]],
    departamento: ['', []],
    telefono: [
      '',
      [Validators.required, this.customValidatorsService.validatePhone],
    ],
    correo: ['', [Validators.required, Validators.email]],
    direccion: ['', [Validators.required]],
    credito: [false, []],
  });

  constructor(
    private fb: FormBuilder,
    private readonly clienteService: ClienteService,
    private customErrorService: CustomErrorService,
    private readonly customValidatorsService: ValidatorsService,
    private readonly tipoDocumentoService: TipoDocumentoService,
    private readonly departamentoService: DepartamentoService,
    private reactiveValidators: ReactiveValidatorsService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.docSubscriber = this.tipoDocumentoService
      .listarTipoDocumentoService$()
      .subscribe({
        next: (res: ITypeDocument[]) => {
          this.isLoading = true;
          this.tipoDocumento = res;
        },
        error: (error) => this.customErrorService.listError(error),
        complete: () => (this.isLoading = false),
      });

    this.departamentoSubscriber = this.departamentoService
      .listarDepartamentosService$()
      .subscribe({
        next: (res: IDepartamento[]) => {
          this.isLoading = true;
          this.departamento = res;
        },
        error: (error) => this.customErrorService.listError(error),
        complete: () => (this.isLoading = false),
      });
  }

  onDocumentSelect({ value }: { value: any }) {
    let id = value.idTipoDocumento;
    this.isDniSelected =
      value.descripcion_TipoDocumento !== 'Registro Unico Contribuyente';
    this.isRucSelected = !this.isDniSelected;
    this.reactiveValidators.updateValidators(this.clienteForm, id);
  }

  get showDniFields(): boolean {
    return this.isDniSelected;
  }

  get showRucField(): boolean {
    return this.isRucSelected;
  }

  registrarCliente() {
    const {
      departamento: { idDepartamento },
      tipoDocumento: { idTipoDocumento },
    } = this.clienteForm.value;

    let data = {
      ...this.clienteForm.value,
      tipoDocumento: idTipoDocumento,
      departamento: idDepartamento,
      direcciones: this.direcciones ?? [],
      contactos: this.contactos ?? [],
    };

    if (this.clienteForm.invalid) {
      this.alertService.showWarn(
        'Alerta!!',
        'Verifique que los datos esten correctos'
      );
      return;
    }

    this.clienteService.insertClienteService$(data).subscribe({
      next: (res) => {
        this.isLoading = true;
        this.messageEmit.emit(!!res);
        this.clienteForm.reset();
      },
      error: (error) => this.customErrorService.listError(error),
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  showContacSidebarEmit() {
    this.contactoSidebarEmit.emit();
  }

  showDirectionSidebarEmit() {
    this.directionSidebarEmit.emit();
  }

  ngOnDestroy(): void {
    if (this.docSubscriber) {
      this.docSubscriber.unsubscribe();
    }
    if (this.departamentoSubscriber) {
      this.departamentoSubscriber.unsubscribe();
    }
    if (this.agencySubscriber) {
      this.agencySubscriber.unsubscribe();
    }
  }
}
