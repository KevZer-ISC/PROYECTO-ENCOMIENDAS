import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { MaestrosPrimeNgModule } from '../../themes/modules/maestros/maestros_primeng.module';
import { NuevoClienteComponent } from './nuevo-cliente.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgenciaService, ClienteService, DepartamentoService } from 'src/app/services/service.root';
import { TipoDocumentoService } from '../../service/service.core';
import { CustomErrorService, ValidatorsService } from 'src/app/shared/shared';


@NgModule({
  declarations: [
    NuevoClienteComponent
  ],
  imports: [
    CommonModule,
    MaestrosPrimeNgModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:[
    AgenciaService,
    DepartamentoService,
    TipoDocumentoService,
    ValidatorsService,
    ClienteService,
    CustomErrorService
  ],
  exports:[NuevoClienteComponent]
})
export class SharedClienteModule { }
