import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-detalle-orden',
  templateUrl: './detalle-orden.component.html',
})
export class DetalleOrdenComponent {
  @Input() isVisibleCardDetail: boolean ;
  @Output() onHiddeEmit: EventEmitter<void> = new EventEmitter<void>();

  onHidde(){
    this.onHiddeEmit.emit();
  }

  onShow(){}
}
