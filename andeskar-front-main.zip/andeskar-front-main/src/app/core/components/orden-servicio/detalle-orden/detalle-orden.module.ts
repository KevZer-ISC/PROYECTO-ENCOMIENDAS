import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleOrdenComponent } from './detalle-orden.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { CustomErrorService } from 'src/app/shared/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';


@NgModule({
  declarations: [
    DetalleOrdenComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OperacionesPrimeNgModule
  ],
  providers: [MessageService, ConfirmationService, AlertService, CustomErrorService],
  exports: [DetalleOrdenComponent]
})
export class DetalleOrdenModule { }
