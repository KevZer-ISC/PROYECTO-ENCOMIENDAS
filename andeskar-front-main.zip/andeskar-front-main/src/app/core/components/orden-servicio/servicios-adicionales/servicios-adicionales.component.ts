import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { CSERVICESADDITIONAL } from 'src/app/core/constants/operaciones/CServiciosAdicionales.constant';
import { IServicesAdditional } from 'src/app/core/interfaces/operaciones/IServiciosAdicionales.interfaces';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-servicios-adicionales',
  templateUrl: './servicios-adicionales.component.html',
})
export class ServiciosAdicionalesComponent implements OnInit, OnChanges {
  @Input() isVisibleCardService: boolean = true;
  @Output() onHiddeEmit: EventEmitter<void> = new EventEmitter<void>();

  value: number = 0;
  price: number = 0;
  descripcion: string = '';
  totalPrice: number = 0;
  isServicesDetailVisible: boolean = false;

  listServicesAdditional: IServicesAdditional[] = CSERVICESADDITIONAL;

  servicesSelected: IServicesAdditional[] = [];

  constructor(private alertService: AlertService,  private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {
  }

  chargeServices() {
    if (this.value === 0) {
      this.alertService.showInfo('Ups..', 'Seleccione un servicio adicional');
      return;
    }

    if (this.price === 0) {
      this.alertService.showInfo(
        'Ups..',
        'Agregue un Precio al servicio adicional'
      );
      return;
    }

    const service = {
      id: this.value,
      price: this.price,
      descripcion: this.descripcion,
      state: 'Activo',
      value: this.value,
    };

    this.servicesSelected = [...this.servicesSelected, service];

    this.calculateTotalPrice();

    this.value = 0;
    this.price = 0;
  }

  calculateTotalPrice() {
    this.totalPrice = this.servicesSelected.reduce((acc, curr) => {
      return acc + curr.price!;
    }, 0);
  }

  changeValue(id: number, descripcion: string) {
    this.value = id;
    this.descripcion = descripcion;
  }

  onHidde() {
    this.onHiddeEmit.emit();
  }

  onShow() {
    //TODO: ACA LANZAR EVENTOS DE CARGA
  }

  showDetailServicesAdditional() {
    if (this.servicesSelected.length === 0) {
      this.alertService.showInfo(
        'Ups..',
        'No hay servicios adicionales seleccionados'
      );
      return;
    }
    this.isServicesDetailVisible = !this.isServicesDetailVisible;
  }

  saveServicesAdditional() {
    if (this.servicesSelected.length === 0) {
      this.alertService.showInfo(
        'Ups..',
        'No hay servicios adicionales seleccionados'
      );
      return;
    }
    console.log(`Desde El padre servicios adcionales `);
    console.log(this.servicesSelected);
  }
}
