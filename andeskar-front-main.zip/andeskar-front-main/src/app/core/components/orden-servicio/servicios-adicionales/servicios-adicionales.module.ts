import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiciosAdicionalesComponent } from './servicios-adicionales.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CustomErrorService } from 'src/app/shared/shared';
import { AlertService } from 'src/app/shared/components/alert.service';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServiciosAdicionalesDetalleModule } from '../servicios-adicionales-detalle/servicios-adicionales-detalle.module';

@NgModule({
  declarations: [ServiciosAdicionalesComponent],
  imports: [
    CommonModule,
    OperacionesPrimeNgModule,
    FormsModule,
    ReactiveFormsModule,
    ServiciosAdicionalesDetalleModule,
  ],
  providers: [
    MessageService,
    ConfirmationService,
    AlertService,
    CustomErrorService,
  ],
  exports: [ServiciosAdicionalesComponent],
})
export class ServiciosAdicionalesModule {}
