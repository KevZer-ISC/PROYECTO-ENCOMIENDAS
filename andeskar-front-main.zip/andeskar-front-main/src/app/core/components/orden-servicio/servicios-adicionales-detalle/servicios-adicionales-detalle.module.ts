import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiciosAdicionalesDetalleComponent } from './servicios-adicionales-detalle.component';
import { MessageService } from 'primeng/api';
import { AlertService } from 'src/app/shared/components/alert.service';
import { OperacionesPrimeNgModule } from 'src/app/core/themes/modules/modules';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ServiciosAdicionalesDetalleComponent
  ],
  imports: [
    CommonModule,
    OperacionesPrimeNgModule,
    FormsModule, 
    ReactiveFormsModule
  ],
  providers:[MessageService, AlertService],
  exports: [ServiciosAdicionalesDetalleComponent]
})
export class ServiciosAdicionalesDetalleModule { }
