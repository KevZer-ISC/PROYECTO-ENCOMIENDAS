import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IServicesAdditional } from 'src/app/core/interfaces/operaciones/IServiciosAdicionales.interfaces';
import { AlertService } from 'src/app/shared/components/alert.service';

@Component({
  selector: 'app-servicios-adicionales-detalle',
  templateUrl: './servicios-adicionales-detalle.component.html',
})
export class ServiciosAdicionalesDetalleComponent {
  @Input() isServicesDetailVisible: boolean = false;
  @Output() onHiddeEmit: EventEmitter<void> = new EventEmitter<void>();
  @Input() servicesSelected: IServicesAdditional[] = [];
  @Output() calculatePriceEmit: EventEmitter<void> = new EventEmitter<void>();

  clonedProducts: { [s: string]: IServicesAdditional } = {};

  constructor(private alertService: AlertService) {}

  ngOnInit() {}

  onRowEditInit(product: IServicesAdditional) {
    this.clonedProducts[product.id as number] = { ...product };
  }

  onRowEditSave(product: IServicesAdditional) {
    if (product.price! > 0) {
      delete this.clonedProducts[product.id as number];
      this.calculatePriceEmit.emit();
      this.alertService.showSuccess('Exito', 'Producto actualizado');
    } else {
      this.alertService.showError('Error', 'Precio no puede ser 0');
    }
  }

  onRowEditCancel(product: IServicesAdditional, index: number) {
    this.servicesSelected[index] = this.clonedProducts[product.id as number];
    delete this.clonedProducts[product.id as number];
  }

  onRowDelete(index: number) {
    this.servicesSelected.splice(index, 1);
    this.calculatePriceEmit.emit();
    this.alertService.showSuccess('Exito', 'Producto eliminado');
  }

  onHidde() {
    this.onHiddeEmit.emit();
  }

  onShow() {}
}
