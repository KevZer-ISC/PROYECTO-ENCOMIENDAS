export interface IOrdenServicio{
    accion:string;
    fecha:string;
    numero:string;
    estado:string;
    pagoOrden:string;
    factura:string;
    usuario:string;
    guiaTransportista:string;
    manifiesto:string;
    desembarque:string;
    entrega:string;
    origen:string;
    re:string;
}