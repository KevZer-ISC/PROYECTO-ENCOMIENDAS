export interface IServicesAdditional {
    id:number;
    descripcion:string;
    state:string;
    value:number;
    price?:number;
    createdAt?:string;
}