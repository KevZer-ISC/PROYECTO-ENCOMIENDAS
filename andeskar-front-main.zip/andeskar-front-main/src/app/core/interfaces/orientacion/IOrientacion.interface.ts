export interface IOrientation{
    
}