import { IAgency } from '../interfaces';

export interface Itrajectory {//Solo es el objeto que recibe la API, no es para enviar
  id: number;
  nombre: string;
  origen: IAgency;
  destino: IAgency;
  totalTiempoAcumulado: number;
  totalOficinas: number;
  orientacion: number;
  estado:boolean
  detalle: IDetailAgencyTrajectory[];
}

export interface INewTrajectory {
  agencia: IAgency;
  viaje: string;
  estiba: string;
  isFixed?: boolean;
  isUpdating?: boolean;
  isRemovable?: boolean;
  orientacion: string;
  trayectoriaTipo:number
}


export interface IDetailAgencyTrajectory {
  id: number;
  orden: number;
  pasaPorIdSucursalVenta: any;
  tiempoLlegada: string;
  tiempoEstibaDesestiba:string;
  totalTiempoAcumulado: number;
  trayectoriaTipo:number
}


