
export interface IUsers{
    perfil:string;
    agencia:string;
  }
  
  