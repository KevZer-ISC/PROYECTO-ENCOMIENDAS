export interface IFormPayment{
    id:number;
    descripcion:string;
}

export interface IPersonPayment{
    idCliente:number; 
    pagador:string;
}