import { NgModule, inject } from '@angular/core';
import { RouterModule, Routes, mapToCanActivate } from '@angular/router';
import { AppLayoutComponent } from './components/layout/app.layout.component';
import { authGuard } from './shared/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./pages/auth/auth.module').then((m) => m.AuthModule),
  },
  {
    path: 'dashboard',
    component: AppLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
      },
      {
        path: 'operaciones',
        loadChildren: () =>
          import('./pages/operaciones/operaciones.module').then(
            (m) => m.OperacionesModule
          ),
      },
      {
        path: 'personal',
        loadChildren: () =>
          import('./pages/personal/personal.module').then(
            (m) => m.PersonalModule
          ),
      },
      {
        path: 'maestros',
        loadChildren: () =>
          import('./pages/maestros/maestros.module').then(
            (m) => m.MaestrosModule
          ),
      },
      {
        path:'mantenedor',
        loadChildren:()=>import('./pages/mantenedor/mantenedor.module').then(m=>m.MantenedorModule)
      }
    ],
  },
  {
    path: 'not-found',
    loadChildren: () =>
      import('./pages/not-found/not-found.module').then(
        (m) => m.NotFoundModule
      ),
  },
  {
    path:'**',
    redirectTo: 'not-found'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
