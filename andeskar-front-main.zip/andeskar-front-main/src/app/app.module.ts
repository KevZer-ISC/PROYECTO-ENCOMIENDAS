import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppLayoutModule } from './components/layout/app.layout.module';
import { RippleModule } from 'primeng/ripple';
import { StyleClassModule } from 'primeng/styleclass';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LocalStorageInterceptor } from './shared/interceptors/local-storage.interceptor';
import { CookieInterceptor } from './shared/interceptors/cookie.interceptor';
import { BearerTokenInterceptor } from './shared/interceptors/bearer-token.interceptor';
import { MessageService } from 'primeng/api';
import { AlertService } from './shared/components/alert.service';

@NgModule({
  declarations: [AppComponent ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppLayoutModule,
    RippleModule,
    StyleClassModule,
    HttpClientModule,

  ],
  providers: [
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: LocalStorageInterceptor,
    //   multi: true,
    // },
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: CookieInterceptor,
    //   multi: true,
    // },

    {
      provide: HTTP_INTERCEPTORS,
      useClass: BearerTokenInterceptor,
      multi: true,
    },
    MessageService,
    AlertService
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
