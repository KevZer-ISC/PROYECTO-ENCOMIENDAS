import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { IGenericArrays, Itrajectory } from 'src/app/core/interfaces/interfaces';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TrayectoriaService {

  private base_url = environment.URL_BACKEND;



  constructor(private httpClient:HttpClient) { }




  listarTrayectoriaService$(data:any):Observable<Itrajectory[]>{
    const direccion = `${this.base_url}/Trayectoria/Listar`;
    return this.httpClient.post<IGenericArrays<Itrajectory>>(direccion, data)
    .pipe(
      map((response:IGenericArrays<Itrajectory>)=>response.data)
    )
  };





  obtenerTrayectoriaByIdService(id:number){}

  insertarTrayectoria(data:any):Observable<any>{
    const direccion = `${this.base_url}/Trayectoria/Insert`;
    return this.httpClient.post<any>(direccion,data);
  }

}
