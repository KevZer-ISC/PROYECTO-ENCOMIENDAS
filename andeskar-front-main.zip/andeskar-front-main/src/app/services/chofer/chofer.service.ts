import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ChoferService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }
  
  obtenerChoferService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Chofer/ObtenerChofer`;
    return this.httpClient
      .get<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarChoferService$(): Observable<any> {
    const direccion = `${this.base_url}/Chofer/ListarChofer`;
    return this.httpClient
      .get<any>(direccion)
      .pipe(catchError(this.handleError));
  }

  insertChoferService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Chofer/Insert`;
    return this.httpClient
      .post<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  updateChoferService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Chofer/Update`;
    return this.httpClient
      .put<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  deleteChoferService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Chofer/Delete`;
    return this.httpClient
      .delete<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }
}
