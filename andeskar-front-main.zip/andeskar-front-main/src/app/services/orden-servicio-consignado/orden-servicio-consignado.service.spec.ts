import { TestBed } from '@angular/core/testing';

import { OrdenServicioConsignadoService } from './orden-servicio-consignado.service';

describe('OrdenServicioConsignadoService', () => {
  let service: OrdenServicioConsignadoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OrdenServicioConsignadoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
