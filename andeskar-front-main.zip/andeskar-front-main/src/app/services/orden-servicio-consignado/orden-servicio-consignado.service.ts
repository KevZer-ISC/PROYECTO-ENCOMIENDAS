import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class OrdenServicioConsignadoService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  ordenServicioConsignadoService$(id: number) {}

  listarOrdenServicioConsignadoService$() {}

  insertOrdenServicioConsignadoService$(data: any) {}

  updateOrdenServicioConsignadoService$(data: any) {}
  
  deleteOrdenServicioConsignadoService$(id: number) {}
}
