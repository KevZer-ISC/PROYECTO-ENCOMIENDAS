import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DocumentoReferenciaService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}
  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }
  obtenerDocumentoReferenciaService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/DocumentoReferencia/ObtenerDocumentoReferencia`;
    return this.httpClient
      .get<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarDocumentoReferenciaService$(): Observable<any> {
    const direccion = `${this.base_url}/DocumentoReferencia/ListarDocumentoReferencia`;
    return this.httpClient
      .get<any>(direccion)
      .pipe(catchError(this.handleError));
  }

  insertDocumentoReferenciaService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/DocumentoReferencia/Insert`;
    return this.httpClient
      .post<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  updateDocumentoReferenciaService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/DocumentoReferencia/Update`;
    return this.httpClient
      .put<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  deleteDocumentoReferenciaService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/DocumentoReferencia/Delete`;
    return this.httpClient
      .delete<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }
}
