import { TestBed } from '@angular/core/testing';

import { DocumentoReferenciaService } from './documento-referencia.service';

describe('DocumentoReferenciaService', () => {
  let service: DocumentoReferenciaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocumentoReferenciaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
