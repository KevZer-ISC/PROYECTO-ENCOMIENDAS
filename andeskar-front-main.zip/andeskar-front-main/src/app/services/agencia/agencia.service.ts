import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import { IAgency } from 'src/app/core/interfaces/agencias/IAgencia.interface';
import { IGenericArrays } from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AgenciaService {
  base_url: string = environment.URL_BACKEND;
  auth_url: string = environment.URL_AUTH;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerAgenciaService$(id: number): Observable<IAgency> {
    const direccion = `${this.base_url}/Agencia/ObtenerAgencia`;
    return this.httpClient
      .get<IAgency>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarAgenciaService$(): Observable<IAgency[]> {
    const direccion = `${this.base_url}/Agencia/ListarAgencia`;
    return this.httpClient
      .get<IGenericArrays<IAgency>>(direccion)
      .pipe(
        map((response:IGenericArrays<IAgency>)=>response.data)
      );
  }

  insertAgenciaService$(data: any): Observable<string> {
    const direccion = `${this.base_url}/Agencia/Insert`;
    return this.httpClient
      .post<string>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  updateAgenciaService$(data: any): Observable<string> {
    const direccion = `${this.base_url}/Agencia/Update`;
    return this.httpClient
      .put<string>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  deleteAgenciaService$(id: number): Observable<string> {
    const direccion = `${this.base_url}/Agencia/Delete`;
    return this.httpClient
      .delete<string>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarAgenciaByDocTrabajadorService$(
    documento: string
  ): Observable<IAgency[]> {
    const direccion = `${this.auth_url}/Seguridad/ListarAgenciaByDocumentoTrabajador`;
    return this.httpClient
      .get<IAgency[]>(direccion, { params: { documento } })
      .pipe(catchError(this.handleError));
  }
}
