import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthCookieService } from 'src/app/core/service/cookie/cookie.service';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  base_url: string = environment.URL_AUTH;

  constructor(
    private readonly httpClient: HttpClient,
    private readonly customErrorService: CustomErrorService,
    private authCookieService:AuthCookieService
  ) {}

  loginService$(data: any) {
    let direccion = `${this.base_url}/Seguridad/Autenticacion`;

    return this.httpClient.post<any>(direccion, data).pipe(
      catchError((err) => {
        this.customErrorService.listError(err);
        return throwError(() => err);
      })
    );
  }

  refreshTokenSerive$() {
    let token = this.authCookieService.getToken();
    let data = {
      "refreshToken": token
    }
    let direccion = `${this.base_url}/Seguridad/RefreshToken`;
    return this.httpClient.post<any>(direccion, data).pipe(
      catchError((err) => {
        this.customErrorService.listError(err);
        this.logoutService$();
        return throwError(() => err);
      })
    );
  }


  registerService$() {}

  checkStatusService$() {
    return this.authCookieService.getToken();
  }


  logoutService$(){
    this.authCookieService.clearToken();
  }
}
