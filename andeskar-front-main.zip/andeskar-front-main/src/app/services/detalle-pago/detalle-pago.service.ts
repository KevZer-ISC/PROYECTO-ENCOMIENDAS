import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DetallePagoService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}
  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }
  obtenerDetallePagoService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/DetallePago/ObtenerDetallePago`;
    return this.httpClient
      .get<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarDetallePagoService$(): Observable<any> {
    const direccion = `${this.base_url}/DetallePago/ListarDetallePago`;
    return this.httpClient
      .get<any>(direccion)
      .pipe(catchError(this.handleError));
  }

  insertDetallePagoService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/DetallePago/Insert`;
    return this.httpClient
      .post<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  updateDetallePagoServie$(data: any): Observable<any> {
    const direccion = `${this.base_url}/DetallePago/Update`;
    return this.httpClient
      .put<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  deleteDetallePagoService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/DetallePago/Delete`;
    return this.httpClient
      .delete<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }
}
