import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import {
  IDireccion,
  IGeneric,
  IGenericArrays,
} from 'src/app/core/interfaces/interfaces';

import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DireccionService {
  private base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private readonly customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerDireccionService$(id: number): Observable<IDireccion> {
    const direccion = `${this.base_url}/Direccion/ObtenerDireccion?Id=1`;
    return this.httpClient.get<any>(direccion);
  }

  listarDireccionService$(): Observable<IDireccion[]> {
    const direccion = `${this.base_url}/Direccion/ObtenerDireccion?Id=1`;
    return this.httpClient.get<IDireccion[]>(direccion);
  }

  insertDireccionService$(): Observable<any> {
    const direccion = `${this.base_url}/Direccion/ObtenerDireccion?Id=1`;
    return this.httpClient.post<any>(direccion, {});
  }

  updateDireccionService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Direccion/Update`;
    return this.httpClient.put<any>(direccion, data);
  }

  deleteDireccionService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Direccion/ActivoInactivo`;
    return this.httpClient.delete<any>(direccion, { params: { Id: id } });
  }

  listarDireccionByIdClienteService$(
    idcliente: number,
    estado: number = 1
  ): Observable<IDireccion[]> {
    const direccion = `${this.base_url}/Direccion/ListarDireccionByIdCliente`;
    return this.httpClient
      .post<IGenericArrays<IDireccion>>(
        direccion,
        {},
        {
          params: {
            idcliente: idcliente.toString(),
            estado: estado.toString(),
          },
        }
      )
      .pipe(
        map((response: IGenericArrays<IDireccion>) => response.data),
      );
  }
}
