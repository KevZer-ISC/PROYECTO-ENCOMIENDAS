import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, catchError, map, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';
import {
  ICliente,
  IGeneric,
  IGenericArrays,
} from 'src/app/core/interfaces/interfaces';

@Injectable({
  providedIn: 'root',
})
export class ClienteService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}
  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerClienteService$(id: number): Observable<ICliente> {
    const direccion = `${this.base_url}/Cliente/ObtenerCliente`;
    return this.httpClient
      .get<IGeneric<ICliente>>(direccion, { params: { id } })
      .pipe(
        map((response: IGeneric<ICliente>) => response.data),
        catchError(this.handleError)
      );
  }



  listarClienteService$(inactivo: boolean = false): Observable<ICliente[]> {
    const direccion = `${this.base_url}/Cliente/ListarCliente`;
    return this.httpClient
      .post<IGenericArrays<ICliente>>(direccion, inactivo)
      .pipe(map((response:IGenericArrays<ICliente>)=>response.data))
  }



  insertClienteService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Cliente/Insert`;
    return this.httpClient
      .post<any>(direccion, data)
  }



  updateClienteService$(data: any): Observable<IGeneric<boolean>> {
    const direccion = `${this.base_url}/Cliente/Update`;
    return this.httpClient
      .put<IGeneric<boolean>>(direccion, data)
  }




  deleteClienteService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Cliente/ActivarDesactivar`;
    return this.httpClient
      .delete<any>(direccion, { params: { id } })
  }



  buscarClienteByDocService$(data: any): Observable<ICliente> {
    const direccion = `${this.base_url}/Cliente/BuscarClienteByTipoByDocumento`;
    return this.httpClient
      .post<IGeneric<ICliente>>(direccion, data)
      .pipe(map((response:IGeneric<ICliente>)=>response.data));

  }
}
