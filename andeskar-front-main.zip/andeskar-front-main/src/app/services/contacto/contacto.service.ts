import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, throwError } from 'rxjs';
import { IGenericArrays } from 'src/app/core/interfaces/interfaces';
import { IContacto } from 'src/app/core/interfaces/maestros/IContacto.interface';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ContactoService {
  private base_url: string = environment.URL_BACKEND;
  private estado: number = 1;

  constructor(
    private readonly httppClient: HttpClient,
    private readonly customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  
  obtenerContactoService$(Id: number): Observable<IContacto> {
    const direccion = `${this.base_url}/Contacto/ObtenerContacto`;
    return this.httppClient.get<IContacto>(direccion, { params: { Id } });
  }

  listarContactoService$(
    estado: number = this.estado
  ): Observable<IContacto[]> {
    const direccion = `${this.base_url}/Contacto/ListarContacto`;
    return this.httppClient.get<IContacto[]>(direccion, { params: { estado } });
  }

  insertContactoService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Contacto/Insert`;
    return this.httppClient.post<any>(direccion, data);
  }

  updateContactoService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Contacto/Update`;
    return this.httppClient.put<any>(direccion, data);
  }

  deleteContactoService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Contacto/ActivoInactivo`;
    return this.httppClient.delete<any>(direccion, { params: { Id: id } });
  }

  listarContactoByIdService(idcliente: number): Observable<IContacto[]> {
    const direccion = `${this.base_url}/Contacto/ListarContactoByIdCliente`;
    return this.httppClient
      .post<IGenericArrays<IContacto>>(
        direccion,
        {},
        {
          params: {
            idcliente,
            estado: 1,
          },
        }
      )
      .pipe(map((response: IGenericArrays<IContacto>) => response.data));
  }



}
