import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ComprobanteService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}
  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerComprobanteService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Comprobante/ObtenerComprobante`;
    return this.httpClient
      .get<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }

  listarCompobanteService$(): Observable<any> {
    const direccion = `${this.base_url}/Comprobante/ListarComprobante`;
    return this.httpClient
      .get<any>(direccion)
      .pipe(catchError(this.handleError));
  }

  insertComprobanteService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Comprobante/Insert`;
    return this.httpClient
      .post<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  updateComprobanteService$(data: any): Observable<any> {
    const direccion = `${this.base_url}/Comprobante/Update`;
    return this.httpClient
      .put<any>(direccion, data)
      .pipe(catchError(this.handleError));
  }

  deleteComprobanteService$(id: number): Observable<any> {
    const direccion = `${this.base_url}/Cliente/Delete`;
    return this.httpClient
      .get<any>(direccion, { params: { id } })
      .pipe(catchError(this.handleError));
  }
}
