import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class OrdenServicioItemService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  obtenerOrdenServicioItemService$(id: number) {}

  listarOrdenServicioItemService$() {}

  insertOrdenServicioItemService$(data: any) {}

  updateOrdenServicioItemService$(data: any) {}
  
  deleteOrdenServicioItemService$(id: number) {}
}
