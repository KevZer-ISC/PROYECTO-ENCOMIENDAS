import { TestBed } from '@angular/core/testing';

import { OrdenServicioItemService } from './orden-servicio-item.service';

describe('OrdenServicioItemService', () => {
  let service: OrdenServicioItemService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OrdenServicioItemService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
