import { TestBed } from '@angular/core/testing';

import { ClienteNoDeseadoService } from './cliente-no-deseado.service';

describe('ClienteNoDeseadoService', () => {
  let service: ClienteNoDeseadoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClienteNoDeseadoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
