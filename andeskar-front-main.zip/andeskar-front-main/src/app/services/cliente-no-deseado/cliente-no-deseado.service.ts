import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import {
  IClienteNoDeseado,
  IGeneric,
} from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ClienteNoDeseadoService {
  private base_url: string = environment.URL_BACKEND;
  private estado: number = 1;

  constructor(
    private httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  obtenerClienteNoDeseadoService$(id: number) {}

  obtenerClienteByDocumentoService$(data: any): Observable<IClienteNoDeseado> {
    let direccion = `${this.base_url}/ClienteNoDeseado/ObtenerClienteNoDeseadoByTipoNumero`;
    return this.httpClient
      .post<IGeneric<IClienteNoDeseado>>(direccion, data)
      .pipe(map((response: IGeneric<IClienteNoDeseado>) => response.data));
  }

  listarClienteNoDeseadoService$(estado = this.estado) {}

  insertClienteNoDeseadoService$(data: any): Observable<any> {
    let direccion = `${this.base_url}/ClienteNoDeseado/Insert`;
    return this.httpClient.post<any>(direccion, data);
  }

  updateClienteNoDeseadoService$(data: any) {}
  deleteClienteNoDeseadoService$(id: number) {}
}
