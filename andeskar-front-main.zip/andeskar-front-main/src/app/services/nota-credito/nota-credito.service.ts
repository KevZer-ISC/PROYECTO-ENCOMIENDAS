import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomErrorService } from 'src/app/shared/Errors/custom_error.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NotaCreditoService {

  base_url: string = environment.URL_BACKEND;
  
  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) { }

  obtenerNotaCreditoService$(id:number){}

  listarNotaCreditoService$(){}

  insertNotaCreditoService$(data:any){}

  updateNotaCreditoService$(data:any){}

  deleteNotaCreditoService$(id:number){}
}
