import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { IDepartamento } from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DepartamentoService {
  private base_url = environment.URL_BACKEND;

  constructor(
    private readonly customErrorService: CustomErrorService,
    private readonly httpClient: HttpClient
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  obtenerDepartamentoService$(id: number) {}

  listarDepartamentosService$(): Observable<IDepartamento[]> {
    let direccion = `${this.base_url}/Departamento/ListarDepartamento`;
    return this.httpClient
      .get<IDepartamento[]>(direccion)
      .pipe(catchError(this.handleError));
  }

  insertDepartamentoService$(data: any) {}
  updateDepartamentoService$(data: any) {}
  deleteDepartamentoService$(id: number) {}
}
