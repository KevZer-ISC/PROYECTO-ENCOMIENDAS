import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { ITypePayment } from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TipoPagoService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  listarTipoPagoService$(): Observable<ITypePayment[]> {
    const direccion = `${this.base_url}/TipoPago/ListarComboTipoPago`;
    return this.httpClient
      .get<ITypePayment[]>(direccion)
      .pipe(catchError(this.handleError));
  }
}
