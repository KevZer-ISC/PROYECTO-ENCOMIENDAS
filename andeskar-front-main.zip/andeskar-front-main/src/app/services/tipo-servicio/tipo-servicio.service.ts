import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import {
  IGenericArrays,
  ITypeService,
} from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TipoServicioService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  private handleError(error: any): Observable<never> {
    this.customErrorService.listError(error);
    return throwError(() => error);
  }

  listaTipoServicioService$(): Observable<ITypeService[]> {
    const direccion = `${this.base_url}/TipoServicio/ListarComboTipoServicio`;
    return this.httpClient
      .get<IGenericArrays<ITypeService>>(direccion)
      .pipe(map((response: IGenericArrays<ITypeService>) => response.data));
  }
}
