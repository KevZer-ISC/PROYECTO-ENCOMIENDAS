import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import { IGenericArrays, ITypeDelivery } from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TipoEntregaService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}



  listarTipoEntregaService$(): Observable<ITypeDelivery[]> {
    const direccion = `${this.base_url}/TipoEntrega/ListarComboTipoEntrega`;
    return this.httpClient
      .get<IGenericArrays<ITypeDelivery>>(direccion)
      .pipe(
        map((response:IGenericArrays<ITypeDelivery>)=>response.data)
      )
  }
}
