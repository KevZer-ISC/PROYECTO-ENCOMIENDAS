import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { IFormPayment } from 'src/app/core/interfaces/forma-pago/IFormaPago.interface';
import { IGenericArrays } from 'src/app/core/interfaces/interfaces';
import { CustomErrorService } from 'src/app/shared/shared';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class FormaPagoService {
  base_url: string = environment.URL_BACKEND;

  constructor(
    private readonly httpClient: HttpClient,
    private customErrorService: CustomErrorService
  ) {}

  obtenerFormaPagoService$(data: any): Observable<IFormPayment[]> {
    const direccion = `${this.base_url}/FormaPago/ObtenerFormaPago`;
    return this.httpClient
      .post<any>(direccion, data)
      .pipe(map((response: IGenericArrays<IFormPayment>) => response.data));
  }
}
