# FrontAndeskar

Este proyecto fue generado con [Angular CLI](https://github.com/angular/angular-cli) version 16.2.14.


## Instalaciones Necesarias
- version 16.2.14 [Angular CLI](https://github.com/angular/angular-cli)
- version 20.12.2 [NodeJs](https://nodejs.org/en) 
- version 1.89 [Visual Studio Code](https://code.visualstudio.com/)
- version 10.5.0 [Npm](https://www.npmjs.com/)




## Servidor de Desarrollo

Antes de levantar el servidor, ejecutar el comando de `npm install` en la raiz del proyecto para descargar toda la paqueteria de NodeJs necesaria para la ejecucion

Ejecutar `ng serve` para inicializar el servidor y navegar a `http://localhost:4200/`, recordar que `4200` es el puerto.

El server se recargara automaticamente asi que no es necesario bajar el servidor y volver a levantarlo.


## Dependencias

Nombre | Versión | Uso
------------ | ------------- | -------------
[jwt-decode](https://www.npmjs.com/package/jwt-decode) | 4.0.0 | Decodificar el JWT para tener acceso a las propiedades que contiene.
[ngx-cookie-service](https://www.npmjs.com/package/ngx-cookie-service) | 16.1.0 | Generar Cookies que serviran para mejorar la seguridadad, autentificación y autorización.
[primeflex](https://primeflex.org/) | 3.3.1 | Sistema de estilos Css para posicionamiento, grid, responsividad, etc.
[primeicons](https://primeng.org/icons) | 7.0.0 | Iconos de Css.
[primeng](https://primeng.org/) | 16.4.1 | Libreria de UI/UX para la customización de estilos en angular.


## Rutas API (API Routes)
Las rutas son muchas, asi que no se puede establecer en esta parte, por ello dentro del codigo hay una carpeta que contiene todas las rutas que puede revisar, la carpeta se encuentra en: `src/app/services`


## Menciones Necesarias
Es necesario mencionar que algunos estilos CSS fueron usados por la paqueteria y libreria de [PrimeBlocks](https://www.primefaces.org/primeblocks-jsf/), por ello es necesario mencionar que dichos componentes que usan esta libreria estan bajo sujetos de licencia de dicha organizacion. El codigo usado no debe ser duplicado ni retribuido a mas proyectos sin previa autorizacion del desarrollador que posea la licencia.