using FluentValidation;
using FluentValidation.AspNetCore;
using ILogica.Seguridad;
using Logica;
using Logica.Seguridad.SeguridadJwtAuthorization;
using Logica.Seguridad.SeguridadJwtMiddleware;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Modelos.Request;
using Modelos.Response;
using ProyectoApiMySql.Validaciones;
using System.Text;
using Utilitarios.JWT;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers(opciones => opciones.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true).AddJsonOptions(opciones =>
{
    opciones.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;

});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpContextAccessor();
builder.Services.AddApplication(builder.Configuration.GetConnectionString("Conexion").ToString());
// Configurar AutoMapper
builder.Services.AddAutoMapper(typeof(Program));
// Configurar FluentValidation
builder.Services.AddScoped<IValidator<ClienteRequest>, ValidacionCliente>();
builder.Services.AddScoped<IValidator<OrdenServicioRequest>, ValidacionOrdenServicio>();
builder.Services.AddScoped<IValidator<ContactosClienteRequest>, ValidacionContactoCliente>();
builder.Services.AddScoped<IValidator<DireccionesClienteRequest>, ValidacionDireccionCliente>();
builder.Services.AddScoped<IValidator<ClienteNoDeseadoRequest>, ValidacionClienteNoDeseado>();
builder.Services.AddScoped<IValidator<BusquedaClienteRequest>, ValidacionBusquedaCliente>();
builder.Services.AddScoped<IValidator<TrayectoriaResponse>, ValidacionTrayectoria>();
builder.Services.AddSwaggerGen(c =>
{

    c.SwaggerDoc("v1", new OpenApiInfo { Title = "ApiSql", Version = "v1" });
    var jwtSecurityScheme = new OpenApiSecurityScheme
    {
        BearerFormat = "JWT",
        Name = "TokenAutorizacion",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = JwtBearerDefaults.AuthenticationScheme,
        Description = "Put **_ONLY_** your JWT Bearer token on textbox below",
        Reference = new OpenApiReference
        {
            Id = "ApiSql",
            Type = ReferenceType.SecurityScheme
        }
    };
    c.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { jwtSecurityScheme,Array.Empty<string>()}
       });
});
JwtConfig.JwtConfigHelper(builder.Configuration);
builder.Services.AddAuthentication().AddJwtBearer(jwt =>
{
    jwt.SaveToken = true;
    jwt.RequireHttpsMetadata = false;
    jwt.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(JwtConfig.JwtSecret)),
        ValidateIssuer = JwtConfig.JwtValidateIssuer, // for dev
        ValidateAudience = JwtConfig.JwtValidateAudience, // for dev
        RequireExpirationTime = JwtConfig.JwtRequireExpirationTime, // for dev -- needs to be updated when refresh token is added
        ValidateLifetime = JwtConfig.JwtValidateLifetime,

    };

});
builder.Services.AddSingleton<IAuthorizationHandler, OperationAuthorizerHandler>();
// global cors policy
//builder.Services.AddCors(options =>
//{
//    options.AddPolicy("AnyOrigin", builder =>
//    {
//        builder.AllowAnyOrigin()
//                                                        .AllowAnyMethod()
//                                                        .AllowAnyHeader()
//                                                        .SetIsOriginAllowed(origin => true)
//                                                        .AllowCredentials();
//    });
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}
app.UseCors(options =>
{
    options
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .AllowAnyMethod();
});
//app.UseCors("AnyOrigin");
app.UseMiddleware<ErrorHandlerMiddleware>();
app.UseMiddleware<JwtMiddleware>();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();


app.MapControllers();

app.Run();
