﻿using FluentValidation;
using Modelos.Request;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionBusquedaCliente : AbstractValidator<BusquedaClienteRequest>
    {
        public ValidacionBusquedaCliente()
        {
            RuleFor(c => c.IdTipoDocumento).NotNull().WithMessage("El Tipo de Documento no Existe");
            When(c => c.IdTipoDocumento == 1, () =>
            {
                RuleFor(c => c.Documento).Length(8).WithMessage("El Documento debe tener 8 caracteres");
            });
            When(c => c.IdTipoDocumento == 2, () =>
            {
                RuleFor(c => c.Documento).Length(11).WithMessage("El Documento debe tener 11 caracteres");
            });

        }
    }
}
