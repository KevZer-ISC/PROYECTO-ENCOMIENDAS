﻿using FluentValidation;
using Modelos.Request;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionCliente : AbstractValidator<ClienteRequest>
    {
        public ValidacionCliente()
        {
           RuleFor(c => c.TipoDocumento).NotNull().WithMessage("El Tipo de Documento no Existe");
            //RuleFor(c => c.Direcciones).NotNull().WithMessage("Debe tener al Menos una Direccion");
            When(c => c.TipoDocumento == 1, () =>
            {
                RuleFor(c => c.Documento).Length(8).WithMessage("El Documento debe tener 8 caracteres");
                RuleFor(c => c.Nombre).NotNull().NotEmpty().WithMessage("No contiene El Nombre");
                RuleFor(c => c.Apellidos).NotNull().NotEmpty().WithMessage("No contiene El Apellido");

            });
            When(c => c.TipoDocumento == 2, () =>
            {
                RuleFor(c => c.Documento).Length(11).WithMessage("El Documento debe tener 11 caracteres");
                When(n => string.IsNullOrEmpty(n.RazonSocial), () =>
                {
                    RuleFor(c => c.Nombre).NotNull().NotEmpty().WithMessage("No contiene El Nombre");
                    RuleFor(c => c.Apellidos).NotNull().NotEmpty().WithMessage("No contiene El Apellido");
                });
            });
            When(c => c.TipoDocumento == 3, () =>
            {
                RuleFor(c => c.Documento).MinimumLength(7).MaximumLength(12).WithMessage("El Documento debe tener entre 7 y 12 caracteres");
                When(n => string.IsNullOrEmpty(n.RazonSocial), () =>
                {
                    RuleFor(c => c.Nombre).NotNull().NotEmpty().WithMessage("No contiene El Nombre");
                    RuleFor(c => c.Apellidos).NotNull().NotEmpty().WithMessage("No contiene El Apellido");
                });
            });
            When(c => c.TipoDocumento == 4, () =>
            {
                RuleFor(c => c.Documento).MinimumLength(5).MaximumLength(12).WithMessage("El Documento debe tener entre 5 y 12 caracteres");
                When(n => string.IsNullOrEmpty(n.RazonSocial), () =>
                {
                    RuleFor(c => c.Nombre).NotNull().NotEmpty().WithMessage("No contiene El Nombre");
                    RuleFor(c => c.Apellidos).NotNull().NotEmpty().WithMessage("No contiene El Apellido");
                });
            });
            
        }

    }
}
