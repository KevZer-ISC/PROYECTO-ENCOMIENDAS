﻿using FluentValidation;
using Modelos.Request;
using Utilitarios;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionOrdenServicio : AbstractValidator<OrdenServicioRequest>
    {
        public ValidacionOrdenServicio()
        {
            RuleFor(c => c.Idorigen).NotNull().NotEmpty().WithMessage("No ha selecionado Origen");
            RuleFor(c => c.Iddestino).NotNull().NotEmpty().WithMessage("No ha selecionado Destino");
            RuleFor(c => c.Idremitente).NotNull().NotEmpty().WithMessage("No ha selecionado Remitente");
            RuleFor(c => c.Iddestinatario).NotNull().NotEmpty().WithMessage("No ha selecionado Destinatario");
            RuleFor(c => c.Idtiposervicio).NotNull().NotEmpty().WithMessage("No ha selecionado Tipo de Servicio");
            RuleFor(c => c.IdtipoEntrega).NotNull().NotEmpty().WithMessage("No ha selecionado Tipo de Entrega");
            RuleFor(c => c.IdformaPago).NotNull().NotEmpty().WithMessage("No ha selecionado  Forma de Pago");
            RuleFor(c => c.IdresponsablePago).NotEmpty().NotNull().WithMessage("No ha selecionado Responsable Pago");
            When(c => c.IdtipoEntrega == (int)GlobalEnum.TipoEntrega.Delivery, () =>
            {
                RuleFor(x => x.DireccionEntrega).NotNull().NotEmpty().MinimumLength(5).WithMessage("La Direccion de entrega es necesaria para el tipo de entrega seleccionada y debe ser mayo a 5 caracteres");
            });
            When(c => c.IdTipoRecepcion == (int)GlobalEnum.TipoEntrega.Delivery, () =>
            {
                RuleFor(x => x.DireccionRecepcion).NotNull().NotEmpty().MinimumLength(5).WithMessage("La Direccion de recepcion es necesaria para el tipo de recepcion seleccionada y debe ser mayo a 5 caracteres");
            });
        }
    }
}
