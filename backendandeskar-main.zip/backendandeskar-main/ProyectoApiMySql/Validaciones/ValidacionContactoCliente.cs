﻿using FluentValidation;
using Modelos.Request;
using Modelos.Response;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionContactoCliente:AbstractValidator<ContactosClienteRequest>
    {
        public ValidacionContactoCliente() { 
        RuleFor(c=>c.IdCliente).NotNull().WithMessage("No Tiene Cliente Relacionado");
        RuleFor(c=>c.Documento).NotNull().NotEmpty().MinimumLength(7).WithMessage("El Documento no se encuentra o tiene menos de 7 caracteres");
        RuleFor(c=>c.Nombre).NotNull().NotEmpty().MinimumLength(8).WithMessage("El Nombre no se encuentra o tiene menos de 8 caracteres");

        
        }
    }
}
