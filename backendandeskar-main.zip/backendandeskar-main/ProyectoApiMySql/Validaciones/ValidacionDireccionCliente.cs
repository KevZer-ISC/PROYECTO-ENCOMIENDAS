﻿using FluentValidation;
using Modelos.Request;
using Modelos.Response;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionDireccionCliente : AbstractValidator<DireccionesClienteRequest>
    {
        public ValidacionDireccionCliente()
        {
            RuleFor(c => c.IdCliente).NotNull().WithMessage("No tiene Asociado Ningun Cliente");
            RuleFor(c => c.Direccion).NotNull().NotEmpty().MinimumLength(8).WithMessage("Debe Ingresar la direccion con un minimo de 8 caracteres");
        }
    }
}
