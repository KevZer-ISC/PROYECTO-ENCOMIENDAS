﻿using FluentValidation;
using Modelos.Response;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionTrayectoria : AbstractValidator<TrayectoriaResponse>
    {
        public ValidacionTrayectoria()
        {
            RuleFor(c => c.Origen).NotNull().WithMessage("El Origen no esta declarado");
            RuleFor(c => c.Destino).NotNull().WithMessage("El Destino no esta declarado");
            RuleFor(c => c.Nombre).NotNull().WithMessage("El Nombre no esta definido");
            RuleFor(c => c.Orientacion).NotNull().WithMessage("La orientacion no esta definida");
            RuleFor(c => c.Detalle).NotNull().WithMessage("No existe detalle");
            RuleForEach(x => x.Detalle).ChildRules(order =>
            {
                order.RuleFor(x => x.Orden).NotNull().WithMessage("Un Registro del detalle no tiene orden");
                order.When(x => x.Orden > 1, () =>
                {
                    order.RuleFor(x => x.PasaPorIdSucursalVenta).NotNull().WithMessage("Un Registro del detalle no tiene sucursal");
                    order.RuleFor(x => x.TiempoLlegada).NotNull().WithMessage("Un Registro del detalle no tiene Tiempo Llegada");
                    order.RuleFor(x => x.TiempoEstibaDesestiba).NotNull().WithMessage("Un Registro del detalle no tiene Tiempo Estiba");
                    order.RuleFor(x => x.TotalTiempoAcumulado).NotNull().WithMessage("Un Registro del detalle no tiene Tiempo Acumulado");
                    order.RuleFor(x => x.TrayectoriaTipo).NotNull().WithMessage("Un Registro del detalle no tiene Tipo Trayectoria");
                   order.RuleFor(x => x.TiempoLlegada).Must(distino00).WithMessage("Un Registro del detalle no tiene Tiempo Llegada");

                });
                order.RuleFor(x => x.TiempoLlegada).NotNull().WithMessage("Un Registro del detalle no tiene Tiempo Llegada");
                order.RuleFor(x => x.TiempoLlegada).Length(5).WithMessage("Un tiempo de Llegada del detalle no tiene el formato corecto");
                order.RuleFor(x => x.TiempoLlegada).Must(Contienedospuntos).WithMessage("Un tiempo de Llegada del detalle no cuenta con los Dos puntos de separacion");
                order.RuleFor(x => x.TiempoLlegada).Must(formatocorrecto).WithMessage("Un tiempo de Llegada del detalle no cuenta con el formato correcto");
            
                order.RuleFor(x => x.TiempoEstibaDesestiba).NotNull().WithMessage("Un Registro del detalle no tiene Tiempo EstibaDesestiba");
                order.RuleFor(x => x.TiempoEstibaDesestiba).Length(5).WithMessage("Un tiempo de EstibaDesestiba del detalle no tiene el formato corecto");
                order.RuleFor(x => x.TiempoEstibaDesestiba).Must(Contienedospuntos).WithMessage("Un tiempo de EstibaDesestiba del detalle no cuenta con los Dos puntos de separacion");
                order.RuleFor(x => x.TiempoEstibaDesestiba).Must(formatocorrecto).WithMessage("Un tiempo de EstibaDesestiba del detalle no cuenta con el formato correcto");
            
            });
        }
        protected bool Contienedospuntos(string cadena) => cadena.Contains(':');
        protected bool formatocorrecto(string cadena)
        {
            string[] tiempo = cadena.Split(':');
            bool continuar = true;
            tiempo.ToList().ForEach(t =>
            {
                if (t.Length != 2) continuar = false;
            });
            return continuar;
        }
        protected bool distino00(string cadena)
        {
            string[] tiempo = cadena.Split(':');
            if (tiempo[0].ToString()=="00" && tiempo[1].ToString()=="00")
                return false;
            return true;
        }
    }


}
