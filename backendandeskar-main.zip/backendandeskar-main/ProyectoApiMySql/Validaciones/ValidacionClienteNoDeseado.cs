﻿using FluentValidation;
using Modelos.Request;

namespace ProyectoApiMySql.Validaciones
{
    public class ValidacionClienteNoDeseado : AbstractValidator<ClienteNoDeseadoRequest>
    {
        public ValidacionClienteNoDeseado() {
            RuleFor(x=>x.IdtipoDocumento).NotEmpty().WithMessage("No tiene Tipo Documento");
            RuleFor(x => x.Documento).NotEmpty().WithMessage("No tiene Numero de Documento");
            RuleFor(x => x.Nombre).NotEmpty().WithMessage("No tiene Nombre");
        }
    }
}
