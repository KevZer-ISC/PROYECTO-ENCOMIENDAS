﻿using AutoMapper;
using Entidades;
using ILogica.Seguridad;
using Microsoft.IdentityModel.Tokens;
using Modelos.Request;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Mapper
{
    public class ToMapper : Profile
    {

        public ToMapper()
        {


            CreateMap<ClienteRequest, ClienteEe>()
                    .ForMember(des => des.IdCliente, origen => origen.MapFrom(ori => ori.Id))
                    .ForMember(des => des.FK_TipoDocumento, origen => origen.MapFrom(ori => ori.TipoDocumento))
                    .ForMember(des => des.FK_Departamento, origen => origen.MapFrom(ori => ori.Departamento))
                    .ForMember(des => des.FK_Sucursal, origen => origen.MapFrom(ori => ori.Oficina))
                    .ForMember(des => des.Documento, origen => origen.MapFrom(ori => ori.Documento))
                    .ForMember(des => des.Nombres, origen => origen.MapFrom(ori => ori.Nombre))
                    .ForMember(des => des.Apellidos, origen => origen.MapFrom(ori => ori.Apellidos))
                    .ForMember(des => des.NombreCompleto, origen => origen.MapFrom(ori => string.IsNullOrEmpty(ori.RazonSocial) ? $"{ori.Nombre} {ori.Apellidos}" : ori.RazonSocial))
                    .ForMember(des => des.Ubigeo, origen => origen.MapFrom(ori => ori.Ubigeo))
                    .ForMember(des => des.Direccion, origen => origen.MapFrom(ori => ori.Direccion))
                    .ForMember(des => des.Telefono, origen => origen.MapFrom(ori => ori.Telefono))
                    .ForMember(des => des.Correo, origen => origen.MapFrom(ori => ori.Correo))
                    .ForMember(des => des.Contacto, origen => origen.MapFrom(ori => ori.Contacto))
                    .ForMember(des => des.Direcciones, origen => origen.MapFrom(ori => ori.Direcciones))
                    .ForMember(des => des.Contactos, origen => origen.MapFrom(ori => ori.Contactos))
                    .ForMember(des => des.Credito, origen => origen.MapFrom(ori => ori.Credito))
                    ;
            CreateMap<ClienteEe, ClienteRequest>()
                    .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdCliente))
                    .ForMember(des => des.TipoDocumento, origen => origen.MapFrom(ori => ori.FK_TipoDocumento))
                    .ForMember(des => des.Departamento, origen => origen.MapFrom(ori => ori.FK_Departamento))
                    .ForMember(des => des.Oficina, origen => origen.MapFrom(ori => ori.FK_Sucursal))
                    .ForMember(des => des.Documento, origen => origen.MapFrom(ori => ori.Documento))
                    .ForMember(des => des.Nombre, origen => origen.MapFrom(ori => ori.Nombres))
                    .ForMember(des => des.Apellidos, origen => origen.MapFrom(ori => ori.Apellidos))
                    .ForMember(des => des.RazonSocial, origen => origen.MapFrom(ori => ori.NombreCompleto))
                    .ForMember(des => des.Ubigeo, origen => origen.MapFrom(ori => ori.Ubigeo))
                    .ForMember(des => des.Direccion, origen => origen.MapFrom(ori => ori.Direccion))
                    .ForMember(des => des.Telefono, origen => origen.MapFrom(ori => ori.Telefono))
                    .ForMember(des => des.Correo, origen => origen.MapFrom(ori => ori.Correo))
                    .ForMember(des => des.Contacto, origen => origen.MapFrom(ori => ori.Contacto))
                    .ForMember(des => des.Direcciones, origen => origen.MapFrom(ori => ori.Direcciones))
                    .ForMember(des => des.Contactos, origen => origen.MapFrom(ori => ori.Contactos))
                    .ForMember(des => des.Credito, origen => origen.MapFrom(ori => ori.Credito))
                    ;
            CreateMap<DireccionesClienteRequest, ClienteDireccionEe>()
                    .ForMember(des => des.IdClienteDireccion, origen => origen.MapFrom(ori => ori.IdDireccion))
                    .ForMember(des => des.IdCliente, origen => origen.MapFrom(ori => ori.IdCliente))
                    .ForMember(des => des.Direccion, origen => origen.MapFrom(ori => ori.Direccion))
                    .ReverseMap();
            CreateMap<DireccionesClienteResponse, ClienteDireccionEe>()
                    .ForMember(des => des.IdClienteDireccion, origen => origen.MapFrom(ori => ori.IdDireccion))
                    .ForMember(des => des.IdCliente, origen => origen.MapFrom(ori => ori.IdCliente))
                    .ForMember(des => des.Direccion, origen => origen.MapFrom(ori => ori.Direccion))
                    .ForMember(des => des.Activo, origen => origen.MapFrom(ori => ori.Activo))
                    .ReverseMap();
            CreateMap<ContactosClienteRequest, ClienteContactoEe>()
                    .ForMember(des => des.IdClienteContacto, origen => origen.MapFrom(ori => ori.IdContacto))
                    .ForMember(des => des.IdCliente, origen => origen.MapFrom(ori => ori.IdCliente))
                    .ForMember(des => des.NombreContacto, origen => origen.MapFrom(ori => ori.Nombre))
                    .ForMember(des => des.TelefonoContacto, origen => origen.MapFrom(ori => ori.Telefono))
                    .ForMember(des => des.NumeroDocumento, origen => origen.MapFrom(ori => ori.Documento))
                    .ReverseMap();

            CreateMap<ContactosClienteResponse, ClienteContactoEe>()
                    .ForMember(des => des.IdClienteContacto, origen => origen.MapFrom(ori => ori.IdContacto))
                    .ForMember(des => des.IdCliente, origen => origen.MapFrom(ori => ori.IdCliente))
                    .ForMember(des => des.NombreContacto, origen => origen.MapFrom(ori => ori.Nombre))
                    .ForMember(des => des.TelefonoContacto, origen => origen.MapFrom(ori => ori.Telefono))
                    .ForMember(des => des.NumeroDocumento, origen => origen.MapFrom(ori => ori.Documento))
                    .ForMember(des => des.Activo, origen => origen.MapFrom(ori => ori.Activo))
                    .ReverseMap();




            CreateMap<TipoServicioEe, TipoServicioResponse>()
                    .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdTipoServicio))
                    .ForMember(des => des.Descripcion, origen => origen.MapFrom(ori => ori.DescripcionTipoServicio))
                    .ForMember(des => des.Estado, origen => origen.MapFrom(ori => ori.Activo))
                    .ForMember(des => des.CreatedAt, origen => origen.MapFrom(ori => ori.FechaCreacion))
                    .ReverseMap();
            CreateMap<TipoPagoEe, TipoPagoResponse>()
                    .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdTipoPago))
                    .ForMember(des => des.Descripcion, origen => origen.MapFrom(ori => ori.DescripcionTipoPago))
                    .ForMember(des => des.Estado, origen => origen.MapFrom(ori => ori.Activo))
                    .ForMember(des => des.CreatedAt, origen => origen.MapFrom(ori => ori.FechaCreacion))
                    .ReverseMap();
            CreateMap<TipoEntregaEe, TipoEntregaResponse>()
                    .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdTipoEntrega))
                    .ForMember(des => des.Descripcion, origen => origen.MapFrom(ori => ori.DescripcionTipoEntrega))
                    .ForMember(des => des.Estado, origen => origen.MapFrom(ori => ori.Activo))
                    .ForMember(des => des.CreatedAt, origen => origen.MapFrom(ori => ori.FechaCreacion))
                    .ReverseMap();

            CreateMap<ClienteEe, ClienteResponse>()
                       .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdCliente))
                       .ForMember(des => des.Documento, origen => origen.MapFrom(ori => ori.Documento))
                       .ForMember(des => des.Nombre, origen => origen.MapFrom(ori => ori.Nombres))
                       .ForMember(des => des.Apellidos, origen => origen.MapFrom(ori => ori.Apellidos))
                       .ForMember(des => des.NombreCompleto, origen => origen.MapFrom(ori => ori.NombreCompleto))
                       .ForMember(des => des.Ubigeo, origen => origen.MapFrom(ori => ori.Ubigeo))
                       .ForMember(des => des.Telefono, origen => origen.MapFrom(ori => ori.Telefono))
                       .ForMember(des => des.Correo, origen => origen.MapFrom(ori => ori.Correo))
                       .ForMember(des => des.Contacto, origen => origen.MapFrom(ori => ori.Contacto))
                       .ForMember(des => des.Direccion, origen => origen.MapFrom(ori => ori.Direccion))
                       .ForMember(des => des.Activo, origen => origen.MapFrom(ori => ori.Activo))
                       .ForMember(des => des.Credito, origen => origen.MapFrom(ori => ori.Credito))
                       .ReverseMap();



            CreateMap<OrdenServicioRequest, OrdenServicioEe>()
                    .ForMember(des => des.IdUsuario, origen => origen.MapFrom(ori => ori.IdUsuario))
                    .ForMember(des => des.IdOrigen, origen => origen.MapFrom(ori => ori.Idorigen))
                    .ForMember(des => des.IdDestino, origen => origen.MapFrom(ori => ori.Iddestino))
                    .ForMember(des => des.IdTipoServicio, origen => origen.MapFrom(ori => ori.Idtiposervicio))
                    .ForMember(des => des.IdTipoEntrega, origen => origen.MapFrom(ori => ori.IdtipoEntrega))
                    .ForMember(des => des.IdFormaPago, origen => origen.MapFrom(ori => ori.IdformaPago))
                    .ForMember(des => des.IdRemitente, origen => origen.MapFrom(ori => ori.Idremitente))
                    .ForMember(des => des.IdDestinatario, origen => origen.MapFrom(ori => ori.Iddestinatario))
                    .ForMember(des => des.PersonaContacto, origen => origen.MapFrom(ori => ori.Personacontacto))
                    .ForMember(des => des.IdPersonaContacto, origen => origen.MapFrom(ori => ori.IdpersonaContacto))
                    .ForMember(des => des.DireccionEntrega, origen => origen.MapFrom(ori => ori.DireccionEntrega))
                    .ForMember(des => des.IdResponsablePago, origen => origen.MapFrom(ori => ori.IdresponsablePago))
                    .ForMember(des => des.TotalUnidades, origen => origen.MapFrom(ori => ori.TotalUnidades))
                    .ForMember(des => des.TotalPeso, origen => origen.MapFrom(ori => ori.Totalpeso))
                    .ForMember(des => des.TotalBulto, origen => origen.MapFrom(ori => ori.TotalBulto))
                    .ForMember(des => des.TotalVolumen, origen => origen.MapFrom(ori => ori.TotalVolumen))
                    .ForMember(des => des.TotalDescuento, origen => origen.MapFrom(ori => ori.Totaldescuento))
                    .ForMember(des => des.TotalImporte, origen => origen.MapFrom(ori => ori.TotalImporte))
                    .ForMember(des => des.SubTotal, origen => origen.MapFrom(ori => ori.SubTotal))
                    .ForMember(des => des.IGV, origen => origen.MapFrom(ori => ori.IGV))
                    .ForMember(des => des.FechaOrden, origen => origen.MapFrom(ori => ori.FechaOrden))
                    .ReverseMap();

            CreateMap<ClienteNoDeseadoEe, ClienteNoDeseadoResponse>()
                .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.IdClienteNoDeseado))
                .ForMember(des => des.IdtipoDocumento, origen => origen.MapFrom(ori => ori.IdTipoDocumento))
                .ForMember(des => des.Documento, origen => origen.MapFrom(ori => ori.NumeroDocumento))
                .ForMember(des => des.Nombre, origen => origen.MapFrom(ori => ori.NombreCompleto))
                .ForMember(des => des.Observacion, origen => origen.MapFrom(ori => ori.Observacion))
                .ForMember(des => des.Activo, origen => origen.MapFrom(ori => ori.Activo))
                .ReverseMap();
            CreateMap<ClienteNoDeseadoRequest, ClienteNoDeseadoEe>()
                 .ForMember(des => des.IdClienteNoDeseado, origen => origen.MapFrom(ori => ori.Id))
                .ForMember(des => des.IdTipoDocumento, origen => origen.MapFrom(ori => ori.IdtipoDocumento))
                .ForMember(des => des.NumeroDocumento, origen => origen.MapFrom(ori => ori.Documento))
                .ForMember(des => des.NombreCompleto, origen => origen.MapFrom(ori => ori.Nombre))
                .ForMember(des => des.Observacion, origen => origen.MapFrom(ori => ori.Observacion))
                .ReverseMap();
            CreateMap<TrayectoriaResponse, TrayectoriaEe>()
                .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.Id))
                .ForMember(des => des.Nombre, origen => origen.MapFrom(ori => ori.Nombre))
                .ForMember(des => des.FK_Origen, origen => origen.MapFrom(ori => ori.Origen.Id))
                .ForMember(des => des.FK_Destino, origen => origen.MapFrom(ori => ori.Destino.Id))
                .ForMember(des => des.TotalTiempoAcumulado, origen => origen.MapFrom(ori => ori.TotalTiempoAcumulado))
                .ForMember(des => des.TotalOficinas, origen => origen.MapFrom(ori => ori.TotalOficinas))
                .ForMember(des => des.Orientacion_Id, origen => origen.MapFrom(ori => (int)ori.Orientacion))
                .ReverseMap();
            CreateMap<TrayectoriaDetalleResponse, TrayectoriaDetalleEe>()
                .ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.Id))
                .ForMember(des => des.Orden, origen => origen.MapFrom(ori => ori.Orden))
                .ForMember(des => des.PasaPor_IdSucursalVenta, origen => origen.MapFrom(ori => ori.PasaPorIdSucursalVenta.Id))
                .ForMember(des => des.TiempoLlegadaMinutos, origen => origen.MapFrom(ori =>formatominutosaint( ori.TiempoLlegada)))
                .ForMember(des => des.TiempoEstibaDesestibaMinutos, origen => origen.MapFrom(ori => formatominutosaint(ori.TiempoEstibaDesestiba)))
                .ForMember(des => des.TotalTiempoAcumulado, origen => origen.MapFrom(ori => ori.TotalTiempoAcumulado))
                .ForMember(des => des.TrayectoriaTipo_Id, origen => origen.MapFrom(ori => (int)ori.TrayectoriaTipo))
                ;
         //   CreateMap<TrayectoriaDetalleEe, TrayectoriaDetalleResponse>()
         //.ForMember(des => des.Id, origen => origen.MapFrom(ori => ori.Id))
         //.ForMember(des => des.Orden, origen => origen.MapFrom(ori => ori.Orden))
         //.ForMember(des => des.PasaPorIdSucursalVenta.Id, origen => origen.MapFrom(ori => ori.PasaPor_IdSucursalVenta))
         //.ForMember(des =>des.TiempoLlegada , origen => origen.MapFrom(ori => ori.TiempoLlegadaMinutos))
         //.ForMember(des => des.TiempoEstibaDesestiba, origen => origen.MapFrom(ori =>formatominutosastring((int) ori.TiempoEstibaDesestibaMinutos) ))
         //.ForMember(des => des.TotalTiempoAcumulado, origen => origen.MapFrom(ori =>formatominutosastring((int) ori.TotalTiempoAcumulado)))
         //.ForMember(des =>(int)des.TrayectoriaTipo , origen => origen.MapFrom(ori => ori.TrayectoriaTipo_Id))
         //;

        }
        private string formatominutosastring(int tiempo)
        {
            int Horas = tiempo / 60;
            int minutos = tiempo % 60;
            return $"{Horas.ToString("D2")}:{minutos.ToString("D2")}";
        }
        private int formatominutosaint(string tiempo)
        {
            string[] cadena = tiempo.Split(':');
            return ConvertForce.toInt(cadena[0]) * 60 + ConvertForce.toInt(cadena[1]);
        }
    }
}
