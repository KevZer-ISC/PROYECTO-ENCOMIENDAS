﻿using Entidades;
using ILogica;
using ILogica.Auditoria;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class ChoferController : ControllerBase
    {
        private readonly IChofer _mediator;
        private readonly IAuditoria _auditoria;
        public ChoferController(IChofer mediator,IAuditoria auditoria)
        {
            _mediator = mediator;
            _auditoria = auditoria;
        }

        [HttpGet("ObtenerChofer")]
        public async Task<IActionResult> ObtenerChofer(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
 
        [HttpPost("ListarChofer")]
        public async Task<IActionResult> ListarChofer()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(ChoferEe obj)
        {
            try
            {
                _auditoria.SetAuditFieldsForInsert(obj);
                var listado = _mediator.Insert(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(ChoferEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.ID_Chofer);
                if (ee == 0) throw new Exception("Id no encontrado");
                _auditoria.SetAuditFieldsForUpdate(obj);
                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjeto(Id);
                if (ee == null||ee.ID_Chofer==0) throw new Exception("Id no encontrado");
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.Delete(ee);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
