﻿using AutoMapper;
using FluentValidation;
using ILogica.Auditoria;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Response;
using Entidades;
using Utilitarios;
using Modelos.Request;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactoController : ControllerBase
    {
        private readonly IClienteContacto _mediator;
        private readonly IAuditoria _auditoria;
        private readonly IMapper _mapper;
        private readonly IValidator<ContactosClienteRequest> _validator;
        public ContactoController(IClienteContacto mediator,IAuditoria auditoria,IMapper mapper,IValidator<ContactosClienteRequest> validator)
        {
            _auditoria = auditoria;
            _mediator = mediator;   
            _mapper = mapper;
            _validator = validator;

        }
        [HttpGet("ObtenerContacto")]
        public async Task<IActionResult> ObtenerContacto(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                var result=_mapper.Map<ContactosClienteResponse>(listado);
                var respuesta = new ToReturn<ContactosClienteResponse>(result);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ContactosClienteResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        //[OperationAuthorize(GlobalConstant.RlVisualizar, GlobalConstant.MnTrabajador)]
        [HttpGet("ListarContacto")]
        public async Task<IActionResult> ListarAgencia(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            try
            {
                var Listado= _mediator.ListaObjeto(estado);
                var result=_mapper.Map<IEnumerable<ContactosClienteResponse>>(Listado);
                if (result.Any()) {
                    var respuesta = new ToReturnList<ContactosClienteResponse>(result);
                    return StatusCode(respuesta.Status, respuesta);
                }
      
                var error = new ToReturnNoEncontrado<ContactosClienteResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ContactosClienteResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(ContactosClienteRequest obj)
        {
            try
            {
                var valida = _validator.Validate(obj);
                if (!valida.IsValid)
                {
                    var result = new ToReturnValidation<ContactosClienteRequest>(valida);
                    return StatusCode(result.Status, result);

                }
                var direccion = _mapper.Map<ClienteContactoEe>(obj);
                _auditoria.SetAuditFieldsForInsert(direccion);
                var listado = _mediator.Insert(direccion);
                var respuesta = new ToReturn<int>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ContactosClienteRequest>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(List<ContactosClienteRequest> arr)
        {
            try
            {
                foreach (var obj in arr.Where(x => x.IdContacto != 0))
                {
                    var valida = _validator.Validate(obj);
                    if (!valida.IsValid)
                    {
                        var result = new ToReturnValidation<ContactosClienteRequest>(valida);
                        return StatusCode(result.Status, result);

                    }

                    var ee = _mediator.ObtenerObjetoId(obj.IdContacto);
                    if (ee == 0)
                    {
                        var result = new ToReturnError<ContactosClienteRequest>("El Contacto a actualizar no existe");
                        return StatusCode(result.Status, result);
                    }
                }
                var contacto = _mapper.Map<List<ClienteContactoEe>>(arr);
                foreach (var e in contacto)
                {
                    if (e.IdClienteContacto == 0) _auditoria.SetAuditFieldsForInsert(e);
                    else
                        _auditoria.SetAuditFieldsForUpdate(e);
                }
                var listado = _mediator.Update(contacto);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ContactosClienteRequest>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpDelete("ActivoInactivo")]
        public async Task<IActionResult> ActivoInactivo(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjeto(Id);
                if (ee == null || ee.IdClienteContacto == 0)
                {
                    var result = new ToReturnError<ContactosClienteResponse>("El Contacto a actualizar no existe");
                    return StatusCode(result.Status, result);
                }
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.Delete(ee);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("ListarContactoByIdCliente")]

        public async Task<IActionResult> ListarDireccionByIdCliente(int idcliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            try
            {
                var listado = _mediator.ListarByIdCliente(idcliente, estado);
                var result = _mapper.Map<IEnumerable<ContactosClienteResponse>>(listado);
                var respuesta = new ToReturnList<ContactosClienteResponse>(result);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ContactosClienteResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }


       

    }
}
