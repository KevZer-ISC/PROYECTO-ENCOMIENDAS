﻿using AutoMapper;
using Entidades;
using FluentValidation;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Request;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class OrdenServicioController : ControllerBase
    {
        private readonly IOrdenServicio _mediator;
        private readonly IAgenciaTipoComprobante _AgenciaTipoComprobante;
        private readonly IValidator<OrdenServicioRequest> _Validator;
        private readonly IMapper _mapper;
        public OrdenServicioController(IOrdenServicio mediator, IMapper mapper, IValidator<OrdenServicioRequest> validator, IAgenciaTipoComprobante AgenciaTipoComprobante)
        {
            _mediator = mediator;
            _mapper = mapper;
            _Validator = validator;
            _AgenciaTipoComprobante = AgenciaTipoComprobante;
        }

        [HttpGet("ObtenerOrdenServicio")]
        public async Task<IActionResult> ObtenerOrdenServicio(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("ListarOrdenServicio")]
        public async Task<IActionResult> ListarOrdenServicio()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(OrdenServicioRequest obj)
        {
            try
            {
                var valida = _Validator.Validate(obj);
                if (!valida.IsValid)
                {
                    var result = new ToReturnValidation<OrdenServicioRequest>(valida);
                    return StatusCode(result.Status, result);
                }
                var orden = _mapper.Map<OrdenServicioEe>(obj);
                var ObjSerie = _AgenciaTipoComprobante.ObtenerByUsuario(GlobalEnum.TipoComprobante.OS);
                if (ObjSerie == null || ObjSerie.IdAgenciaComprobante == 0)
                {
                    var result = new ToReturnError<OrdenServicioRequest>("La Serie de la Sucursal no existe");
                    return StatusCode(result.Status, result);
                }
                orden.Serie = ObjSerie.Serie;
                orden.Correlativo = Utilitarios.Convert.Correlativos(ObjSerie.Correlativo + 1);
                var listado = _mediator.Insert(orden);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                var result = new ToReturnError<OrdenServicioRequest>(ex.Message);
                return StatusCode(result.Status, result);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(OrdenServicioEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.Id_Orden);
                if (ee == 0) throw new Exception("Id no encontrado");

                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(Id);
                if (ee == 0) throw new Exception("Id no encontrado");
                var listado = _mediator.Delete(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
