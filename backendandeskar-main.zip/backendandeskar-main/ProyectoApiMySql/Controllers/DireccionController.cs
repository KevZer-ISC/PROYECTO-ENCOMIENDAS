﻿using ILogica.Auditoria;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using FluentValidation;
using Modelos.Response;
using Entidades;
using Utilitarios;
using Modelos.Request;
using AutoMapper;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DireccionController : ControllerBase
    {
        private readonly IClienteDireccion _mediator;
        private readonly IAuditoria _auditoria;
        private readonly IMapper _mapper;
        private readonly IValidator<DireccionesClienteRequest> _validator;

        public DireccionController(IClienteDireccion mediator, IAuditoria auditoria, IValidator<DireccionesClienteRequest> validator, IMapper mapper)
        {
            _mediator = mediator;
            _auditoria = auditoria;
            _validator = validator;
            _mapper = mapper;
        }
        [HttpGet("ObtenerDireccion")]
        public async Task<IActionResult> ObtenerDireccion(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                var result = _mapper.Map<DireccionesClienteResponse>(listado);
                var respuesta = new ToReturn<DireccionesClienteResponse>(result);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        //[OperationAuthorize(GlobalConstant.RlVisualizar, GlobalConstant.MnTrabajador)]
        [HttpGet("ListarDireccion")]
        public async Task<IActionResult> ListarAgencia(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            try
            {
                var Listado = _mediator.ListaObjeto(estado);
                if (Listado.Any() && Listado.Count > 0)
                {
                    var result = _mapper.Map<IEnumerable<DireccionesClienteResponse>>(Listado);
                    var respuesta = new ToReturnList<DireccionesClienteResponse>(result);
                    return StatusCode(respuesta.Status, respuesta);

                }

                var error = new ToReturnNoEncontrado<DireccionesClienteResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(DireccionesClienteRequest obj)
        {
            try
            {
                var valida = _validator.Validate(obj);
                if (!valida.IsValid)
                {
                    var result = new ToReturnValidation<DireccionesClienteRequest>(valida);
                    return StatusCode(result.Status, result);

                }
                var direccion = _mapper.Map<ClienteDireccionEe>(obj);
                _auditoria.SetAuditFieldsForInsert(direccion);
                var listado = _mediator.Insert(direccion);
                var respuesta = new ToReturn<int>(listado);
                return StatusCode(respuesta.Status, respuesta);

            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(List<DireccionesClienteRequest> arr)
        {
            try
            {
                foreach (var obj in arr.Where(x => x.IdDireccion != 0))
                {
                    var valida = _validator.Validate(obj);
                    if (!valida.IsValid)
                    {
                        var result = new ToReturnValidation<DireccionesClienteRequest>(valida);
                        return StatusCode(result.Status, result);

                    }

                    var ee = _mediator.ObtenerObjetoId(obj.IdDireccion);
                    if (ee == 0)
                    {
                        var result = new ToReturnError<DireccionesClienteRequest>("La direccion a actualizar no existe");
                        return StatusCode(result.Status, result);
                    }
                }
                var direccion = _mapper.Map<List<ClienteDireccionEe>>(arr);
                foreach (var e in direccion)
                {
                    if (e.IdClienteDireccion == 0) _auditoria.SetAuditFieldsForInsert(e);
                    else
                        _auditoria.SetAuditFieldsForUpdate(e);
                }
                var listado = _mediator.Update(direccion);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpDelete("ActivoInactivo")]
        public async Task<IActionResult> ActivoInactivo(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjeto(Id);
                if (ee == null || ee.IdClienteDireccion == 0)
                {
                    var result = new ToReturnError<DireccionesClienteRequest>("La direccion a actualizar no existe");
                    return StatusCode(result.Status, result);
                }
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.Delete(ee);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("ListarDireccionByIdCliente")]

        public async Task<IActionResult> ListarDireccionByIdCliente(int idcliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            try
            {
                var listado = _mediator.ListarByIdCliente(idcliente, estado);
                var result = _mapper.Map<IEnumerable<DireccionesClienteResponse>>(listado);
                var respuesta = new ToReturnList<DireccionesClienteResponse>(result);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoServicioResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
    }
}
