﻿using Azure.Core;
using Entidades;
using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using ILogica;
using Modelos.Request;
using Utilitarios;
using Modelos.Response;
using ILogica.Auditoria;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class ClienteController : ControllerBase
    {
        private readonly ICliente _mediator;
        private readonly IClienteNoDeseado _mediatorC;
        private readonly IDepartamento _departamento;
        private readonly ITipoDocumento _tipodocumento;
        private readonly IConsultaSunatReniec _SunatReniec;
        private readonly IValidator<ClienteRequest> _Validator;
        private readonly IValidator<BusquedaClienteRequest> _ValidatorBusqueda;
        private readonly IMapper _mapper;
        private readonly IAuditoria _auditoria;
        public ClienteController(ICliente mediator,
            IClienteNoDeseado mediatorC,
            IValidator<ClienteRequest> validator,
            IValidator<BusquedaClienteRequest> validatorBusqueda,
            IMapper mapper, IAuditoria auditoria,
            IDepartamento departamento,
            ITipoDocumento tipoDocumento,
            IConsultaSunatReniec SunatReniec)
        {
            _mediator = mediator;
            _Validator = validator;
            _mapper = mapper;
            _auditoria = auditoria;
            _departamento = departamento;
            _tipodocumento = tipoDocumento;
            _mediatorC = mediatorC;
            _SunatReniec = SunatReniec;
            _ValidatorBusqueda = validatorBusqueda;
        }

        [HttpGet("ObtenerCliente")]
        public async Task<IActionResult> ObtenerCliente(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                if (listado == null || listado.IdCliente == 0)
                {
                    var notfound = new ToReturnNoEncontrado<ClienteResponse>();
                    return StatusCode(notfound.Status, notfound);
                }
                var result = _mapper.Map<ClienteResponse>(listado);
                result.TipoDocumento = listado.FK_TipoDocumento != null ? _tipodocumento.ObtenerObjeto((int)listado.FK_TipoDocumento) : null;
                result.Departamento = listado.FK_Departamento != null ? _departamento.ObtenerObjeto((int)listado.FK_Departamento) : null;
                var response = new ToReturn<ClienteResponse>(result);

                return StatusCode(response.Status, response);
            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<ClienteResponse>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }
        [HttpPost("ListarCliente")]
        public async Task<IActionResult> ListarCliente()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                var map = _mapper.Map<IEnumerable<ClienteResponse>>(listado);
                var response = new ToReturnList<ClienteResponse>(map);

                return StatusCode(response.Status, response);
            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<ClienteResponse>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }
        [HttpPost("BuscarClienteByTipoByDocumento")]
        public async Task<IActionResult> BuscarClienteByTipoByDocumento(BusquedaClienteRequest request)
        {
            try
            {
                var validar = _ValidatorBusqueda.Validate(request);
                if (!validar.IsValid)
                {
                    var resul = new ToReturnValidation<ClienteRequest>(validar);
                    return StatusCode(resul.Status, resul);
                }



                var noencontrado = _mediatorC.ObtenerObjetoByDocumento(request.IdTipoDocumento, request.Documento);
                if (noencontrado != null && noencontrado.IdClienteNoDeseado != 0)
                {
                    var resul = new ToReturnValidation<ClienteRequest>(noencontrado.Observacion);
                    return StatusCode(resul.Status, resul);
                }
                var result = _mediator.ObtenerObjetoByDocumentoTipoDocumento(request.IdTipoDocumento, request.Documento, GlobalEnum.Estado.Todos);
                if (result != null && result.IdCliente != 0)
                {
                    if (!result.Activo)
                    {
                        var Inactivo = new ToReturnNoEncontrado<ClienteRequest>("Cliente Inactivo");
                        return StatusCode(Inactivo.Status, Inactivo);
                    }
                    var rr = new ToReturn<ClienteRequest>(_mapper.Map<ClienteRequest>(result));
                    return StatusCode(rr.Status, rr);
                }
                ClienteEe cliente = new ClienteEe();
                switch (request.IdTipoDocumento)
                {
                    case 1:
                        cliente = await _SunatReniec.ConsultarDni(request.Documento);
                        break;
                    case 2:
                        cliente = await _SunatReniec.ConsultarRuc(request.Documento);
                        break;

                }
                if (cliente != null && !string.IsNullOrEmpty(cliente.Documento))
                {
                    cliente.FK_TipoDocumento = request.IdTipoDocumento;
                    _auditoria.SetAuditFieldsForInsert(cliente);
                    var respuesta = _mediator.Insert(cliente);
                    if (respuesta != 0)
                    {
                        var rr = new ToReturn<ClienteRequest>(_mapper.Map<ClienteRequest>(_mediator.ObtenerObjeto(respuesta)));
                        return StatusCode(rr.Status, rr);
                    }
                }
                var error = new ToReturnNoEncontrado<ClienteRequest>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ClienteRequest>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }
        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(ClienteRequest obj)
        {
            try
            {
                var validar = _Validator.Validate(obj);
                if (!validar.IsValid)
                {
                    var resul = new ToReturnValidation<ClienteRequest>(validar);
                    return StatusCode(resul.Status, resul);
                }
                var encontrado = _mediator.ObtenerObjetoByDocumentoTipoDocumento(obj.TipoDocumento, obj.Documento);
                if (encontrado != null && !string.IsNullOrEmpty(encontrado.Documento))
                {
                    var resul = new ToReturnValidation<ClienteRequest>("El Numero de Documento ya existe");
                    return StatusCode(resul.Status, resul);
                }
                var noencontrado = _mediatorC.ObtenerObjetoByDocumento(obj.TipoDocumento, obj.Documento);
                if (noencontrado != null && noencontrado.IdClienteNoDeseado != 0)
                {
                    var resul = new ToReturnValidation<ClienteRequest>(noencontrado.Observacion);
                    return StatusCode(resul.Status, resul);
                }
                var cliente = _mapper.Map<ClienteEe>(obj);
                _auditoria.SetAuditFieldsForInsert(cliente);
                if (cliente.Direcciones != null && cliente.Direcciones.Count > 0) cliente.Direcciones.ForEach(direccion => { _auditoria.SetAuditFieldsForInsert(direccion); });
                if (cliente.Contactos != null && cliente.Contactos.Count > 0) cliente.Contactos.ForEach(contacto => { _auditoria.SetAuditFieldsForInsert(contacto); });
                var listado = _mediator.Insert(cliente);
                var result = new ToReturn<int>(listado);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<int>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }
        [HttpPut("Update")]
        public async Task<IActionResult> Update(ClienteRequest obj)
        {
            try
            {
                var validar = _Validator.Validate(obj);

                if (!validar.IsValid)
                {
                    var resul = new ToReturnValidation<bool>(validar);
                    return StatusCode(resul.Status, resul);
                }
                var ee = _mediator.ObtenerObjetoById(obj.Id);
                if (ee == null || ee.IdCliente == 0)
                {
                    var resul = new ToReturnValidation<bool>("Cliente no encontrado");
                    return StatusCode(resul.Status, resul);

                }
                if (ee.Documento != obj.Documento)
                {
                    var encontrado = _mediator.ObtenerObjetoByDocumentoTipoDocumento(obj.TipoDocumento, obj.Documento);
                    if (encontrado != null && !string.IsNullOrEmpty(encontrado.Documento))
                    {
                        var resul = new ToReturnValidation<bool>("El Numero de Documento ya existe");
                        return StatusCode(resul.Status, resul);
                    }

                }
                var noencontrado = _mediatorC.ObtenerObjetoByDocumento(obj.TipoDocumento, obj.Documento);
                if (noencontrado != null && noencontrado.IdClienteNoDeseado != 0)
                {
                    var resul = new ToReturnValidation<bool>(noencontrado.Observacion);
                    return StatusCode(resul.Status, resul);
                }

                var cliente = _mapper.Map<ClienteEe>(obj);
                _auditoria.SetAuditFieldsForUpdate(cliente);
                if (cliente.Direcciones != null && cliente.Direcciones.Count > 0) cliente.Direcciones.ForEach(direccion =>
                {
                    if (direccion.IdClienteDireccion > 0) _auditoria.SetAuditFieldsForUpdate(direccion);
                    else _auditoria.SetAuditFieldsForInsert(direccion);
                });
                if (cliente.Contactos != null && cliente.Contactos.Count > 0) cliente.Contactos.ForEach(contacto =>
                {
                    if (contacto.IdClienteContacto > 0) _auditoria.SetAuditFieldsForUpdate(contacto);
                    else _auditoria.SetAuditFieldsForInsert(contacto);
                });

                var listado = _mediator.Update(cliente);
                var notfound = new ToReturn<bool>(listado);
                return StatusCode(notfound.Status, notfound);
            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<bool>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }
        [HttpDelete("ActivarDesactivar")]
        public async Task<IActionResult> ActivarDesactivar(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjeto(Id);
                if (ee == null || ee.IdCliente == 0)
                {
                    var result = new ToReturnError<bool>("Id no encontrado");
                    return StatusCode(result.Status, result);

                }
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.Delete(ee);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);

            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<ClienteResponse>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }

    }
}
