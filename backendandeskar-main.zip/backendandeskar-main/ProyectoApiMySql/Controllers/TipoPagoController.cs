﻿using AutoMapper;
using Entidades;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class TipoPagoController : ControllerBase
    {
        private readonly ITipoPago _mediator;
        private readonly IMapper _mapper;
        public TipoPagoController(ITipoPago mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }
        [HttpGet("ListarComboTipoPago")]
        public IActionResult ListarComboTipoPago()
        {
            try
            {
                var result = _mediator.ListarByEstado();
                if (result.Any() && result.Count > 0)
                {
                    var rr = new ToReturnList<TipoPagoResponse>(_mapper.Map<List<TipoPagoResponse>>(result));
                    return StatusCode(rr.Status, rr);
                }
                var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<TipoPagoResponse>(ex.Message);
                return StatusCode(error.Status, error);
            }

        }
        [HttpGet("ObtenerTipoPagoById")]
        public async Task<IActionResult> ObtenerTipoPagoById(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjetoById(Id);
                if(listado!=null && listado.IdTipoPago > 0)
                {
                    var rr = new ToReturn<TipoPagoResponse>(_mapper.Map<TipoPagoResponse>(listado));
                    return StatusCode(rr.Status, rr);
                }
                var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoPagoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpGet("ListarTipoPago")]
        public async Task<IActionResult> ListarTipoPago(GlobalEnum.Estado estado)
        {
            try
            {
                var listado = _mediator.ListarByEstado(estado);
                if (listado.Any() && listado.Count > 0)
                {
                    var rr = new ToReturnList<TipoPagoResponse>(_mapper.Map<List< TipoPagoResponse>>(listado));
                    return StatusCode(rr.Status, rr);
                }
                var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoPagoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(TipoPagoResponse obj)
        {
            try
            {
              
                var listado = _mediator.Insert(_mapper.Map<TipoPagoEe>(obj));
                if (listado > 0) {
                    var rr = new ToReturn<int>(listado);
                    return StatusCode(rr.Status, rr);
                }
                var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoPagoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(TipoPagoResponse obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoById(obj.Id);
                if (ee == null) {
                    var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                    return StatusCode(error.Status, error);
                } ;
         
                var listado = _mediator.Update(_mapper.Map<TipoPagoEe>(ee));
                var rr = new ToReturn<bool>(listado);
                return StatusCode(rr.Status, rr);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoPagoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpDelete("ActivarDesactivar")]
        public async Task<IActionResult> ActivarDesactivar(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoById(Id);
                if (ee == null)
                {
                    var error = new ToReturnNoEncontrado<TipoPagoResponse>("Datos no encontrados");
                    return StatusCode(error.Status, error);
                };

                var listado = _mediator.Delete(ee);
                var rr = new ToReturn<bool>(listado);
                return StatusCode(rr.Status, rr);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TipoPagoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
    }
}
