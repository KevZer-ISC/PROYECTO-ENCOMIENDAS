﻿using AutoMapper;
using Entidades;
using FluentValidation;
using ILogica;
using ILogica.Auditoria;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Request;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrayectoriaController : ControllerBase
    {
        private readonly ITrayectoria _mediator;
        private readonly IValidator<TrayectoriaResponse> _validator;
        private readonly IMapper _mapper;
        private readonly IAuditoria _auditoria;
        public TrayectoriaController(ITrayectoria mediator, IAuditoria auditoria, IValidator<TrayectoriaResponse> validator, IMapper mapper)
        {
            _mediator = mediator;
            _validator = validator;
            _mapper = mapper;
            _auditoria = auditoria;
        }
        [HttpPost("Listar")]
        public IActionResult Listar(BusquedaTrayectoriaRequest obj)
        {
            try
            {
                var result = _mediator.Listar(obj);
                if (result.Any() && result.Count > 0)
                {
                    var respuesta = new ToReturnList<TrayectoriaResponse>(result);
                    return StatusCode(respuesta.Status, respuesta);
                }
                var error = new ToReturnNoEncontrado<TrayectoriaResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TrayectoriaResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }


        }
        [HttpGet("ObtenerById")]
        public IActionResult ObtenerById(int Id)
        {
            try
            {
                var result = _mediator.ObtenerById(Id);
                if (result.Id != 0)
                {
                    var respuesta = new ToReturn<TrayectoriaResponse>(result);
                    return StatusCode(respuesta.Status, respuesta);
                }
                var error = new ToReturnNoEncontrado<TrayectoriaResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TrayectoriaResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }


        }

        [HttpPost("Insert")]
        public IActionResult Insert(TrayectoriaResponse obj)
        {
            try
            {
                var valida = _validator.Validate(obj);
                if (!valida.IsValid)
                {
                    var error = new ToReturnValidation<TrayectoriaResponse>(valida);
                    return StatusCode(error.Status, error);
                }




                var trac = _mapper.Map<TrayectoriaEe>(obj);
                trac.TotalOficinas = 0;
                var trad = _mapper.Map<List<TrayectoriaDetalleEe>>(obj.Detalle);
                _auditoria.SetAuditFieldsForInsert(trac);
                trad.OrderBy(c => c.Orden).ToList().ForEach(t =>
                {
                    trac.TotalOficinas += 1;
                    trac.TotalTiempoAcumulado += (int)t.TotalTiempoAcumulado;
                    _auditoria.SetAuditFieldsForInsert(t);
                });


                var response = _mediator.Insert(trac, trad);
                var result = new ToReturn<int>(response);
                return StatusCode(result.Status, result);


            }
            catch (Exception ex)
            {
                var error = new ToReturnError<TrayectoriaResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }


    }
}
