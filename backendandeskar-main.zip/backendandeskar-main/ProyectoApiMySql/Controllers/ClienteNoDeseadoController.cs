﻿using AutoMapper;
using Entidades;
using FluentValidation;
using ILogica;
using ILogica.Auditoria;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Request;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteNoDeseadoController : ControllerBase
    {
        private readonly IClienteNoDeseado _mediator;
        private readonly ITipoDocumento _mediatorT;
        private readonly IMapper _mapper;
        private readonly IValidator<ClienteNoDeseadoRequest> _validator;
        private readonly IAuditoria _auditoria;
        public ClienteNoDeseadoController(IClienteNoDeseado mediator, ITipoDocumento mediatorT, IMapper mapper, IValidator<ClienteNoDeseadoRequest> validator,IAuditoria auditoria)
        {
            _mediator = mediator;
            _mapper = mapper;
            _validator = validator;
            _mediatorT = mediatorT;
            _auditoria = auditoria;
        }
        [HttpGet("ObtenerClienteNoDeseadoById")]
        public async Task<IActionResult> ObtenerClienteNoDeseadoById(int Id)
        {
            try
            {
                if (Id == 0)
                {
                    var error = new ToReturnNoEncontrado<ClienteNoDeseadoResponse>($"Id no existe");
                    return StatusCode(error.Status, error);
                }
                var obj = _mediator.ObtenerObjetoById(Id);
                if (obj == null || obj.IdClienteNoDeseado == 0)
                {
                    var error = new ToReturnNoEncontrado<ClienteNoDeseadoResponse>($"Objeto no exite");
                    return StatusCode(error.Status, error);
                }
                var cliente = _mapper.Map<ClienteNoDeseadoResponse>(obj);
                var tipodocumento = _mediatorT.ObtenerObjeto(cliente.IdtipoDocumento);
                cliente.TipoDocumento = new TipoDocumentoEe { idTipoDocumento  = tipodocumento.idTipoDocumento, Descripcion_TipoDocumento = tipodocumento.Descripcion_TipoDocumento };
                var result = new ToReturn<ClienteNoDeseadoResponse>(cliente);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ClienteNoDeseadoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
        [HttpPost("ObtenerClienteNoDeseadoByTipoNumero")]
        public async Task<IActionResult> ObtenerClienteNoDeseadoByTipoNumero(BusquedaClienteRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Documento) )
                {
                    var error = new ToReturnNoEncontrado<ClienteNoDeseadoResponse>($"Id no existe");
                    return StatusCode(error.Status, error);
                }
                var obj = _mediator.ObtenerObjetoByDocumento(request.IdTipoDocumento,request.Documento);
                if (obj == null || obj.IdClienteNoDeseado == 0)
                {
                    var error = new ToReturnNoEncontrado<ClienteNoDeseadoResponse>($"Objeto no exite");
                    return StatusCode(error.Status, error);
                }
                var cliente = _mapper.Map<ClienteNoDeseadoResponse>(obj);
                var tipodocumento = _mediatorT.ObtenerObjeto(cliente.IdtipoDocumento);
                cliente.TipoDocumento = new TipoDocumentoEe { idTipoDocumento = tipodocumento.idTipoDocumento, Descripcion_TipoDocumento = tipodocumento.Descripcion_TipoDocumento };
                var result = new ToReturn<ClienteNoDeseadoResponse>(cliente);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ClienteNoDeseadoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
        [HttpGet("ListarClienteNoDeseado")]
        public async Task<IActionResult> ListarClienteNoDeseado(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            try
            {

                var arr = _mediator.Lista(estado);
                if (arr == null || !arr.Any())
                {
                    var error = new ToReturnNoEncontrado<ClienteNoDeseadoResponse>($"Lista no exite");
                    return StatusCode(error.Status, error);
                }
                var arrcliente = _mapper.Map<IEnumerable<ClienteNoDeseadoResponse>>(arr);
                var tipodocumento = _mediatorT.ListaObjeto();
                arrcliente.ToList().ForEach(t =>
                {

                    var tipo = tipodocumento.FirstOrDefault(x => x.idTipoDocumento == t.IdtipoDocumento);

                    t.TipoDocumento = new TipoDocumentoEe { idTipoDocumento = tipo.idTipoDocumento, Descripcion_TipoDocumento = tipo.Descripcion_TipoDocumento };
                });
                var result = new ToReturnList<ClienteNoDeseadoResponse>(arrcliente);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ClienteNoDeseadoResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(ClienteNoDeseadoRequest obj)
        {
            try
            {
                              var validacion = _validator.Validate(obj);
                if (!validacion.IsValid)
                {
                    var error = new ToReturnValidation<int>(validacion);
                    return StatusCode(error.Status, error);
                }
                var rr = _mediator.ObtenerObjetoByDocumento(obj.IdtipoDocumento,obj.Documento);
                if (rr != null && rr.IdClienteNoDeseado != 0) {
                    var error = new ToReturnValidation<int>("El numero de documento ya existe");
                    return StatusCode(error.Status, error);

                }
                var noencontrado = _mapper.Map<ClienteNoDeseadoEe>(obj);
                _auditoria.SetAuditFieldsForInsert(noencontrado);    
                var I = _mediator.Insert(noencontrado);
                var result = new ToReturn<int>(I);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<int>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }

        }
        [HttpPut("Update")]
        public async Task<IActionResult> Update(ClienteNoDeseadoRequest obj) {
            try
            {
                var validacion = _validator.Validate(obj);
                if (!validacion.IsValid)
                {
                    var error = new ToReturnValidation<int>(validacion);
                    return StatusCode(error.Status, error);
                }

                var rr = _mediator.ObtenerObjetoById(obj.Id);
                if (rr != null && rr.IdClienteNoDeseado != 0)
                {
                    var error = new ToReturnValidation<int>("El numero de documento ya existe");
                    return StatusCode(error.Status, error);
                }
                                 rr = _mediator.ObtenerObjetoByDocumentoExcluirID(obj.Id,obj.IdtipoDocumento, obj.Documento);
                if (rr != null && rr.IdClienteNoDeseado != 0)
                {
                    var error = new ToReturnValidation<int>("El numero de documento ya existe");
                    return StatusCode(error.Status, error);
                }
                var noencontrado = _mapper.Map<ClienteNoDeseadoEe>(obj);
                var I = _mediator.Update(noencontrado);
                var result = new ToReturn<bool>(I);
                return StatusCode(result.Status, result);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<int>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        
        
        }
        [HttpDelete("ActivarDesactivar")]
        public async Task<IActionResult> ActivarDesactivar(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoById(Id);
                if (ee == null || ee.IdClienteNoDeseado == 0)
                {
                    var result = new ToReturnError<bool>("Id no encontrado");
                    return StatusCode(result.Status, result);

                }
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.ActivarDesactivar(ee);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);

            }
            catch (Exception ex)
            {
                var notfound = new ToReturnError<ClienteResponse>(ex.Message + "\n" + ex.InnerException);
                return StatusCode(notfound.Status, notfound);
            }
        }
    }
}
