﻿using Entidades;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class  ProgramacionController : ControllerBase
    {
        private readonly IProgramacion _mediator;
        public ProgramacionController(IProgramacion mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("ObtenerProgramacion")]
        public async Task<IActionResult> ObtenerProgramacion(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("ListarProgramacion")]
        public async Task<IActionResult> ListarProgramacion()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(ProgramacionEe obj)
        {
            try
            {
                var listado = _mediator.Insert(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(ProgramacionEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.Id_Programacion);
                if (ee == 0) throw new Exception("Id no encontrado");

                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(Id);
                if (ee == 0) throw new Exception("Id no encontrado");
                var listado = _mediator.Delete(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
