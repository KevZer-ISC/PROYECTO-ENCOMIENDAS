﻿using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class MenuController : ControllerBase
    {
        private readonly IMenu _mediator;
        public MenuController(IMenu mediator)
        {
            _mediator = mediator;
        }
        [HttpPost("ListarMenuOrdenado")]
        public async Task<IActionResult> ListarMenuOrdenado()
        {
            try
            {
                var listado = _mediator.ListaMenuOrdenados();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
