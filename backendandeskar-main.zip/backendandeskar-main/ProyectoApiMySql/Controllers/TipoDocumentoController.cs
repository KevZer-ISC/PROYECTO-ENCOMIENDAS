
using Entidades;
using ILogica;
using Microsoft.AspNetCore.Mvc;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class TipoDocumentoController : ControllerBase
    {
        private readonly ITipoDocumento _mediator;
        public TipoDocumentoController(ITipoDocumento mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("ObtenerTipoDocumentos")]
        public async Task<IActionResult> ObtenerTipoDocumentos(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<TipoDocumentoEe>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("ListarTipoDocumentos")]
        public async Task<IActionResult> ListarTipoDocumentos()
        {
            try
            {
                 var result = _mediator.ListaObjeto();
                if (result.Any() && result.Count > 0)
                {
                    var rr = new ToReturnList<TipoDocumentoEe>(result);
                    return StatusCode(rr.Status, rr);

                }
                var error = new ToReturnNoEncontrado<TipoDocumentoEe>("Datos no encontrados");
                return StatusCode(error.Status, error);

            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<TipoEntregaResponse>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(TipoDocumentoEe obj)
        {
            try
            {
                var listado = _mediator.Insert(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<int>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(TipoDocumentoEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.idTipoDocumento);
                if ( ee == 0) throw new Exception("Id no encontrado");
              
                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<bool>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(Id);
                if (ee == 0) throw new Exception("Id no encontrado");
                var listado = _mediator.Delete(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<bool>(ex.Message);
                return StatusCode(error.Status, error);
            }
        }

    }
}