﻿using AutoMapper;
using ILogica;
using Microsoft.AspNetCore.Mvc;
using Modelos.Response;
using Utilitarios;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class TipoServicioController : ControllerBase
    {
        private readonly ITipoServicio _mediator;
        private readonly IMapper _mapper;
        public TipoServicioController(ITipoServicio mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }
        [HttpGet("ListarComboTipoServicio")]
        public IActionResult ListarComboTipoServicio()
        {
            try
            {
                var result = _mediator.Listar();
                if (result.Any() && result.Count > 0) {
                    var rr = new ToReturnList< TipoServicioResponse>(_mapper.Map<IEnumerable<TipoServicioResponse>>(result));
                    return StatusCode(rr.Status, rr);

                } 
                var error = new ToReturnNoEncontrado<TipoServicioResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<TipoServicioResponse>(ex.Message);
                return StatusCode(error.Status, error);
            }

        }
    }
}
