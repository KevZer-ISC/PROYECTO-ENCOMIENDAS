﻿using Entidades;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class NotaDeCreditoController : ControllerBase
    {
        private readonly INotaCredito _mediator;
        public NotaDeCreditoController(INotaCredito mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("ObtenerNotaCredito")]
        public async Task<IActionResult> ObtenerNotaCredito(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("ListarNotaCredito")]
        public async Task<IActionResult> ListarNotaCredito()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(NotaCreditoEe obj)
        {
            try
            {
                var listado = _mediator.Insert(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(NotaCreditoEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.idNotaCredito);
                if (ee == 0) throw new Exception("Id no encontrado");

                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(Id);
                if (ee == 0) throw new Exception("Id no encontrado");
                var listado = _mediator.Delete(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
