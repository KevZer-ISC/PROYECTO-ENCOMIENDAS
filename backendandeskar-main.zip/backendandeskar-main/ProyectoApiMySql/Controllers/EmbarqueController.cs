﻿using Entidades;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class EmbarqueController : ControllerBase
    {
        private readonly IEmbarque _mediator;
        public EmbarqueController(IEmbarque mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("ObtenerEmbarque")]
        public async Task<IActionResult> ObtenerEmbarque(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("ListarEmbarque")]
        public async Task<IActionResult> ListarEmbarque()
        {
            try
            {
                var listado = _mediator.ListaObjeto();
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(EmbarqueEe obj)
        {
            try
            {
                var listado = _mediator.Insert(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(EmbarqueEe obj)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(obj.id_Embarque);
                if (ee == 0) throw new Exception("Id no encontrado");

                var listado = _mediator.Update(obj);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjetoId(Id);
                if (ee == 0) throw new Exception("Id no encontrado");
                var listado = _mediator.Delete(Id);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
