﻿using AutoMapper;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Response;
using Utilitarios;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class TipoEntregaController : ControllerBase
    {
        private readonly ITipoEntrega _mediator;
        private readonly IMapper _mapper;
        public TipoEntregaController(ITipoEntrega mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }
        [HttpGet("ListarComboTipoEntrega")]
        public IActionResult ListarComboTipoEntrega()
        {
            try
            {
                var result = _mediator.Listar();
                if (result.Any() && result.Count > 0) {
                    var rr = new ToReturnList<TipoEntregaResponse>(_mapper.Map<List<TipoEntregaResponse>>(result));
                    return StatusCode(rr.Status, rr);

                } 
                var error = new ToReturnNoEncontrado<TipoEntregaResponse>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnErrorList<TipoEntregaResponse>(ex.Message);
                return StatusCode(error.Status, error);
            }

        }
    }
}
