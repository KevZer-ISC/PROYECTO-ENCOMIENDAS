﻿using Entidades;
using Utilitarios.Resources;
using ILogica;
using Logica.Seguridad.SeguridadJwtAuthorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.Versioning;
using Utilitarios;
using Modelos.Response;
using ILogica.Auditoria;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]

    public class AgenciaController : ControllerBase
    {
        private readonly IAgencia _mediator;
        private readonly IAuditoria _auditoria;
        public AgenciaController(IAgencia mediator,IAuditoria auditoria)
        {
            _mediator = mediator;
            _auditoria = auditoria;
        }

        [HttpGet("ObtenerAgencia")]
        public async Task<IActionResult> ObtenerAgencia(int Id)
        {
            try
            {
                var listado = _mediator.ObtenerObjeto(Id);
                if (listado == null || listado.IdAgencia == 0) {
                    var error = new ToReturnNoEncontrado<AgenciaEe>("Datos no encontrados");
                    return StatusCode(error.Status, error);
                }
                var respuesta = new ToReturn<AgenciaEe>(listado);
                return StatusCode(respuesta.Status, respuesta);
 
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        //[OperationAuthorize(GlobalConstant.RlVisualizar, GlobalConstant.MnTrabajador)]
        [HttpGet("ListarAgencia")]
        public async Task<IActionResult> ListarAgencia()
        {
            try
            {
                var result = _mediator.ListaObjeto();
                if (result.Any() && result.Count > 0) {
                    var respuesta = new ToReturnList<AgenciaEe>(result);
                    return StatusCode(respuesta.Status, respuesta);
                }
        
                var error = new ToReturnNoEncontrado<AgenciaEe>("Datos no encontrados");
                return StatusCode(error.Status, error);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return  StatusCode(error.Status,error);
            }
        }

        [HttpPost("Insert")]
        public async Task<IActionResult> Insert(AgenciaEe obj)
        {
            try
            {
                _auditoria.SetAuditFieldsForInsert(obj);
                var listado = _mediator.Insert(obj);
                var respuesta = new ToReturn<int>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(AgenciaEe obj)
        {
            try
            {

                var ee = _mediator.ObtenerObjetoId(obj.IdAgencia);
                if (ee == 0) throw new Exception("Id no encontrado");
                _auditoria.SetAuditFieldsForUpdate(obj);
                var listado = _mediator.Update(obj);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpDelete("ActivoInactivo")]
        public async Task<IActionResult> ActivoInactivo(int Id)
        {
            try
            {
                var ee = _mediator.ObtenerObjeto(Id);
                if (ee == null ||ee.IdAgencia==0) throw new Exception("Id no encontrado");
                _auditoria.SetAuditFieldsForUpdate(ee);
                var listado = _mediator.Delete(ee);
                var respuesta = new ToReturn<bool>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }

        [HttpGet("ListarAgenciaByDocumentoTrabajador")]

        public async Task<IActionResult> ListarAgenciaByDocumentoTrabajador(string Documento)
        {
            try
            {
                var listado = _mediator.ListarAgenciaByDocumentoTrabajador(Documento);
                var respuesta = new ToReturnList<AgenciaEe>(listado);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<AgenciaEe>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }
    }
}
