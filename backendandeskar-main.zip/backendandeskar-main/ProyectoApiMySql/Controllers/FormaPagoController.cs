﻿using Entidades;
using ILogica;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Request;
using Modelos.Response;
using Utilitarios;
using static Utilitarios.GlobalEnum;

namespace ProyectoApiMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FormaPagoController : ControllerBase
    {
        private readonly IFormaPago _mediator;
        public FormaPagoController(IFormaPago mediator)
        {
            _mediator = mediator;
        }
        [HttpPost("ObtenerFormaPago")]
        public async Task<IActionResult> ObtenerFormaPago(BuscarFormaPagoRequest obj)
        {
            try
            {
                var lista = _mediator.BuscarFormaPagoByIdClienteByPagador(obj);
                if (lista == null || lista.Count() == 0)
                {
                    var error = new ToReturnNoEncontrado<ComunResponse>("Datos no encontrados");
                    return StatusCode(error.Status, error);
                }
                var respuesta = new ToReturnList<ComunResponse>(lista);
                return StatusCode(respuesta.Status, respuesta);
            }
            catch (Exception ex)
            {
                var error = new ToReturnError<ComunResponse>($"{ex.Message} {ex.InnerException}");
                return StatusCode(error.Status, error);
            }
        }



    }
}
