﻿namespace TipoDocumentoEe
{
    public class Class1
    {

    }
}