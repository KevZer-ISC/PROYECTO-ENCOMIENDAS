﻿using ILogica.Seguridad;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelos.Request;
using Modelos.Response;
using Swashbuckle.AspNetCore.Annotations;

namespace ProyectoSeguridad.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(object))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public class SeguridadController : ControllerBase
    {
        private readonly ISeguridadRepository _mediator;
        public SeguridadController(ISeguridadRepository mediator)
        {
            _mediator = mediator;

        }
        [SwaggerOperation(Summary = "Autenticacion de usuarios")]
        [HttpPost("Autenticacion")]
        public async Task<IActionResult> Autenticacion(LoginRequest request)
        {
            try
            {
                var result = _mediator.LoginByDocumentoAgenciaClave(request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [ProducesResponseType(typeof(LoginResponse), 200)]
        [SwaggerOperation(Summary = "Autenticacion de usuarios")]
        [HttpPost("RefreshToken")]
        public async Task<IActionResult> RefreshToken(TokenRefreshRequest request)
        {

            try
            {
                var result = _mediator.RefreshToken(request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("ListarAgenciaByDocumentoTrabajador")]

        public async Task<IActionResult> ListarAgenciaByDocumentoTrabajador(string Documento)
        {
            try
            {
                var listado = _mediator.ListarAgenciaByDocumentoTrabajador(Documento);
                return Ok(listado);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
