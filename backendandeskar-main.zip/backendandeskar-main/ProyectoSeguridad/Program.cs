using Utilitarios.JWT;
using Logica;
using Microsoft.OpenApi.Models;
using ILogica.Seguridad;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
JwtConfig.JwtConfigHelper(builder.Configuration);

builder.Services.AddControllers(opciones => opciones.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true).AddJsonOptions(opciones =>
{
    opciones.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;

});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddApplication(builder.Configuration.GetConnectionString("Conexion").ToString());
builder.Services.AddSwaggerGen(c =>
{

    c.SwaggerDoc("v1", new OpenApiInfo { Title = "ProyectoSeguridad", Version = "v1" });

});
// global cors policy
//builder.Services.AddCors(options =>
//{
//    options.AddPolicy("AnyOrigin", builder => { builder.AllowAnyOrigin()
//                                                        .AllowAnyMethod()
//                                                        .AllowAnyHeader()
//                                                        .SetIsOriginAllowed(origin => true) 
//                                                        .AllowCredentials(); 
//                                                    });
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}
app.UseCors(options =>
{
    options
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .AllowAnyMethod();
});
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
