﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface ITipoServicio
    {
        List<TipoServicioEe> Listar(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
    }
}
