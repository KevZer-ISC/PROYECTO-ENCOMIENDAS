﻿

using Entidades;

namespace ILogica
{
    public interface ITipoDocumento
    {
        TipoDocumentoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<TipoDocumentoEe> ListaObjeto();
        int Insert(TipoDocumentoEe obj);
        bool Update(TipoDocumentoEe obj);
        bool Delete(int Id);
    }
}