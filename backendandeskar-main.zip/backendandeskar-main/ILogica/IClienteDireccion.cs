﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IClienteDireccion
    {
        ClienteDireccionEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<ClienteDireccionEe> ListaObjeto(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
        List<ClienteDireccionEe> ListaObjetoByIds(List<int> Ids);
        int Insert(ClienteDireccionEe obj);
        bool Update(List<ClienteDireccionEe> obj);
        bool Delete(ClienteDireccionEe obj);
        List<ClienteDireccionEe> ListarByIdCliente(int IdCliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);

    }
}
