﻿using Entidades;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IMenu
    {
        public MenuEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<MenuEe> ListaObjeto();
        List<MenuEe> ListaObjetoByIds(List<int> Ids);
        int Insert(MenuEe obj);
        bool Update(MenuEe obj);
        bool Delete(int Id);
        List<MenuResponse> ListaMenuOrdenados();
        List<MenuResponse> Ordenarmenus(List<MenuEe> arr, int Padre = 0);
    }
}
