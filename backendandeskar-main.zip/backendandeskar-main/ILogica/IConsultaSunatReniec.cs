﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IConsultaSunatReniec
    {
        Task<ClienteEe> ConsultarRuc(string Ruc);
        Task<ClienteEe> ConsultarDni(string Dni);
    }
}
