﻿using Entidades;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface ITrayectoria
    {
        List<TrayectoriaResponse> Listar(BusquedaTrayectoriaRequest obj);
        TrayectoriaResponse ObtenerById(int Id);
        int Insert(TrayectoriaEe obj, List<TrayectoriaDetalleEe> detalle);
    }
}
