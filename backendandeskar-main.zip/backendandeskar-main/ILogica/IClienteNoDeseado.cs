﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IClienteNoDeseado
    {
        ClienteNoDeseadoEe ObtenerObjetoById(int Id);
        ClienteNoDeseadoEe ObtenerObjetoByDocumento(int TipoDocumento, string numero);
        ClienteNoDeseadoEe ObtenerObjetoByDocumentoExcluirID(int Id, int TipoDocumento, string numero);
        IEnumerable<ClienteNoDeseadoEe> Lista(GlobalEnum.Estado estado = GlobalEnum.Estado.Todos);
        int Insert(ClienteNoDeseadoEe obj);
        bool Update(ClienteNoDeseadoEe obj);
        bool ActivarDesactivar(ClienteNoDeseadoEe obj);
    }
}
