﻿using Entidades;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IFormaPago
    {
        IEnumerable<ComunResponse> BuscarFormaPagoByIdClienteByPagador(BuscarFormaPagoRequest obj);
    }
}
