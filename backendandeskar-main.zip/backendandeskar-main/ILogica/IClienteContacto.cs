﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IClienteContacto
    {
        ClienteContactoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<ClienteContactoEe> ListaObjeto(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
        List<ClienteContactoEe> ListaObjetoByIds(List<int> Ids);
        int Insert(ClienteContactoEe obj);
        bool Update(List<ClienteContactoEe> obj);
        bool Delete(ClienteContactoEe obj);
        List<ClienteContactoEe> ListarByIdCliente(int IdCliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
    }
}
