﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica.Auditoria
{
    public   interface IAuditoria
    {
        void SetAuditFieldsForInsert(AuditoriaEe entity);
        void SetAuditFieldsForUpdate(AuditoriaEe entity);
    }
}
