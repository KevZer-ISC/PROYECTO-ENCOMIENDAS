using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
	public interface IOrdenServicioConsignado
	{
		OrdenServicioConsignadoEe ObtenerObjeto(int Id);
		int ObtenerObjetoId(int Id);
		List<OrdenServicioConsignadoEe> ListaObjeto();
		int Insert(OrdenServicioConsignadoEe obj);
		bool Update(OrdenServicioConsignadoEe obj);
		bool Delete(int Id);
	}
}
