using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IUsuario
    {
        UsuarioEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<UsuarioEe> ListaObjeto();
        int Insert(UsuarioEe obj);
        bool Update(UsuarioEe obj);
        bool Delete(int Id);
    }
}
