﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IDetallePago
    {
        DetallePagoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<DetallePagoEe> ListaObjeto();
        int Insert(DetallePagoEe obj);
        bool Update(DetallePagoEe obj);
        bool Delete(int Id);
    }
}
