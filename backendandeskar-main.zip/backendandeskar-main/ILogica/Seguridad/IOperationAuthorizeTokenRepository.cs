﻿using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ILogica.Seguridad
{
    public interface IOperationAuthorizeTokenRepository
    {
        ClaimsPrincipal ValidateToken(string jwtToken);
        bool attachAccountToContext(string token);
        LoginResponse attachTenantToContext(string token);
    }
}
