﻿using Entidades;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica.Seguridad
{
    public interface ISeguridadRepository
    {

        LoginResponse RefreshToken(TokenRefreshRequest obj);
        LoginResponse LoginByDocumentoAgenciaClave(LoginRequest login);
        List<AgenciaEe> ListarAgenciaByDocumentoTrabajador(string Documento);
    }
}
