﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica.Seguridad
{
    public interface IGlobalLogin
    {
         int IdUsuario { get; set; }
         int IdPerfil { get; set; }
         int IdAgencia { get; set; }
         int IdTrabajador { get; set; }
    }
}
