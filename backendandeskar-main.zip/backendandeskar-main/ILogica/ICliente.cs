﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface ICliente
    {
        ClienteEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        ClienteEe ObtenerObjetoByDocumentoTipoDocumento(int tipo, string documento, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
        List<ClienteEe> ListaObjeto();
        int Insert(ClienteEe obj);
        bool Update(ClienteEe obj);
        bool Delete(ClienteEe obj);
        ClienteEe ObtenerObjetoById(int Id);
    }
}
