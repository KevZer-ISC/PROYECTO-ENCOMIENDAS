using Entidades;
using Modelos.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface ITrabajador
    {
        TrabajadorEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<TrabajadorEe> ListaObjeto();
        int Insert(TrabajadorRequest obj);
        bool Update(TrabajadorRequest obj);
        bool Delete(int Id);
    }
}
