using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface ITipoVehiculo
    {
        TipoVehiculoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<TipoVehiculoEe> ListaObjeto();
        int Insert(TipoVehiculoEe obj);
        bool Update(TipoVehiculoEe obj);
        bool Delete(int Id);
    }
}
