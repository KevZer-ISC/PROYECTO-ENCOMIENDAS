﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IAgencia
    {
        AgenciaEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<AgenciaEe> ListaObjeto();
        int Insert(AgenciaEe obj);
        bool Update(AgenciaEe obj);
        bool Delete(AgenciaEe obj);
        List<AgenciaEe> ListarAgenciaByDocumentoTrabajador(string Documento);
    }
}
