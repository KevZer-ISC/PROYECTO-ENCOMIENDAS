﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Utilitarios.GlobalEnum;
using Utilitarios;

namespace ILogica
{
    public interface IAgenciaTipoComprobante
    {
        AgenciaTipoComprobanteEe ObtenerByUsuario(GlobalEnum.TipoComprobante tipoComprobante = TipoComprobante.Ninguno);
    }
}
