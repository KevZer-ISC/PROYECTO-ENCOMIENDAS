using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
	public interface IOrdenServicioItem
	{
		OrdenServicioItemEe ObtenerObjeto(int Id);
		int ObtenerObjetoId(int Id);
		List<OrdenServicioItemEe> ListaObjeto();
		int Insert(OrdenServicioItemEe obj);
		bool Update(OrdenServicioItemEe obj);
		bool Delete(int Id);
	}
}
