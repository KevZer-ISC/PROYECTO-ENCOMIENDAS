using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IProgramacion
    {
        ProgramacionEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<ProgramacionEe> ListaObjeto();
        int Insert(ProgramacionEe obj);
        bool Update(ProgramacionEe obj);
        bool Delete(int Id);
    }
}
