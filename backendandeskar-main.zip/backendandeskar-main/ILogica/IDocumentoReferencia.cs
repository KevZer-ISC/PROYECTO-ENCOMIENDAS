﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IDocumentoReferencia
    {
        DocumentoReferenciaEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<DocumentoReferenciaEe> ListaObjeto();
        int Insert(DocumentoReferenciaEe obj);
        bool Update(DocumentoReferenciaEe obj);
        bool Delete(int Id);
    }
}
