using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IVehiculo
    {
        VehiculoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<VehiculoEe> ListaObjeto();
        int Insert(VehiculoEe obj);
        bool Update(VehiculoEe obj);
        bool Delete(int Id);
    }
}
