﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IComprobante
    {
        ComprobanteEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<ComprobanteEe> ListaObjeto();
        int Insert(ComprobanteEe obj);
        bool Update(ComprobanteEe obj);
        bool Delete(int Id);
    }
}
