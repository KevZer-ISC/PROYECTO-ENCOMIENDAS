using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
	public interface IOrdenServicio
	{
		OrdenServicioEe ObtenerObjeto(int Id);
		int ObtenerObjetoId(int Id);
		List<OrdenServicioEe> ListaObjeto();
		int Insert(OrdenServicioEe obj);
		bool Update(OrdenServicioEe obj);
		bool Delete(int Id);
	}
}
