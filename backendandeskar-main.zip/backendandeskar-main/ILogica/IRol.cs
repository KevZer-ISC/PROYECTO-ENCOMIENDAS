using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IRol
    {
        RolEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<RolEe> ListaObjeto();
        int Insert(RolEe obj);
        bool Update(RolEe obj);
        bool Delete(int Id);
    }
}
