﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IEmbarque
    {
        EmbarqueEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<EmbarqueEe> ListaObjeto();
        int Insert(EmbarqueEe obj);
        bool Update(EmbarqueEe obj);
        bool Delete(int Id);
    }
}
