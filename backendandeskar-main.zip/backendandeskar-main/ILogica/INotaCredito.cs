using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface INotaCredito
    {
        NotaCreditoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<NotaCreditoEe> ListaObjeto();
        int Insert(NotaCreditoEe obj);
        bool Update(NotaCreditoEe obj);
        bool Delete(int Id);
    }
}
