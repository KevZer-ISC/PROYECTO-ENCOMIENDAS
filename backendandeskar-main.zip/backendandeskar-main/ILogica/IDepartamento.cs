﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IDepartamento
    {
        DepartamentoEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<DepartamentoEe> ListaObjeto();
        int Insert(DepartamentoEe obj);
        bool Update(DepartamentoEe obj);
        bool Delete(int Id);
    }
}
