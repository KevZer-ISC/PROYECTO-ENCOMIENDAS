﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IChofer
    {
        ChoferEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<ChoferEe> ListaObjeto();
        int Insert(ChoferEe obj);
        bool Update(ChoferEe obj);
        bool Delete(ChoferEe obj);
    }
}
