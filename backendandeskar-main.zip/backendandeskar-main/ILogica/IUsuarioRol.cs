using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILogica
{
    public interface IUsuarioRol
    {
        UsuarioRolEe ObtenerObjetobyIdUsuario(int Id);
        int ObtenerObjetoId(int Id);
        List<UsuarioRolEe> ListaObjeto();
        int Insert(UsuarioRolEe obj);
        bool Update(UsuarioRolEe obj);
        bool Delete(int Id);
    }
}
