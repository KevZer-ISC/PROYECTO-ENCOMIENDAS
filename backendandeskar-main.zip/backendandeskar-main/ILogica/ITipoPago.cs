﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface ITipoPago
    {
        List<TipoPagoEe> ListarByEstado(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo);
        TipoPagoEe ObtenerObjetoById(int Id);
        bool ExisteObjetoById(int Id);
        int Insert(TipoPagoEe obj);
        bool Update(TipoPagoEe obj);
        bool Delete(TipoPagoEe obj);
    }
}
