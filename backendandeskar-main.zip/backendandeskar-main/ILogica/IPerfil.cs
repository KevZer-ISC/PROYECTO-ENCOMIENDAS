﻿using Entidades;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace ILogica
{
    public interface IPerfil
    {
        PerfilEe ObtenerObjeto(int Id);
        int ObtenerObjetoId(int Id);
        List<PerfilEe> ListaObjeto();
        List<PerfilEe> ListaObjetoByIdsPerfil(List<int> Ids);
        int Insert(PerfilRequest obj);
        bool Update(PerfilRequest obj);
        bool Delete(int Id);
        PerfilMenuRolResponse ListarPerfilWithMenuByIdperfil(int id);
    }
}
