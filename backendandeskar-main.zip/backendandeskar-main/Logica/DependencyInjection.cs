﻿using FluentValidation;
using ILogica;
using ILogica.Auditoria;
using ILogica.Seguridad;
using Logica.Auditoria;
using Logica.Seguridad;
using Logica.Seguridad.SeguridadJwtAuthorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using System.ComponentModel;
using System.Reflection;
using Utilitarios;

namespace Logica
{
    public static class DependencyInjection
    {
        public static void AddApplication(this IServiceCollection services, string connectionStringDB)
        {
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            services.AddRepositories();
            Base.ConnectionString = connectionStringDB;
        }

        public static void AddRepositories(this IServiceCollection services)
        {
            services.AddScoped<ITipoDocumento, LogTipoDocumento>();
            services.AddScoped<IAgencia, LogAgencia>();
            services.AddScoped<IChofer, LogChofer>();
            services.AddScoped<ICliente, LogCliente>();
            services.AddScoped<IComprobante, LogComprobante>();
            services.AddScoped<IDetallePago, LogDetallePago>();
            services.AddScoped<IDocumentoReferencia, LogDocumentoReferencia>();
            services.AddScoped<IEmbarque, LogEmbarque>();

            services.AddScoped<IVehiculo, LogVehiculo>();
            services.AddScoped<IUsuarioRol,LogUsuarioRol>();
            services.AddScoped<IUsuario,LogUsuario>();
            services.AddScoped<ITrabajador,LogTrabajador>();
            services.AddScoped<ITipoVehiculo,LogTipoVehiculo>();
            services.AddScoped<IRol,LogRol>();  
            services.AddScoped<IProgramacion,LogProgramacion>();
            services.AddScoped<IOrdenServicioItem,LogOrdenServicioItem>();  
            services.AddScoped<IOrdenServicioConsignado,LogOrdenServicioConsignado>();
            services.AddScoped<IOrdenServicio,LogOrdenServicio>();
            services.AddScoped<INotaCredito,LogNotaCredito>();
            services.AddScoped<IPerfil,LogPerfil>();
            services.AddScoped<IMenu,LogMenu>();
            services.AddScoped<IDepartamento,LogDepartamento>();
            services.AddScoped<ITipoServicio,LogTipoServico>();
            services.AddScoped<ITipoEntrega,LogTipoEntrega>();
            services.AddScoped<ITipoPago,LogTipoPago>();
            services.AddScoped<IAgenciaTipoComprobante,LogAgenciaTipoComprobante>();
            services.AddScoped<IAuditoria,LogAuditoria>();
            services.AddScoped<IClienteDireccion,logClienteDireccion>();
            services.AddScoped<IClienteContacto,LogClienteContacto>();
            services.AddScoped<IClienteNoDeseado,LogClienteNoDeseado>();
            services.AddScoped<IConsultaSunatReniec,LogConsultaSunatReniec>();
            services.AddScoped<IFormaPago,LogFormaPago>();
            services.AddScoped<ITrayectoria,LogTrayectoria>();

            #region Seguridad

            services.AddScoped<ISeguridadRepository, SeguridadRepository>();
            services.AddSingleton<IOperationAuthorizeTokenRepository, OperationAuthorizeTokenRepository>();
            services.AddTransient<IAuthorizationPolicyProvider, OperationAuthorizeProvider>();
            services.AddSingleton<IAuthorizationHandler, OperationAuthorizerHandler>();
            services.AddScoped<IGlobalLogin,Logica.Seguridad.GlobalLogin>();
            #endregion




        }
    }
}
