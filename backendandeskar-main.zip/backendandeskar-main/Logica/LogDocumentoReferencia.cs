﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogDocumentoReferencia: IDocumentoReferencia
    {
        public DocumentoReferenciaEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<DocumentoReferenciaEe>($"select * from documento_referencia where idDocumento_Referencia={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select idDocumento_Referencia from documento_referencia where idDocumento_Referencia={Id}");

            return nt;

        }
        public List<DocumentoReferenciaEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<DocumentoReferenciaEe>($"select * from documento_referencia ");

            return nt;

        }
        public int Insert(DocumentoReferenciaEe obj)
        {
            string cadena = $@"IINSERT INTO documento_referencia
                              ( Descripcion_DocumentoReferencia)
                              VALUES( '{obj.Descripcion_DocumentoReferencia}');
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(DocumentoReferenciaEe obj)
        {
            string cadena = $@"UPDATE documento_referencia
                               SET Descripcion_DocumentoReferencia='{obj.Descripcion_DocumentoReferencia}'
                               WHERE idDocumento_Referencia={obj.idDocumento_Referencia};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from documento_referencia 
                                WHERE idDocumento_Referencia={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
