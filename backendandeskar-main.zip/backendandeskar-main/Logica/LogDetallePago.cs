﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogDetallePago: IDetallePago
    {
        public DetallePagoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<DetallePagoEe>($"select * from detallepago where id_DetallePago={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdCliente from detallepago where id_DetallePago={Id}");

            return nt;

        }
        public List<DetallePagoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<DetallePagoEe>($"select * from detallepago ");

            return nt;

        }
        public int Insert(DetallePagoEe obj)
        {
            string cadena = $@"INSERT INTO detallepago
                               ( PK_OrdeServicio, PK_Comprobante, FechaPago, TipoPago, TipoTarjeta, 
                               MontoPagado, Lote, Digito, Referencia, Monto)
                               VALUES( {obj.PK_OrdeServicio}, {obj.PK_Comprobante}, '{obj.FechaPago}', {obj.TipoPago}, {obj.TipoTarjeta}, 
                               {obj.MontoPagado}, '{obj.Lote}', '{obj.Digito}', '{obj.Referencia}', {obj.Monto});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(DetallePagoEe obj)
        {
            string cadena = $@"UPDATE detallepago
                             SET PK_OrdeServicio= {obj.PK_OrdeServicio}, PK_Comprobante= {obj.PK_Comprobante}, FechaPago=' {obj.FechaPago}',TipoPago= {obj.TipoPago}, 
                                 TipoTarjeta= {obj.TipoTarjeta}, MontoPagado= {obj.MontoPagado}, Lote='{obj.Lote}', Digito='{obj.Digito}', Referencia=' {obj.Referencia}', 
                                 Monto= {obj.Monto}
                             where  id_DetallePago= {obj.id_DetallePago}     ;                        
                             select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from detallepago 
                                WHERE id_DetallePago={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
