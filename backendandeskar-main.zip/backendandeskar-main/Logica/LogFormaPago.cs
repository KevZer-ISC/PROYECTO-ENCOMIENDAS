﻿using Entidades;
using ILogica;
using Microsoft.Identity.Client;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogFormaPago: IFormaPago
    {
        public IEnumerable<FormaPagoEe> ListaObjeto(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {

            string cadena = $@"select * from Formapago {(estado != GlobalEnum.Estado.Todos ? $" where activo={(int)estado}" : "")}";
            return DapperSQL.Lista<FormaPagoEe>(cadena);
        }
        public IEnumerable<ComunResponse> BuscarFormaPagoByIdClienteByPagador(BuscarFormaPagoRequest obj)
        {
            IEnumerable<FormaPagoEe> Lista = ListaObjeto();
            List<ComunResponse> ListaRetorno=new List<ComunResponse>();
            ClienteEe Cliente = new LogCliente().ObtenerObjetoById(obj.IdCliente);
            if (Cliente == null || Cliente.IdCliente == 0) return new List<ComunResponse>();
            TipoDocumentoEe tipo = new LogTipoDocumento().ObtenerObjeto((int)Cliente.FK_TipoDocumento);
            if(tipo==null|| tipo.idTipoDocumento==0||string.IsNullOrWhiteSpace( tipo.Tipo))return new List<ComunResponse>();
            string input = obj.Pagador.ToString().ToLower() ?? throw new Exception();
            input= input.First().ToString().ToUpper() + input.Substring(1);

            string nombreColumna = $"{input}{(tipo.Tipo=="J"?"Juridico":"Natural")}";
            foreach (var item in Lista)
            {
                PropertyInfo propiedad = item.GetType().GetProperty(nombreColumna);
                if (propiedad != null)
                {
                    var valor = propiedad.GetValue(item);
                    if (valor != null)
                    {
                        if ((bool)valor)
                        {
                            ListaRetorno.Add(new ComunResponse {Id=item.IdFormaPago,Descripcion=item.DescripcionFormaPago });
                        }
                    }
                }
            }
            return ListaRetorno;
        }

    }
}
