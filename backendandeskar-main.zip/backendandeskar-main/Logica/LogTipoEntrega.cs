﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTipoEntrega:ITipoEntrega
    {
        public List<TipoEntregaEe> Listar(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            return DapperSQL.Lista<TipoEntregaEe>($@"select * from TipoEntrega {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");

        }
    }
}
