﻿using Entidades;
using ILogica;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTipoPago : ITipoPago
    {
        public List<TipoPagoEe> ListarByEstado(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            return DapperSQL.Lista<TipoPagoEe>($@"select * from TipoPago {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");

        }
        public TipoPagoEe ObtenerObjetoById(int Id)
        {
            var nt = DapperSQL.Objeto<TipoPagoEe>($"select * from TipoPago where IdTipoPago={Id}");

            return nt;

        }
        public bool ExisteObjetoById(int Id)
        {
            var nt = DapperSQL.Objeto<TipoPagoEe>($"select * from TipoPago where IdTipoPago={Id}");

            return nt != null && nt.IdTipoPago > 0;

        }
        public int Insert(TipoPagoEe obj)
        {
            string cadena = $@"INSERT INTO TipoPago
                               ( DescripcionTipoPago{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@DescripcionTipoPago{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena, obj);
        }
        public bool Update(TipoPagoEe obj)
        {
            string cadena = $@"UPDATE TipoPago
                               SET DescripcionTipoPago=@DescripcionTipoPago
                                   {GlobalConstant.AuditoriaUpdate}
                               WHERE IdTipoPago=@IdTipoPago;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }
        public bool Delete(TipoPagoEe obj)
        {
            string cadena = $@"UPDATE TipoPago
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE IdTipoPago=@IdTipoPago;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }
    }
}
