﻿using Entidades;
using ILogica;
using Modelos.Response;
using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogMenu : IMenu
    {
        public MenuEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<MenuEe>($"select * from Menu where Idmenu={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdAgencia from Menu where IdMenu={Id}");

            return nt;

        }
        public List<MenuEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<MenuEe>($"select * from Menu ");

            return nt;

        }
        public List<MenuEe> ListaObjetoByIds(List<int> Ids)
        {
            var nt = DapperSQL.Lista<MenuEe>($"select * from Menu where Idmenu in ({string.Join(",", Ids)})");

            return nt;

        }
        public int Insert(MenuEe obj)
        {
            string cadena = $@"INSERT INTO Menu
                               ( Nombre,Ruta,IdPadre,Icono)
                               VALUES('{obj.Nombre}', '{obj.Ruta}', {obj.IdPadre}, '{obj.Icono}');;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(MenuEe obj)
        {
            string cadena = $@"UPDATE Menu
                               SET Nombre='{obj.Nombre}', Ruta='{obj.Ruta}', Icono='{obj.Icono}', IdPadre= {obj.IdPadre}
                               WHERE Idmenu={obj.IdMenu};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Menu 
                                WHERE Idmenu={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public List<MenuResponse> ListaMenuOrdenados()
        {
            return Ordenarmenus(ListaObjeto());
        }
        public List<MenuResponse> Ordenarmenus(List<MenuEe> arr, int Padre = 0)
        {
            List<MenuResponse> arrnew = new List<MenuResponse>();
            arr.Where(x => x.IdPadre == Padre).ToList().ForEach(r =>
            {
                MenuResponse nuevo = new MenuResponse();

                nuevo.IdMenu = r.IdMenu;
                nuevo.IdPadre = r.IdPadre;
                nuevo.Icono = r.Icono;
                nuevo.Nombre = r.Nombre;
                nuevo.Ruta = r.Ruta;
                if (r.IdPadre > 0)
                {
                    nuevo.Padre = new MenuEe();
                    nuevo.Padre = ((from p in arr where p.IdMenu == r.IdPadre select p).FirstOrDefault());
                }
                if (arr.Any(x => x.IdPadre == r.IdMenu))
                    nuevo.items = Ordenarmenus(arr, r.IdMenu);
                arrnew.Add(nuevo);
                arr.RemoveAll(x => x.IdPadre == r.IdMenu || x.IdMenu == r.IdMenu);

            });
            return arrnew;
        }

    }
}
