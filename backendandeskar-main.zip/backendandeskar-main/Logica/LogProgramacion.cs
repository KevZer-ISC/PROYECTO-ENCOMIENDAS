﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogProgramacion:IProgramacion
    {
         
        public ProgramacionEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ProgramacionEe>($"select * from Programacion where Id_Programacion={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select Id_Programacion from Programacion where Id_Programacion={Id}");

            return nt;

        }
        public List<ProgramacionEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<ProgramacionEe>($"select * from Programacion ");

            return nt;

        }
        public int Insert(ProgramacionEe obj)
        {
            string cadena = $@"INSERT INTO Programacion
                               ( Fecha_Registro, FK_Usuario, HorarioTermino, FK_TipoProgramacion,FechaViaje,FK_Piloto,FK_Copiloto,FK_Vehiculo)
                               VALUES('{obj.Fecha_Registro}', '{obj.FK_Usuario}', '{obj.FK_TipoProgramacion}', {obj.FechaViaje}, {obj.FK_Piloto},
                                        {obj.FK_Copiloto}, {obj.FK_Vehiculo});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(ProgramacionEe obj)
        {
            string cadena = $@"UPDATE Programacion
                               SET Fecha_Registro='{obj.Fecha_Registro}', FK_Usuario='{obj.FK_Usuario}', FK_TipoProgramacion='{obj.FK_TipoProgramacion}', 
                                    FechaViaje= {obj.FechaViaje}, FK_Piloto= {obj.FK_Piloto}, FK_Copiloto= {obj.FK_Copiloto}, FK_Vehiculo= {obj.FK_Vehiculo}
                               WHERE Id_Programacion={obj.Id_Programacion};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Programacion 
                                WHERE Id_Programacion={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}

