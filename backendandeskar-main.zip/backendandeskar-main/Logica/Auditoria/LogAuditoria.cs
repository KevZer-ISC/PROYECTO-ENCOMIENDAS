﻿using Entidades;
using ILogica.Auditoria;
using ILogica.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using static Entidades.AuditoriaEe;

namespace Logica.Auditoria
{
    public class LogAuditoria : IAuditoria
    {
        private readonly IGlobalLogin _login;
        public LogAuditoria(IGlobalLogin login)
        {
            _login = login;
        }

        public void SetAuditFieldsForInsert(AuditoriaEe entity)
        {

            entity.FechaCreacion = DateTime.Now;
            entity.UsuarioCreacion = _login.IdUsuario;
            entity.Activo = true;
        }

        public void SetAuditFieldsForUpdate(AuditoriaEe entity)
        {
            entity.FechaCreacion = DateTime.Now;
            entity.FechaUltimaModificacion = DateTime.Now;
            entity.UsuarioUltimaModificacion = _login.IdUsuario;
        }
    }
}
