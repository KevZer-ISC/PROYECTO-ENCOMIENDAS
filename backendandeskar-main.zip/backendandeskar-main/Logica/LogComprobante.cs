﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogComprobante: IComprobante
    {
        public ComprobanteEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ComprobanteEe>($"select * from comprobante where Id_Comprobante={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select Id_Comprobante from comprobante where Id_Comprobante={Id}");

            return nt;

        }
        public List<ComprobanteEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<ComprobanteEe>($"select * from comprobante ");

            return nt;

        }
        public int Insert(ComprobanteEe obj)
        {
            string cadena = $@"INSERT INTO comprobante
                            ( FK_Orden, FK_Cajero, FechaRegistro, Serie, Numero)
                            VALUES( {obj.FK_Orden}, {obj.FK_Cajero}, '{obj.FechaRegistro}', '{obj.Serie}', '{obj.Numero}');
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(ComprobanteEe obj)
        {
            string cadena = $@"UPDATE comprobante
                               SET FK_Orden={obj.FK_Orden}, FK_Cajero={obj.FK_Cajero}, FechaRegistro='{obj.FechaRegistro}', Serie='{obj.Serie}', Numero='{obj.Numero}'
                               WHERE Id_Comprobante={obj.Id_Comprobante};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) ==1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from comprobante 
                                WHERE Id_Comprobante={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) ==1;
        }
    }
}
