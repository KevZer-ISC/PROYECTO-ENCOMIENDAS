﻿using Entidades;
using ILogica;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogPerfil : IPerfil
    {
        public PerfilEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<PerfilEe>($"select * from Perfil where IdPerfil={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdPerfil from  Perfil where IdPerfil={Id}");

            return nt;

        }
        public List<PerfilEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<PerfilEe>($"select * from Perfil ");

            return nt;

        }
        public List<PerfilEe> ListaObjetoByIdsPerfil(List<int> Ids)
        {
            var nt = DapperSQL.Lista<PerfilEe>($"select * from Perfil where IdPerfil in ({string.Join(",", Ids)})");

            return nt;

        }
        public int Insert(PerfilRequest obj)
        {
            string cadena = $@"
                               declare @IdRetorno int =0;
                               INSERT INTO Perfil (NombrePerfil)
                               VALUES('{obj.NombrePerfil}');
                                set @IdRetorno = (SELECT SCOPE_IDENTITY());
                               ";
            if (obj.ItemMenu.Any())
            {
                obj.ItemMenu.ForEach(m =>
                {
                    cadena += $@" Insert Into perfil_menu_rol (IdMenu,IdsRol,IdPerfil)
                                          values({m.IdMenu},'{(m.ItemRol.Count > 0 ? string.Join(";", m.ItemRol.Select(x => x.IdRol)) : "")}',@idRetorno);
                                          ";

                });
            }
            cadena += "Select @IdRetorno;";

            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(PerfilRequest obj)
        {
            string cadena = $@"UPDATE Perfil
                               SET NombrePerfil='{obj.NombrePerfil}'
                               WHERE IdPerfil={obj.IdPerfil};
                               ";
            if (obj.ItemMenu.Any() && obj.ItemMenu.Count > 0)
            {
                cadena += $@"Delete from perfil_menu_rol where IdPerfil={obj.IdPerfil};";
                obj.ItemMenu.ForEach(m =>
                {
                    cadena += $@" Insert Into perfil_menu_rol (IdMenu,IdsRol,IdPerfil)
                                          values({m.IdMenu},'{(m.ItemRol.Count > 0 ? string.Join(";", m.ItemRol.Select(x => x.IdRol)) : "")}',{obj.IdPerfil});
                                          ";

                });
            }
            cadena += "select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Perfil 
                                WHERE IdPerfil={Id};
                                Delete from perfil_menu_rol where IdPerfil={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public PerfilMenuRolResponse ListarPerfilWithMenuByIdperfil(int id)
        {
            var perfil = ObtenerObjeto(id);
            return new PerfilMenuRolResponse
            {
                IdPerfil = perfil.IdPerfil,
                NombrePerfil = perfil.NombrePerfil,
                Menus = ListarMenuByIdPerfil(perfil.IdPerfil),
            };
        }

        public List<MenuRolResponse> ListarMenuByIdPerfil(int IdPerfil)
        {
            List<MenuRolResponse> arr = new List<MenuRolResponse>();
            string consulta = $@"Select * from  perfil_menu_rol  where IdPerfil={IdPerfil}";
            var menurol = DapperSQL.Lista<PerfilMenuRolEe>(consulta);
            if (menurol.Any() && menurol.Count > 0)
            {
                var menus = new LogMenu().ListaObjetoByIds(menurol.Select(x => x.IdMenu).ToList());
                if (menus.Any() && menus.Count > 0)
                {
                    menus.ForEach(x =>
                    {
                        List<int> ids = new List<int>();
                        string[] arrId = menurol.Where(n => n.IdMenu == x.IdMenu && !string.IsNullOrWhiteSpace(n.IdsRol)).Select(n => n.IdsRol.Split(";")).FirstOrDefault();
                        if (arrId !=null && arrId.Length > 0)
                            ids = arrId.Select(Int32.Parse).ToList();
                        arr.Add(new MenuRolResponse
                        {
                            IdMenu = x.IdMenu,
                            Icono = x.Icono,
                            IdPadre = x.IdPadre,
                            Nombre = x.Nombre,
                            Ruta = x.Ruta,
                            Roles =ids.Any()? new LogRol().ListaObjetoByIdsRol(ids):null,
                        });



                    });
                }

            }
            return Ordenarmenus(arr);
        }
        public List<MenuRolResponse> Ordenarmenus(List<MenuRolResponse> arr, int Padre = 0)
        {
            List<MenuRolResponse> arrnew = new List<MenuRolResponse>();
            arr.Where(x => x.IdPadre == Padre).ToList().ForEach(r =>
            {
                MenuRolResponse nuevo = new MenuRolResponse();

                nuevo.IdMenu = r.IdMenu;
                nuevo.IdPadre = r.IdPadre;
                nuevo.Icono = r.Icono;
                nuevo.Nombre = r.Nombre;
                nuevo.Ruta = r.Ruta;
                nuevo.Roles = r.Roles;

                if (arr.Any(x => x.IdPadre == r.IdMenu))
                    nuevo.Items = Ordenarmenus(arr, r.IdMenu);
                arrnew.Add(nuevo);
                arr.RemoveAll(x => x.IdPadre == r.IdMenu || x.IdMenu == r.IdMenu);

            });
            return arrnew;
        }
    }
}
