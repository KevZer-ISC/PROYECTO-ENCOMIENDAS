﻿using Dapper;
using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogUsuario : IUsuario
    {
        public UsuarioEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<UsuarioEe>($"select * from Usuario where IdUsuario={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdUsuario from Usuario where IdUsuario={Id}");

            return nt;

        }
        public List<UsuarioEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<UsuarioEe>($"select * from Usuario ");

            return nt;

        }
        public List<UsuarioEe> ListaObjetobyIdTrabajador(int Idtrabajador)
        {
            var nt = DapperSQL.Lista<UsuarioEe>($"select * from Usuario where Fk_trabajador={Idtrabajador}");

            return nt;

        }
        public UsuarioEe ObtenerObjetobyIdTrabajadorIdAgencia(int Idtrabajador, int Idagencia)
        {
            var nt = DapperSQL.Objeto<UsuarioEe>($"select * from Usuario where Fk_trabajador={Idtrabajador} and FK_Agencia={Idagencia}");

            return nt;

        }
        public int Insert(UsuarioEe obj)
        {
            var parametros = new DynamicParameters();
            parametros.Add("@FK_Trabajador", obj.FK_Trabajador);
            parametros.Add("@FK_Agencia", obj.FK_Agencia);
            parametros.Add("@Fk_Perfil", obj.Fk_Perfil);
           

            string cadena = @"
            INSERT INTO Usuario
            ( FK_Trabajador, FK_Agencia, Fk_Perfil)
            VALUES
            (@FK_Trabajador, @FK_Agencia, @Fk_Perfil);
            SELECT SCOPE_IDENTITY();";
            return DapperSQL.Execute_Int(cadena, parametros);
        }
        public bool Update(UsuarioEe obj)
        {
            string cadena = $@"UPDATE Usuario
                               SET FK_Trabajador={obj.FK_Trabajador}, FK_Agencia={obj.FK_Agencia}, Fk_Perfil={obj.Fk_Perfil}
                               WHERE IdUsuario={obj.IdUsuario};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Usuario 
                                WHERE IdUsuario={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}

