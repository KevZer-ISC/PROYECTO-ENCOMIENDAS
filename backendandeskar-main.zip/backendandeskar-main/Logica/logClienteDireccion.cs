﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class logClienteDireccion : IClienteDireccion
    {
        public ClienteDireccionEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ClienteDireccionEe>($"select * from ClienteDireccion where IdClienteDireccion={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdClienteDireccion from ClienteDireccion where IdClienteDireccion={Id}");

            return nt;

        }
        public List<ClienteDireccionEe> ListaObjeto(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var nt = DapperSQL.Lista<ClienteDireccionEe>($@"select * from ClienteDireccion {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");

            return new List<ClienteDireccionEe>(nt);

        }
        public List<ClienteDireccionEe> ListaObjetoByIds(List<int> Ids)
        {
            var nt = DapperSQL.Lista<ClienteDireccionEe>($"select * from ClienteDireccion where IdClienteDireccion in ({string.Join(",", Ids)})");

            return nt;

        }
        public int Insert(ClienteDireccionEe obj)
        {
            string cadena = $@"INSERT INTO ClienteDireccion
                               ( IdCliente,Direccion{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@IdCliente,@Direccion{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena, obj);
        }
        public bool Update(List<ClienteDireccionEe> obj)
        {
            StringBuilder cadena = new StringBuilder();
            obj.ForEach(x =>
            {
                if (x.IdClienteDireccion == 0)
                {
                    cadena.Append($@"INSERT INTO ClienteDireccion
                               ( IdCliente,Direccion,Activo,UsuarioCreacion,FechaCreacion)
                               VALUES({x.IdCliente},'{x.Direccion}',1,{x.UsuarioCreacion},getdate());
                      
                               ");
                }
                else
                {
                    cadena.Append($@"UPDATE ClienteDireccion
                               SET IdCliente={x.IdCliente},
                                   Direccion='{x.Direccion}'
                                   ,UsuarioUltimaModificacion = {x.UsuarioUltimaModificacion},FechaUltimaModificacion = getdate()
                               WHERE IdClienteDireccion={x.IdClienteDireccion};
                               select 1;");
                }

            });
            return DapperSQL.Execute_Int(cadena.ToString(), null) == 1;
        }
        public bool Delete(ClienteDireccionEe obj)
        {
            string cadena = $@"UPDATE ClienteDireccion
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE IdClienteDireccion=@IdClienteDireccion;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }
        public List<ClienteDireccionEe> ListarByIdCliente(int IdCliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var nt = DapperSQL.Lista<ClienteDireccionEe>($@"select * from ClienteDireccion where idcliente={IdCliente} {(estado != GlobalEnum.Estado.Todos ? $" and Activo={(int)estado}" : "")}");

            return new List<ClienteDireccionEe>(nt);

        }
    }
}
