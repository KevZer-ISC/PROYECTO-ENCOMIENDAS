﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogPerfilMenuRol
    {
        public List<PerfilMenuRolEe> ListarByIdPerfil(int Id)
        {
            var nt = DapperSQL.Lista<PerfilMenuRolEe>($"select * from perfil_menu_rol where IdPerfil ={Id} ");

            return nt;
        }
    }
}
