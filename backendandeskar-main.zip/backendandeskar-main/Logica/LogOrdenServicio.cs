﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogOrdenServicio:IOrdenServicio
    {
        public OrdenServicioEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<OrdenServicioEe>($"select * from OrdenServicio where Id_Orden={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select Id_Orden from OrdenServicio where Id_Orden={Id}");

            return nt;

        }
        public List<OrdenServicioEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<OrdenServicioEe>($"select * from OrdenServicio  ");

            return nt;

        }
        public int Insert(OrdenServicioEe obj)
        {
            string cadena = $@"INSERT INTO OrdenServicio
                               ( Serie,Correlativo,IdOrigen,IdDestino,IdTipoServicio,IdTipoRecepcion,IdTipoEntrega
		                        ,IdRemitente,IdDestinatario,PersonaContacto,IdPersonaContacto,DireccionRecepcion,DireccionEntrega
		                        ,IdFormaPago,IdResponsablePago,TotalUnidades,TotalPeso,TotalBulto
		                        ,TotalVolumen,TotalDescuento,TotalImporte,IGV,SubTotal
		                        ,FechaOrden,FechaCreacion,IdEstado)
                               VALUES('{obj.Serie}','{obj.Correlativo}',{obj.IdOrigen},{obj.IdDestino},{obj.IdTipoServicio},{obj.IdTipoRecepcion},{obj.IdTipoEntrega}
		                        ,{obj.IdRemitente},{obj.IdDestinatario},{(obj.PersonaContacto?1:0)},{obj.IdPersonaContacto},'{obj.DireccionRecepcion}','{obj.DireccionEntrega}'
		                        ,{obj.IdFormaPago},{obj.IdResponsablePago},{obj.TotalUnidades},{obj.TotalPeso},{obj.TotalBulto}
		                        ,{obj.TotalVolumen},{obj.TotalDescuento},{obj.TotalImporte},{obj.IGV},{obj.SubTotal}
		                        ,'{obj.FechaOrden.ToString("yyyyMMdd")}',getdate(),{obj.IdEstado});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(OrdenServicioEe obj)
        {
            string cadena = $@"";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from OrdenServicio 
                                WHERE Id_Orden={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
