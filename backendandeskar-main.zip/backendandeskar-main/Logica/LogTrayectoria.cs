﻿using Entidades;
using ILogica;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTrayectoria : ITrayectoria
    {
        public List<TrayectoriaResponse> Listar(BusquedaTrayectoriaRequest obj)
        {
            List<TrayectoriaResponse> arr = new List<TrayectoriaResponse>();
            string cadena = $@"Select * from trayectoria where FK_Origen={obj.IdOrigen} and FK_Destino={obj.IdDestino} and convert(date, FechaCreacion)='{obj.Fecha.ToString("yyyyMMdd")}' {(obj.estado != GlobalEnum.Estado.Todos ? $" and  Activo={(int)obj.estado}" : "")}";
            var trayectoria = DapperSQL.Lista<TrayectoriaEe>(cadena);
            if (trayectoria.Any())
            {
                cadena = $@"select * from Trayectoria_Detalle where Trayectoria_Id in ({(string.Join(",", trayectoria.Select(x => x.Id)))})";
                var detalle = DapperSQL.Lista<TrayectoriaDetalleEe>(cadena);
                var sucursal = new LogAgencia().ListaObjeto();



                trayectoria.ForEach(t =>
                {
                    ComunResponse ori = (from su in sucursal where su.IdAgencia == t.FK_Origen select new ComunResponse { Id = su.IdAgencia, Descripcion = su.NombreAgencia }).FirstOrDefault();
                    ComunResponse des = (from su in sucursal where su.IdAgencia == t.FK_Destino select new ComunResponse { Id = su.IdAgencia, Descripcion = su.NombreAgencia }).FirstOrDefault();
                    GlobalEnum.Orientacion ort = t.Orientacion_Id switch
                    {
                        1 => GlobalEnum.Orientacion.Norte,
                        2 => GlobalEnum.Orientacion.Sur,
                        _ => GlobalEnum.Orientacion.Ninguno
                    };
                    List<TrayectoriaDetalleResponse> det = (from de in detalle
                                                            where de.Trayectoria_Id == t.Id
                                                            select new TrayectoriaDetalleResponse
                                                            {
                                                                Id = de.Id,
                                                                Orden = de.Orden,
                                                                PasaPorIdSucursalVenta = (from pa in sucursal where pa.IdAgencia == de.PasaPor_IdSucursalVenta select new ComunResponse { Id = pa.IdAgencia, Descripcion = pa.NombreAgencia }).FirstOrDefault(),
                                                                TiempoLlegada = formatominutosastring((int)de.TiempoLlegadaMinutos),
                                                                TiempoEstibaDesestiba = formatominutosastring((int)de.TiempoEstibaDesestibaMinutos),
                                                                TotalTiempoAcumulado = de.TotalTiempoAcumulado,
                                                                TrayectoriaTipo = de.TrayectoriaTipo_Id switch
                                                                {
                                                                    1 => GlobalEnum.TrayectoriaTipo.Inicial,
                                                                    2 => GlobalEnum.TrayectoriaTipo.Intermedio,
                                                                    3 => GlobalEnum.TrayectoriaTipo.Final,
                                                                    _ => GlobalEnum.TrayectoriaTipo.Ninguno,
                                                                }
                                                            }).ToList();


                    arr.Add(new TrayectoriaResponse
                    {
                        Id = t.Id,
                        Nombre = t.Nombre,
                        Origen = ori,
                        Destino = des,
                        TotalTiempoAcumulado = t.TotalTiempoAcumulado,
                        TotalOficinas = t.TotalOficinas,
                        Orientacion = ort,
                        Detalle = det,
                    });
                });

            }
            return arr;
        }
        private string formatominutosastring(int tiempo)
        {
            int Horas = tiempo / 60;
            int minutos = tiempo % 60;
            return $"{Horas.ToString("D2")}:{minutos.ToString("D2")}";
        }
        public TrayectoriaResponse ObtenerById(int Id)
        {
            TrayectoriaResponse arr = new TrayectoriaResponse();
            string cadena = $@"Select * from trayectoria  where Id={Id}";
            var trayectoria = DapperSQL.Objeto<TrayectoriaEe>(cadena);
            if (trayectoria.Id != 0)
            {
                cadena = $@"select * from Trayectoria_Detalle where Trayectoria_Id in ({Id})";
                var detalle = DapperSQL.Lista<TrayectoriaDetalleEe>(cadena);
                var sucursal = new LogAgencia().ListaObjeto();


                ComunResponse ori = (from su in sucursal where su.IdAgencia == trayectoria.FK_Origen select new ComunResponse { Id = su.IdAgencia, Descripcion = su.NombreAgencia }).FirstOrDefault();
                ComunResponse des = (from su in sucursal where su.IdAgencia == trayectoria.FK_Destino select new ComunResponse { Id = su.IdAgencia, Descripcion = su.NombreAgencia }).FirstOrDefault();
                GlobalEnum.Orientacion ort = trayectoria.Orientacion_Id switch
                {
                    1 => GlobalEnum.Orientacion.Norte,
                    2 => GlobalEnum.Orientacion.Sur,
                    _ => GlobalEnum.Orientacion.Ninguno
                };
                List<TrayectoriaDetalleResponse> det = (from de in detalle
                                                        where de.Trayectoria_Id == trayectoria.Id
                                                        select new TrayectoriaDetalleResponse
                                                        {
                                                            Id = de.Id,
                                                            Orden = de.Orden,
                                                            PasaPorIdSucursalVenta = (from pa in sucursal where pa.IdAgencia == de.PasaPor_IdSucursalVenta select new ComunResponse { Id = pa.IdAgencia, Descripcion = pa.NombreAgencia }).FirstOrDefault(),
                                                            TiempoLlegada = formatominutosastring((int)de.TiempoLlegadaMinutos),
                                                            TiempoEstibaDesestiba = formatominutosastring((int)de.TiempoEstibaDesestibaMinutos),
                                                            TotalTiempoAcumulado = de.TotalTiempoAcumulado,
                                                            TrayectoriaTipo = de.TrayectoriaTipo_Id switch
                                                            {
                                                                1 => GlobalEnum.TrayectoriaTipo.Inicial,
                                                                2 => GlobalEnum.TrayectoriaTipo.Intermedio,
                                                                3 => GlobalEnum.TrayectoriaTipo.Final,
                                                                _ => GlobalEnum.TrayectoriaTipo.Ninguno,
                                                            }
                                                        }).ToList();


                arr = new TrayectoriaResponse
                {
                    Id = trayectoria.Id,
                    Nombre = trayectoria.Nombre,
                    Origen = ori,
                    Destino = des,
                    TotalTiempoAcumulado = trayectoria.TotalTiempoAcumulado,
                    TotalOficinas = trayectoria.TotalOficinas,
                    Orientacion = ort,
                    Detalle = det,
                };


            }
            return arr;
        }

        public int Insert(TrayectoriaEe obj, List<TrayectoriaDetalleEe> detalle)
        {

            string cadena = $@"INSERT INTO Trayectoria
                                     ( Nombre,FK_Origen,FK_Destino,TotalTiempoAcumulado,TotalOficinas,Orientacion_Id{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@Nombre,@FK_Origen,@FK_Destino,@TotalTiempoAcumulado,@TotalOficinas,@Orientacion_Id{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            string cadenadetalle = $@"INSERT INTO Trayectoria_Detalle
                                   (Trayectoria_Id,Orden,PasaPor_IdSucursalVenta,TiempoLlegadaMinutos,
		                        	TiempoEstibaDesestibaMinutos,TotalTiempoAcumulado,TrayectoriaTipo_Id {GlobalConstant.AuditoriaInsertColumna})
                                     VALUES
                                    (@Trayectoria_Id,@Orden,@PasaPor_IdSucursalVenta,@TiempoLlegadaMinutos,
			                         @TiempoEstibaDesestibaMinutos,@TotalTiempoAcumulado,@TrayectoriaTipo_Id {GlobalConstant.AuditoriaInsertValues})";
            return DapperSQL.InsertarCabeceraDetalle(cadena, obj, cadenadetalle, detalle);
        }

    }
}
