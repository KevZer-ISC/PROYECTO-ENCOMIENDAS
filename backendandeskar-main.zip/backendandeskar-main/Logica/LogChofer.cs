﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogChofer: IChofer
    {
        public ChoferEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ChoferEe>($"select * from chofer where ID_Chofer={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select ID_Chofer from chofer where ID_Chofer={Id}");

            return nt;

        }
        public List<ChoferEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<ChoferEe>($"select * from chofer ");

            return nt;

        }
        public int Insert(ChoferEe obj)
        {
            string cadena = $@"INSERT INTO chofer
                               ( FK_Trabajador, NumeroLicenciaConducir, FechaExpiracionLicencia, TipoLicencia, Estado, Horario{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(  @FK_Trabajador, @NumeroLicenciaConducir, @FechaExpiracionLicencia, @TipoLicencia, @Estado, @Horario{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,obj);
        }
        public bool Update(ChoferEe obj)
        {
            string cadena = $@"UPDATE chofer
                               SET FK_Trabajador=@FK_Trabajador,
                                   NumeroLicenciaConducir=@NumeroLicenciaConducir,
                                   FechaExpiracionLicencia=@FechaExpiracionLicencia, 
                                   TipoLicencia=@TipoLicencia, Estado=@Estado, 
                                   Horario=@Horario
                                   {GlobalConstant.AuditoriaUpdate}
                               WHERE ID_Chofer=@ID_Chofer;
                               select 1;";
            return DapperSQL.Execute_Int(cadena,obj)==1;
        }
        public bool Delete(ChoferEe obj)
        {
            string cadena = $@"UPDATE chofer
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                 WHERE ID_Chofer=@ID_Chofer;
                               select 1;";
            return DapperSQL.Execute_Int(cadena,obj)==1;
        }
    }
}
