﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public  class LogRol:IRol
    {
        public RolEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<RolEe>($"select * from Rol where IdRol={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdRol from Rol where IdRol={Id}");

            return nt;

        }
        public List<RolEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<RolEe>($"select * from Rol ");

            return nt;

        }
        public List<RolEe> ListaObjetoByIdsRol(List<int >Ids)
        {
            var nt = DapperSQL.Lista<RolEe>($"select * from Rol where IdRol in ({string.Join(",",Ids)})");

            return nt;

        }
        public int Insert(RolEe obj)
        {
            string cadena = $@"INSERT INTO Rol
                               ( Rol)
                               VALUES('{obj.Rol}');
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(RolEe obj)
        {
            string cadena = $@"UPDATE Rol
                               SET NombreAgencia=' Rol= {obj.Rol}
                               WHERE IdRol={obj.IdRol};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Rol 
                                WHERE IdRol={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}

