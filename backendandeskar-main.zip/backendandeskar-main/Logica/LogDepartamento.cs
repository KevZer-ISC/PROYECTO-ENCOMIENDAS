﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogDepartamento:IDepartamento
    {
        public DepartamentoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<DepartamentoEe>($"select * from departamento where IdDepartamento={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdCliente from departamento where IdCliente={Id}");

            return nt;

        }
        public List<DepartamentoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<DepartamentoEe>($"select * from departamento ");

            return nt;

        }
        public int Insert(DepartamentoEe obj)
        {
            string cadena = $@"INSERT INTO departamento
                               ( NombreDepartamento)
                               VALUES('{obj.NombreDepartamento}');
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(DepartamentoEe obj)
        {
            string cadena = $@"UPDATE departamento
                               SET     NombreDepartamento
                               WHERE IdDepartamento ={obj.IdDepartamento};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from NombreDepartamento 
                                WHERE IdDepartamento={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
