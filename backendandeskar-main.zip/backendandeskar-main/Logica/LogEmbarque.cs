﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogEmbarque: IEmbarque
    {
        public EmbarqueEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<EmbarqueEe>($"select * from embarque where id_Embarque={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select id_Embarque from embarque where id_Embarque={Id}");

            return nt;

        }
        public List<EmbarqueEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<EmbarqueEe>($"select * from embarque ");

            return nt;

        }
        public int Insert(EmbarqueEe obj)
        {
            string cadena = $@"INSERT INTO embarque
                               ( FK_Orden, FK_Usuario, FechaRegistro, Ruta_Origen, Ruta_Destino, FK_TipoProgramacion, 
                               FK_Programacion, FK_Estado_Embarque)
                               VALUES( {obj.FK_Orden}, {obj.FK_Usuario}, '{obj.FechaRegistro}', {obj.Ruta_Origen}, {obj.Ruta_Destino}, {obj.FK_TipoProgramacion},
                               {obj.FK_Programacion}, {obj.FK_Estado_Embarque});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(EmbarqueEe obj)
        {
            string cadena = $@"UPDATE embarque
                               SET FK_Orden={obj.FK_Orden}, FK_Usuario={obj.FK_Usuario}, FechaRegistro='{obj.FechaRegistro}', Ruta_Origen={obj.Ruta_Origen}, 
                               Ruta_Destino={obj.Ruta_Destino}, FK_TipoProgramacion={obj.FK_TipoProgramacion}, FK_Programacion={obj.FK_Programacion}, 
                               FK_Estado_Embarque={obj.FK_Estado_Embarque}
                               WHERE id_Embarque={obj.id_Embarque};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from embarque 
                                WHERE id_Embarque={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
