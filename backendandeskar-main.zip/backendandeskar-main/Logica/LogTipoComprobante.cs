﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTipoComprobante
    {
        public List<TipoComprobanteEe> Lista(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var result = DapperSQL.Lista<TipoComprobanteEe>($"Select * from tipocomprobante {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");
            return result;
        }
    }
}
