﻿using Entidades;
using ILogica;
using Utilitarios;

namespace Logica
{
    public class LogTipoDocumento:ITipoDocumento
    {
        public TipoDocumentoEe ObtenerObjeto(int Id)
        {
            var nt = Utilitarios.DapperSQL.Objeto<Entidades.TipoDocumentoEe>($"select * from tipodocumento where idTipoDocumento={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = Utilitarios.DapperSQL.Objeto<int>($"select idTipoDocumento from tipodocumento where idTipoDocumento={Id}");

            return nt;

        }
        public List<TipoDocumentoEe> ListaObjeto()
        {
            var nt =Utilitarios.DapperSQL.Lista<Entidades.TipoDocumentoEe>($"select * from tipodocumento ");

            return nt;

        }
        public int Insert(TipoDocumentoEe obj)
        {
            string cadena = $@"INSERT INTO tipodocumento
                               ( Descripcion_TipoDocumento,tipo)
                               VALUES( '{obj.Descripcion_TipoDocumento}','{obj.Tipo}');
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(TipoDocumentoEe obj)
        {
            string cadena = $@"UPDATE tipodocumento
                               SET Descripcion_TipoDocumento='{obj.Descripcion_TipoDocumento}',
                                Tipo='{obj.Tipo}'
                               WHERE idTipoDocumento={obj.idTipoDocumento};
                               select 1;";
            return  DapperSQL.Execute_Int(cadena,null)==1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from tipodocumento 
                                WHERE idTipoDocumento={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}