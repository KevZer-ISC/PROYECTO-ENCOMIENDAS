﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogCliente : ICliente
    {
        public ClienteEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ClienteEe>($"select * from cliente where IdCliente={Id}");

            return nt;

        }
        public ClienteEe ObtenerObjetoByDocumentoTipoDocumento(int tipo, string documento, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var nt = DapperSQL.Objeto<ClienteEe>($"select * from cliente where FK_TipoDocumento={tipo} and Documento='{documento}' {(estado != GlobalEnum.Estado.Todos ? $" and Activo={(int)estado}" : "")}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdCliente from cliente where IdCliente={Id}");

            return nt;

        }
        public ClienteEe ObtenerObjetoById(int Id)
        {
            var nt = DapperSQL.Objeto<ClienteEe>($"select * from cliente where IdCliente={Id}");

            return nt;

        }
        public List<ClienteEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<ClienteEe>($"select * from cliente ");

            return nt;

        }
        public int Insert(ClienteEe obj)
        {
            string cadena = $@"INSERT INTO cliente
                                     ( FK_Departamento,FK_TipoDocumento,FK_Sucursal,Documento,Nombres,Apellidos,
                                       NombreCompleto,Direccion,Ubigeo,Telefono,Correo,Contacto,Credito{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@FK_Departamento,@FK_TipoDocumento,@FK_Sucursal,@Documento,@Nombres,@Apellidos,
                                       @NombreCompleto,@Direccion,@Ubigeo,@Telefono,@Correo,@Contacto,@Credito{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            string cadenadetalle = $@"INSERT INTO ClienteDireccion
                                    (IdCliente,Direccion {GlobalConstant.AuditoriaInsertColumna})
                                     VALUES
                                    (@IdCliente,@Direccion {GlobalConstant.AuditoriaInsertValues})";
            if (obj.Contactos != null && obj.Contactos.Count > 0)
            {
                string cadenadetalle2 = $@"INSERT INTO ClienteContacto
                                                (IdCliente,NumeroDocumento,NombreContacto,TelefonoContacto  {GlobalConstant.AuditoriaInsertColumna})
                                           VALUES
                                                (@IdCliente,@NumeroDocumento,@NombreContacto,@TelefonoContacto{GlobalConstant.AuditoriaInsertValues})";
                return DapperSQL.InsertarCabeceraDetalle(cadena, obj, cadenadetalle, obj.Direcciones, cadenadetalle2, obj.Contactos);
            }
            if (obj.Direcciones != null && obj.Direcciones.Count > 0)
                return DapperSQL.InsertarCabeceraDetalle(cadena, obj, cadenadetalle, obj.Direcciones);
            return DapperSQL.Execute_Int(cadena, obj);
        }
        public bool Update(ClienteEe obj)
        {
            string cadena = $@"UPDATE cliente
                               SET FK_Departamento=@FK_Departamento,
                                   FK_TipoDocumento=@FK_TipoDocumento,
                                   FK_Sucursal=@FK_Sucursal,
                                   Documento=@Documento,
                                   Nombres=@Nombres,
                                   Apellidos=@Apellidos,
                                   NombreCompleto=@NombreCompleto,
                                   Direccion=@Direccion,
                                   Ubigeo=@Ubigeo,
                                   Telefono=@Telefono,
                                   Correo=@Correo,
                                   Contacto=@Contacto,
                                   Credito=@Credito
                                {GlobalConstant.AuditoriaUpdate}
                               WHERE IdCliente=@IdCliente;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }
        public bool Delete(ClienteEe obj)
        {
            string cadena = $@"UPDATE cliente
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE IdCliente=@IdCliente;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }

    }
}
