﻿using Dapper;
using Entidades;
using ILogica;
using Modelos.Request;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTrabajador : ITrabajador
    {
        public TrabajadorEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<TrabajadorEe>($"select * from Trabajador where IdTrabajador={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdTrabajador from Trabajador where IdTrabajador={Id}");

            return nt;

        }
        public int ObtenerObjetoDocumento(string Documento)
        {
            var query = $"select IdTrabajador from Trabajador where DocumentoIdentidad='{Documento}'";
            var nt = DapperSQL.Objeto<int>(query);

            return nt;

        }
        public TrabajadorEe ObtenerObjetoByDocumentoClave(string Documento, string Clave)
        {
            var query = $"select t.*,u.FK_Agencia from Trabajador as t " +
                $"inner join usuario as u on u.FK_Trabajador=t.IdTrabajador where t.DocumentoIdentidad='{Documento}' and t.clave='{new Encriptacion().Encriptar(Clave)}'";
            var nt = DapperSQL.Objeto<TrabajadorEe>(query);

            return nt;

        }
        public List<TrabajadorEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<TrabajadorEe>($"select * from Trabajador ");

            return nt;

        }
        public int Insert(TrabajadorRequest obj)
        {
            bool existe = false;
            var parametros = new DynamicParameters();
            parametros.Add("@Nombre_Completo", obj.Nombre_Completo);
            parametros.Add("@Genero", obj.Genero);
            parametros.Add("@Estado", obj.Estado);
            parametros.Add("@TipoDocumento", obj.TipoDocumento);
            parametros.Add("@DocumentoIdentidad", obj.DocumentoIdentidad);
            parametros.Add("@Clave", new Encriptacion().Encriptar(obj.Clave));
            parametros.Add("@FechaContratacion", obj.FechaContratacion, DbType.DateTime);
            parametros.Add("@FechaCreacion", obj.FechaCreacion, DbType.DateTime);
            //parametros.Add("@FechaModificacion", obj.FechaModificacion, DbType.DateTime);
            //parametros.Add("@UsuarioModificacion", obj.UsuarioModificacion);

            string cadena = @"  DECLARE @IdCreacion INT; 
                                INSERT INTO Trabajador
                                (Nombre_Completo, Genero, Estado, TipoDocumento, DocumentoIdentidad, Clave, FechaContratacion, FechaCreacion)
                                VALUES
                                (@Nombre_Completo, @Genero, @Estado, @TipoDocumento, @DocumentoIdentidad, @Clave, @FechaContratacion, @FechaCreacion);
                               set @IdCreacion=( SELECT SCOPE_IDENTITY() );
                                    ";
            if (obj.Usuarios.Any())
            {
                int I = 0;

                obj.Usuarios.ForEach(x =>
                {
                    if (x.FK_Agencia != 0 && x.Fk_Perfil != 0)
                    {
                        if (!existe)
                            if (obj.Usuarios.Where(n => n.FK_Agencia == x.FK_Agencia).Count() > 1) { existe = true; return; }
                        I++;
                        parametros.Add($"@FK_Agencia{I}", x.FK_Agencia);
                        parametros.Add($"@Fk_Perfil{I}", x.Fk_Perfil);
                        cadena += $@" INSERT INTO Usuario
                                ( FK_Trabajador, FK_Agencia, Fk_Perfil)
                                VALUES
                                (@IdCreacion, @FK_Agencia{I}, @Fk_Perfil{I});";
                    }

                });

            }
            cadena += "select @IdCreacion";
            if (existe) throw new Exception("Solo puede haber un perfil por Agencia");
            return DapperSQL.Execute_Int(cadena, parametros);
        }
        public bool Update(TrabajadorRequest obj)
        {
            bool existe = false;
            string cadena = $@"UPDATE Trabajador
                               SET Nombre_Completo='{obj.Nombre_Completo}', Genero='{obj.Genero}', Estado={obj.Estado}, TipoDocumento= {obj.TipoDocumento}, DocumentoIdentidad= '{obj.DocumentoIdentidad}'
                                                    , Clave= '{new Encriptacion().Encriptar(obj.Clave)}', FechaContratacion= '{obj.FechaContratacion.ToString("yyyyMMdd")}', FechaModificacion= '{System.Convert.ToDateTime( obj.FechaUltimaModificacion).ToString("yyyyMMdd")}', UsuarioModificacion= {obj.UsuarioUltimaModificacion}
                               WHERE IdTrabajador={obj.IdTrabajador};";
            if (obj.Usuarios.Any())
            {

                cadena += $"delete Usuario where FK_Trabajador={obj.IdTrabajador} ;";

                obj.Usuarios.ForEach(x =>
                {
                    if (!existe)
                        if (obj.Usuarios.Where(n => n.FK_Agencia == x.FK_Agencia ).Count() > 1) { existe = true; return; }
                    cadena += $@" INSERT INTO Usuario
                                ( FK_Trabajador, FK_Agencia, Fk_Perfil)
                                VALUES
                                ({obj.IdTrabajador}, {x.FK_Agencia},{x.Fk_Perfil});";
                });

            }
            cadena += "select 1;";
            if (existe) throw new Exception("Existe un Perfil y Agencia Repetida");
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Trabajador 
                                WHERE IdTrabajador={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }

    }
}
