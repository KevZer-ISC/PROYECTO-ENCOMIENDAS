﻿using Entidades;
using ILogica;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogClienteNoDeseado: IClienteNoDeseado
    {
        public ClienteNoDeseadoEe ObtenerObjetoById(int Id) {

            return DapperSQL.Objeto<ClienteNoDeseadoEe>($"Select * from ClienteNoDeseado where idClienteNoDeseado={Id}");
        }
        public ClienteNoDeseadoEe ObtenerObjetoByDocumento(int TipoDocumento,string numero)
        {

            return DapperSQL.Objeto<ClienteNoDeseadoEe>($"Select * from ClienteNoDeseado where IdTipoDocumento={TipoDocumento} and NumeroDocumento='{numero}'");
        }
        public ClienteNoDeseadoEe ObtenerObjetoByDocumentoExcluirID(int Id,int TipoDocumento, string numero)
        {

            return DapperSQL.Objeto<ClienteNoDeseadoEe>($"Select * from ClienteNoDeseado where IdTipoDocumento={TipoDocumento} and NumeroDocumento='{numero}' and IdClienteNoDeseado !={Id}");
        }
        public IEnumerable<ClienteNoDeseadoEe> Lista(GlobalEnum.Estado estado = GlobalEnum.Estado.Todos) {

            return DapperSQL.Lista<ClienteNoDeseadoEe>($"Select * from ClienteNoDeseado {(estado!=GlobalEnum.Estado.Todos?$"where Activo={(int) estado}":"")} ");
        }
        public int Insert(ClienteNoDeseadoEe obj) {

            string cadena = $@"INSERT INTO ClienteNoDeseado
           (IdTipoDocumento
           ,NumeroDocumento
           ,NombreCompleto
           ,Observacion{GlobalConstant.AuditoriaInsertColumna}
           )
     VALUES
           (@IdTipoDocumento
           ,@NumeroDocumento
           ,@NombreCompleto
           ,@Observacion{GlobalConstant.AuditoriaInsertValues});
 SELECT SCOPE_IDENTITY();
";


            return DapperSQL.Execute_Int(cadena, obj);
        }
        public bool Update(ClienteNoDeseadoEe obj) {
            string cadena = $@"UPDATE ClienteNoDeseado
                                  SET IdTipoDocumento = @IdTipoDocumento
                                     ,NumeroDocumento = @NumeroDocumento
                                     ,NombreCompleto = @NombreCompleto
                                     ,Observacion = @Observacion
                                     {GlobalConstant.AuditoriaUpdate}
                                WHERE idClienteNoDeseado=@idClienteNoDeseado;
                              select 1;";


            return DapperSQL.Execute_Int(cadena, obj)==1;

        }

        public bool ActivarDesactivar(ClienteNoDeseadoEe obj) {
            string cadena = $@"UPDATE ClienteNoDeseado
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE idClienteNoDeseado=@idClienteNoDeseado;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;

        }
    }
}
