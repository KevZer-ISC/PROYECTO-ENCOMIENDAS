﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogNotaCredito:INotaCredito
    {
        public NotaCreditoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<NotaCreditoEe>($"select * from NotaCredito where idNotaCredito={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select idNotaCredito from NotaCredito where idNotaCredito={Id}");

            return nt;

        }
        public List<NotaCreditoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<NotaCreditoEe>($"select * from NotaCredito ");

            return nt;

        }
        public int Insert(NotaCreditoEe obj)
        {
            string cadena = $@"INSERT INTO NotaCredito
                               ( FK_Orden, FK_Usuario, FechaRegistro, Serie,NumeroOrden,FK_comprobante)
                               VALUES('{obj.FK_Orden}', '{obj.FK_Usuario}', '{obj.FechaRegistro}', {obj.NumeroOrden}, {obj.Serie}, {obj.FK_comprobante});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(NotaCreditoEe obj)
        {
            string cadena = $@"UPDATE NotaCredito
                               SET FK_Orden='{obj.FK_Orden}', FK_Usuario='{obj.FK_Usuario}', FechaRegistro='{obj.FechaRegistro}', Serie= {obj.Serie}, Serie= {obj.Serie}
                                        , NumeroOrden= {obj.NumeroOrden}, FK_comprobante= {obj.FK_comprobante}
                               WHERE idNotaCredito={obj.idNotaCredito};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from NotaCredito 
                                WHERE idNotaCredito={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
