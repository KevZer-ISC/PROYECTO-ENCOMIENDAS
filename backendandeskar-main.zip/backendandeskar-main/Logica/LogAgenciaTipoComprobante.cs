﻿using Entidades;
using ILogica;
using ILogica.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using static Utilitarios.GlobalEnum;

namespace Logica
{
    public class LogAgenciaTipoComprobante: IAgenciaTipoComprobante
    {
        private readonly IGlobalLogin _login;
        public LogAgenciaTipoComprobante(IGlobalLogin login) {
        _login = login;
        }
        public List<AgenciaTipoComprobanteEe> Lista(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var result = DapperSQL.Lista<AgenciaTipoComprobanteEe>($"Select * from AgenciaTipoComprobante {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");
            return result;
        }
        public List<AgenciaTipoComprobanteEe> BuscarByAgencia(int IdAgencia)
        {
            var result = DapperSQL.Lista<AgenciaTipoComprobanteEe>($"Select * from AgenciaTipoComprobante where IdAgencia={IdAgencia}");
            return result;
        }
        public AgenciaTipoComprobanteEe BuscarByAgenciaByTipoComprobante(int IdAgencia, GlobalEnum.TipoComprobante tipoComprobante = GlobalEnum.TipoComprobante.Ninguno)
        {
            var result = DapperSQL.Objeto<AgenciaTipoComprobanteEe>($"Select * from AgenciaTipoComprobante where IdAgencia= {IdAgencia} {(tipoComprobante != TipoComprobante.Ninguno ? $" and IdTipoComprobante ={(int)tipoComprobante}" : "")}");
            return result;
        }
        public AgenciaTipoComprobanteEe ObtenerByUsuario(GlobalEnum.TipoComprobante tipoComprobante=TipoComprobante.Ninguno)
        {
            var result = BuscarByAgenciaByTipoComprobante(_login.IdAgencia, tipoComprobante);
            return result;
        }
    }
}
