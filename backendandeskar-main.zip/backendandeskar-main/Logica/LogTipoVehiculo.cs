﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTipoVehiculo: ITipoVehiculo
    {
        public TipoVehiculoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<TipoVehiculoEe>($"select * from TipoVehiculo where Id_TipoVehiculo={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select Id_TipoVehiculo from TipoVehiculo where Id_TipoVehiculo={Id}");

            return nt;

        }
        public List<TipoVehiculoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<TipoVehiculoEe>($"select * from TipoVehiculo ");

            return nt;

        }
        public int Insert(TipoVehiculoEe obj)
        {
            string cadena = $@"INSERT INTO TipoVehiculo
                               ( ConsumoCombustible, Descripcion)
                               VALUES('{obj.ConsumoCombustible}', '{obj.Descripcion}');;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(TipoVehiculoEe obj)
        {
            string cadena = $@"UPDATE TipoVehiculo
                               SET ConsumoCombustible='{obj.ConsumoCombustible}', Descripcion='{obj.Descripcion}
                               WHERE Id_TipoVehiculo={obj.Id_TipoVehiculo};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from TipoVehiculo 
                                WHERE Id_TipoVehiculo={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }

    }
}
