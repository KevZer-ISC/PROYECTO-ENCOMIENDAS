﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    internal class LogOrdenServicioItem:IOrdenServicioItem
    {
        public OrdenServicioItemEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<OrdenServicioItemEe>($"select * from OrdenServicioItem where id_Item={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select id_Item from OrdenServicioItem where id_Item={Id}");

            return nt;

        }
        public List<OrdenServicioItemEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<OrdenServicioItemEe>($"select * from OrdenServicioItem ");

            return nt;

        }
        public int Insert(OrdenServicioItemEe obj)
        {
            string cadena = $@"INSERT INTO OrdenServicioItem
                               ( FK_OrdenServicio, Descripcion, Estado, Unidad, Numero, Peso, Factor, PrecioUnitario,PrecioTotal)
                               VALUES('{obj.FK_OrdenServicio}', '{obj.Descripcion}', '{obj.Estado}', {obj.Unidad}, {obj.Numero}, {obj.Peso}, {obj.Factor}
                                        , {obj.PrecioUnitario},  {obj.PrecioTotal});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(OrdenServicioItemEe obj)
        {
            string cadena = $@"UPDATE OrdenServicioItem
                               SET FK_OrdenServicio='{obj.FK_OrdenServicio}', Descripcion='{obj.Descripcion}', Estado='{obj.Estado}', Unidad= {obj.Unidad}
                                     , Numero= {obj.Numero}, Peso= {obj.Peso}, Factor= {obj.Factor}, PrecioUnitario= {obj.PrecioUnitario}, PrecioTotal= {obj.PrecioTotal}
                               WHERE id_Item={obj.id_Item};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from OrdenServicioItem 
                                WHERE id_Item={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
