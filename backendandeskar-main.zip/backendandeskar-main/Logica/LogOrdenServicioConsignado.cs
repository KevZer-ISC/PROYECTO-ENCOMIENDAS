﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogOrdenServicioConsignado:IOrdenServicioConsignado
    {
        public OrdenServicioConsignadoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<OrdenServicioConsignadoEe>($"select * from agencia where FK_OrdenServicio={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select FK_OrdenServicio from OrdenServicioConsignado where FK_OrdenServicio={Id}");

            return nt;

        }
        public List<OrdenServicioConsignadoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<OrdenServicioConsignadoEe>($"select * from OrdenServicioConsignado ");

            return nt;

        }
        public int Insert(OrdenServicioConsignadoEe obj)
        {
            string cadena = $@"INSERT INTO OrdenServicioConsignado
                               ( FK_Consignado, FechaRegistro, FK_Usuario, Estado_Baja)
                               VALUES('{obj.FK_Consignado}', '{obj.FechaRegistro}', '{obj.FK_Usuario}', {obj.Estado_Baja});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(OrdenServicioConsignadoEe obj)
        {
            string cadena = $@"UPDATE OrdenServicioConsignado
                               SET FK_Consignado='{obj.FK_Consignado}', FechaRegistro='{obj.FechaRegistro}', FK_Usuario='{obj.FK_Usuario}', Estado_Baja= {obj.Estado_Baja}
                               WHERE FK_OrdenServicio={obj.FK_OrdenServicio};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from OrdenServicioConsignado 
                                WHERE FK_OrdenServicio={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
