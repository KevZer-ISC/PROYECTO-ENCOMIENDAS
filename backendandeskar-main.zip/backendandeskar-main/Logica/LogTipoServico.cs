﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogTipoServico: ITipoServicio
    {
        public List<TipoServicioEe> Listar(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            return DapperSQL.Lista<TipoServicioEe>($@"select * from TipoServicio {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");

        }
    }
}
