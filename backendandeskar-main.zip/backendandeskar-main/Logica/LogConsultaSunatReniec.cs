﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogConsultaSunatReniec : IConsultaSunatReniec
    {
        private static readonly HttpClient client = new HttpClient();
        public async Task<ClienteEe> ConsultarRuc(string Ruc)
        {
            try
            {
                var url = GlobalConstant.RucFullConsulta + Ruc;

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GlobalConstant.TokenConsultas);

                var response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                DatosRucEe datos = JsonSerializer.Deserialize<DatosRucEe>(responseContent);
                if (datos != null && !string.IsNullOrEmpty(datos.numeroDocumento))
                {
                    return new ClienteEe
                    {
                        Documento = datos.numeroDocumento,
                        NombreCompleto = datos.razonSocial,
                        Direccion = datos.direccion,

                    };
                }
                return null;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("422"))
                    return null;
                throw;
            }

        }
        public async Task<ClienteEe> ConsultarDni(string Dni)
        {
            try
            {
                var url = GlobalConstant.ReniecConsulta + Dni;

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GlobalConstant.TokenConsultas);

                var response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                DatosDniEe datos = JsonSerializer.Deserialize<DatosDniEe>(responseContent);
                if (datos != null && !string.IsNullOrEmpty(datos.numeroDocumento))
                {
                    return new ClienteEe
                    {
                        Documento = datos.numeroDocumento,
                        Nombres = datos.nombres,
                        Apellidos = $"{datos.apellidoPaterno} {datos.apellidoMaterno}",
                        NombreCompleto = $"{datos.nombres} {datos.apellidoPaterno} {datos.apellidoMaterno}"
                    }; 
                }
                return null;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("422"))
                    return null;
                throw;
            }

        }
    }
}
