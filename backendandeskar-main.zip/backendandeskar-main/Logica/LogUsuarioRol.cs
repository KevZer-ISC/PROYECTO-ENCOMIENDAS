﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogUsuarioRol: IUsuarioRol
    {
        public UsuarioRolEe ObtenerObjetobyIdUsuario(int Id)
        {
            var nt = DapperSQL.Objeto<UsuarioRolEe>($"select * from Usuario_Rol where FK_usuario={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select FK_usuario from Usuario_Rol where FK_usuario={Id}");

            return nt;

        }
        public List<UsuarioRolEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<UsuarioRolEe>($"select * from Usuario_Rol ");

            return nt;

        }
        public List<UsuarioRolEe> ListaObjetoByIdUsuario(int Id)
        {
            var nt = DapperSQL.Lista<UsuarioRolEe>($"select * from Usuario_Rol where FK_usuario={Id}");

            return nt;

        }
        public int Insert(UsuarioRolEe obj)
        {
            string cadena = $@"INSERT INTO Usuario_Rol
                               ( FK_rol)
                               VALUES('{obj.FK_rol});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(UsuarioRolEe obj)
        {
            string cadena = $@"UPDATE Usuario_Rol
                               SET FK_rol='{obj.FK_rol}'
                               WHERE FK_usuario={obj.FK_usuario};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Usuario_Rol 
                                WHERE FK_usuario={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
