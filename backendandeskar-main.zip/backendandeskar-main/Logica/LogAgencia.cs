﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogAgencia: IAgencia
    {
        public AgenciaEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<AgenciaEe>($"select * from agencia where IdAgencia={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdAgencia from agencia where IdAgencia={Id}");

            return nt;

        }
        public List<AgenciaEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<AgenciaEe>($"select * from agencia ");

            return new List<AgenciaEe>(nt);

        }
        public List<AgenciaEe> ListaObjetoByIds(List<int>Ids)
        {
            var nt = DapperSQL.Lista<AgenciaEe>($"select * from agencia where IdAgencia in ({string.Join(",",Ids)})");

            return nt;

        }
        public int Insert(AgenciaEe obj)
        {
            string cadena = $@"INSERT INTO agencia
                               ( NombreAgencia,DireccionAgencia,HorarioInicio, HorarioTermino, FK_EstadoAgencia{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@NombreAgencia,@DireccionAgencia,@HorarioInicio, @HorarioTermino, @FK_EstadoAgencia{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,obj);
        }
        public bool Update(AgenciaEe obj)
        {
            string cadena = $@"UPDATE agencia
                               SET NombreAgencia=@NombreAgencia,
                                   DireccionAgencia=@DireccionAgencia,
                                   HorarioInicio=@HorarioInicio, 
                                   HorarioTermino=@HorarioTermino, 
                                   FK_EstadoAgencia= @FK_EstadoAgencia
                                   {GlobalConstant.AuditoriaUpdate}
                               WHERE IdAgencia=@IdAgencia;
                               select 1;";
            return DapperSQL.Execute_Int(cadena,obj) == 1;
        }
        public bool Delete(AgenciaEe obj)
        {
            string cadena = $@"UPDATE agencia
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE IdAgencia=@IdAgencia;
                               select 1;";
            return DapperSQL.Execute_Int(cadena,obj) == 1;
        }
        public List<AgenciaEe> ListarAgenciaByDocumentoTrabajador(string Documento)
        {
            int Id = new LogTrabajador().ObtenerObjetoDocumento(Documento);
            if (Id == 0) throw new Exception("Documento No encontrado");
            List<UsuarioEe> usuarios = new LogUsuario().ListaObjetobyIdTrabajador(Id);
            if (!usuarios.Any()) throw new Exception("Usuario No encontrado");
            return ListaObjetoByIds((from us in usuarios select us.FK_Agencia).ToList());

        }
    }
}
