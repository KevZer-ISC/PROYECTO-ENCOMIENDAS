﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogVehiculo:IVehiculo  
    {
        public VehiculoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<VehiculoEe>($"select * from Vehiculo where Id_Vehiculo={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select Id_Vehiculo from Vehiculo where Id_Vehiculo={Id}");

            return nt;

        }
        public List<VehiculoEe> ListaObjeto()
        {
            var nt = DapperSQL.Lista<VehiculoEe>($"select * from Vehiculo ");

            return nt;

        }
        public int Insert(VehiculoEe obj)
        {
            string cadena = $@"INSERT INTO Vehiculo
                               ( FK_VehiculoTipo, FK_Usuario, Fecha_Registro, ejes, Fecha_Inscripción, Placa, Serie_Vehiculo, Marca, Modelo, Estado, id_Estado_Vehiculo,FK_Chofer,Serie_Motor)
                               VALUES('{obj.FK_VehiculoTipo}', '{obj.FK_Usuario}', '{obj.Fecha_Registro}', {obj.ejes}, {obj.Fecha_Inscripción}, {obj.Placa}, {obj.Serie_Vehiculo}, {obj.Marca}, {obj.Modelo}, {obj.Estado}, {obj.id_Estado_Vehiculo}, {obj.FK_Chofer}, {obj.Serie_Motor});;
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena,null);
        }
        public bool Update(VehiculoEe obj)
        {
            string cadena = $@"UPDATE Vehiculo
                               SET FK_VehiculoTipo='{obj.FK_VehiculoTipo}', FK_Usuario='{obj.FK_Usuario}', Fecha_Registro='{obj.Fecha_Registro}', ejes='{obj.ejes}', Fecha_Inscripción='{obj.Fecha_Inscripción}', Placa='{obj.Placa}', Serie_Vehiculo= {obj.Serie_Vehiculo}
                                                        , Marca= {obj.Marca}, Modelo= {obj.Modelo}, Estado= {obj.Estado}, id_Estado_Vehiculo= {obj.id_Estado_Vehiculo}, FK_Chofer= {obj.FK_Chofer}
                                                        , Serie_Motor= {obj.Serie_Motor}
                               WHERE Id_Vehiculo={obj.Id_Vehiculo};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
        public bool Delete(int Id)
        {
            string cadena = $@"delete from Vehiculo 
                                WHERE Id_Vehiculo={Id};
                               select 1;";
            return DapperSQL.Execute_Int(cadena,null) == 1;
        }
    }
}
