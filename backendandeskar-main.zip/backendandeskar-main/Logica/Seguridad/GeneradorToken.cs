﻿using Entidades;
using Microsoft.IdentityModel.Tokens;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Utilitarios.JWT;

namespace Logica.Seguridad
{
    public class GeneradorToken
    {
        public async Task<string> GenerarToken(TrabajadorEe Tr, UsuarioEe Us, AgenciaEe Ag, PerfilEe Pe, List<PerfilMenuRolEe> Pmr)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();

            List<Claim> allClaims = new List<Claim>();
            allClaims.Add(new Claim("IdTrabajador", Us.FK_Trabajador.ToString()));
            allClaims.Add(new Claim("IdUsuario", Us.IdUsuario.ToString()));
            allClaims.Add(new Claim("NombreUsuario", Tr.Nombre_Completo.ToString()));
            allClaims.Add(new Claim("IdPerfil", Pe.IdPerfil.ToString()));
            allClaims.Add(new Claim("NombrePerfil", Pe.NombrePerfil.ToString()));
            allClaims.Add(new Claim("IdAgencia", Ag.IdAgencia.ToString()));
            allClaims.Add(new Claim("NombreAgencia", Ag.NombreAgencia.ToString()));
            if (Pmr.Any())
            {
                List<RolEe> rol = new LogRol().ListaObjeto();
                List<MenuEe> menu = new LogMenu().ListaObjeto();
                Pmr.Where(r => !string.IsNullOrWhiteSpace(r.IdsRol)).ToList().ForEach(r =>
                {
                    List<int> ids = new List<int>();
                    string[] arrId = r.IdsRol.Split(";");
                    if (arrId != null && arrId.Length > 0)
                    {
                        ids = arrId.Select(Int32.Parse).ToList();
                        ids.ForEach(n => allClaims.Add(new Claim (menu.Where(x => x.IdMenu == r.IdMenu).FirstOrDefault().Nombre, rol.Where(x => x.IdRol == n).Select(x => x.Rol).FirstOrDefault() )));
                    }
                });

            }
            allClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
            allClaims.Add(new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToUniversalTime().ToString()));
            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(allClaims),
                Expires = DateTime.UtcNow.AddHours(24),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(JwtConfig.JwtSecret)), SecurityAlgorithms.HmacSha256)
            };

            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        }

        public async Task<string> GenerateRefreshToken(TrabajadorEe Tr, UsuarioEe Us)
        {
            try
            {
                var jwtTokenHandler = new JwtSecurityTokenHandler();
                //var key = Encoding.ASCII.GetBytes("7vj7CiwrzpcRTD35hHSGpDvfEHjrSq2oK3Y68tUA");
                List<ClaimsIdentity> permisos = new List<ClaimsIdentity>();
                var tokenDescriptor = new SecurityTokenDescriptor()
                {
                    Subject = new ClaimsIdentity(new[]
    {
                    new Claim("IdUsuario", Us.IdUsuario.ToString()),
                    new Claim("NombreUsuario",Tr.Nombre_Completo.ToString()),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToUniversalTime().ToString()),
                }),
                    Expires = DateTime.UtcNow.AddHours(24),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(JwtConfig.JwtSecret)), SecurityAlgorithms.HmacSha256)
                };
                var token = jwtTokenHandler.CreateToken(tokenDescriptor);
                //if (tokenDescriptor.Expires > DateTime.UtcNow)
                //    throw new GlobalExceptionValidate($"Sesión caducada, por favor vuelva a iniciar sesión");
                return jwtTokenHandler.WriteToken(token);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
