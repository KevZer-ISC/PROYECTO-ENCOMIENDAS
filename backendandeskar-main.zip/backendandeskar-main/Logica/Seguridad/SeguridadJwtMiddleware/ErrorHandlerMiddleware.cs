﻿using Logica.Seguridad.SeguridadJwtAuthorization;
using System.Buffers;
using System.Net.Mime;
using System.Net;
using System.Text;
using System.Text.Json;

using Utilitarios;
using Utilitarios.Exceptions;
using System.IO.Pipelines;
using Microsoft.AspNetCore.Http;

namespace Logica.Seguridad.SeguridadJwtMiddleware
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
            //_logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (OperationAuthorizerException error)
            {
                ToReturnError<object> response = new ToReturnError<object>(error.Message, 401);
                //_logger.Warning(response.TransactionId, error.Message, error);
                await HandleExceptionAsync(context, HttpStatusCode.Unauthorized, response);
            }
            catch (GlobalExceptionValidate error)
            {
                ToReturnError<object> response = new ToReturnError<object>(error.Message);
                await HandleExceptionAsync(context, HttpStatusCode.OK, response);
            }
            catch (FunctionalException error)
            {
                ToReturnError<object> response = new ToReturnError<object>(error.Message, error.customCode);
                //_logger.Warning(response.TransactionId, error.Message, error);
                await HandleExceptionAsync(context, HttpStatusCode.OK, response);
            }
            catch (TechnicalException error)
            {
                ToReturnError<object> response = new ToReturnError<object>(error.Message, error.customCode);
                //_logger.Error(response.TransactionId, error.Message, error);
                await HandleExceptionAsync(context, HttpStatusCode.OK, response);
            }
            catch (Exception error)
            {
                ToReturnError<object> response = new ToReturnError<object>(error.Message);
                //_logger.Error(response.TransactionId, error.Message, error, await GetInfoFromRequest(context));
                await HandleExceptionAsync(context, HttpStatusCode.OK, response);
            }
        }

        private Task HandleExceptionAsync<T>(HttpContext context, HttpStatusCode statusCode, ToReturnError<T> response)
        {
            context.Response.ContentType = MediaTypeNames.Application.Json;
            context.Response.StatusCode = (int)statusCode;
            return context.Response.WriteAsync(JsonSerializer.Serialize(response));
        }
        /*
        private async Task<string> GetInfoFromRequest(HttpContext context)
        {
            var request = context.Request;
            string strInfoBody = string.Empty;
            bool infoBody = request.ContentLength > 0;
            if (infoBody)
            {
                request.Body.Position = 0;
                List<string> tmp = await GetListOfStringFromPipe(request.BodyReader);
                request.Body.Position = 0;

                strInfoBody = string.Concat("\r\nBody: ", string.Join("", tmp.ToArray()));
            }

            return string.Concat('[', request.Method, "]: ", request.Path, '/', request.QueryString, infoBody ? strInfoBody : string.Empty);
        }
        */
        private Task<List<string>> GetListOfStringFromPipe(object bodyReader)
        {
            throw new NotImplementedException();
        }

        private async Task<List<string>> GetListOfStringFromPipe(PipeReader reader)
        {
            List<string> results = new List<string>();

            while (true)
            {
                ReadResult readResult = await reader.ReadAsync();
                var buffer = readResult.Buffer;

                SequencePosition? position = null;

                do
                {
                    // Look for a EOL in the buffer
                    position = buffer.PositionOf((byte)'\n');

                    if (position != null)
                    {
                        var readOnlySequence = buffer.Slice(0, position.Value);
                        AddStringToList(results, in readOnlySequence);

                        // Skip the line + the \n character (basically position)
                        buffer = buffer.Slice(buffer.GetPosition(1, position.Value));
                    }
                }
                while (position != null);


                if (readResult.IsCompleted && buffer.Length > 0)
                {
                    AddStringToList(results, in buffer);
                }

                reader.AdvanceTo(buffer.Start, buffer.End);

                // At this point, buffer will be updated to point one byte after the last
                // \n character.
                if (readResult.IsCompleted)
                {
                    break;
                }
            }

            return results;
        }

        private static void AddStringToList(List<string> results, in ReadOnlySequence<byte> readOnlySequence)
        {
            // Separate method because Span/ReadOnlySpan cannot be used in async methods
            ReadOnlySpan<byte> span = readOnlySequence.IsSingleSegment ? readOnlySequence.First.Span : readOnlySequence.ToArray().AsSpan();
            results.Add(Encoding.UTF8.GetString(span));
        }
    }
}
