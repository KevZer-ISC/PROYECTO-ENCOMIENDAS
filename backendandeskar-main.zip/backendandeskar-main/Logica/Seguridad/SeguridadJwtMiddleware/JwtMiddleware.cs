﻿using ILogica.Seguridad;
using Logica.Seguridad.SeguridadJwtAuthorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Modelos.Response;

namespace Logica.Seguridad.SeguridadJwtMiddleware
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IOperationAuthorizeTokenRepository _token;

        public JwtMiddleware(RequestDelegate next, IOperationAuthorizeTokenRepository token)
        {
            _next = next;
            _token = token;
        }

        public async Task Invoke(HttpContext context,IGlobalLogin _login)
        {
            var headerValues = context.Request.Headers;
            if (headerValues["Authorization"].ToString() == "") throw new OperationAuthorizerException((int)HttpStatusCode.Unauthorized, "Token No Encontrado");
            if (headerValues["Authorization"].ToString() != "")
            {
                var header = AuthenticationHeaderValue.Parse(headerValues["Authorization"]);
                var credentials = header.Parameter;

                LoginResponse _identity = _token.attachTenantToContext(credentials);
            
                 if (_identity==null ||_identity.IdUsuario==0) throw new OperationAuthorizerException((int)HttpStatusCode.Unauthorized, "Token Denegado");
                _login.IdUsuario = _identity.IdUsuario;
                _login.IdPerfil =(int) _identity.IdPerfil;
                _login.IdAgencia = (int)_identity.IdAgencia;
                _login.IdTrabajador = (int)_identity.IdTrabajador;
                /*   _identity.IsSucursalTotal = GlobalConstant.metodosucursal.Any(f => context.Request.Path.Value.Contains(f));

                  context.Items["tenant"] = _identity.IdTenant;
                  context.Request.Headers.Add("tenant", _identity.IdTenant.ToString());
                  context.Request.Headers.Add("useridentity", JsonSerializer.Serialize(_identity));
                  context.Request.Headers.Add("userid", _identity.IdUsuario.ToString());*/
            }
            await _next(context);
        }
    }
}
