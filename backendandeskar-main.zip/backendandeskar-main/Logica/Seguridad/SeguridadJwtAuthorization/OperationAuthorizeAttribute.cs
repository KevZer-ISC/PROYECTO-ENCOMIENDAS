﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica.Seguridad.SeguridadJwtAuthorization
{
    public class OperationAuthorizeAttribute : AuthorizeAttribute
    {
        const string POLICY_PREFIX = GlobalConstant.POLICY_PREFIX;

        public OperationAuthorizeAttribute(string requiredPermission, string requieredController) =>
            RequiredPermission = $"{requiredPermission}-{requieredController}";

        public string? RequiredPermission
        {
            get
            {
                return Policy?.Substring(POLICY_PREFIX.Length);
            }
            set
            {
                Policy = $"{POLICY_PREFIX}{value}";
            }
        }
    }
}
