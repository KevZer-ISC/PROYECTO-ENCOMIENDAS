﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Logica.Seguridad.SeguridadJwtAuthorization
{
    public class OperationAuthorizerException : Exception
    {
        public int status { get; set; }
        public OperationAuthorizerException(int statusCode, string message) : base(message)
        {
            this.status = statusCode;
        }
        public OperationAuthorizerException(string message, Exception innerException) : base(message, innerException)
        {
        }
        protected OperationAuthorizerException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
