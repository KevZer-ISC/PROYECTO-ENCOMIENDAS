﻿using ILogica.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace Logica.Seguridad.SeguridadJwtAuthorization
{
    public class OperationAuthorizerHandler : AuthorizationHandler<OperationAuthorizeRequirement>
    {
        private readonly IOperationAuthorizeTokenRepository _token;

        public OperationAuthorizerHandler(IOperationAuthorizeTokenRepository token)
        {
            _token = token;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, OperationAuthorizeRequirement requirement)
        {
            var headerValues = (context.Resource as HttpContext).Request.Headers;
            if (headerValues["Authorization"].ToString() == "") throw new OperationAuthorizerException((int)HttpStatusCode.Unauthorized, "Token No Encontrado");

            var header = AuthenticationHeaderValue.Parse(headerValues["Authorization"]);
            var credentials = header.Parameter;

            if (!_token.attachAccountToContext(credentials)) throw new OperationAuthorizerException((int)HttpStatusCode.Unauthorized, "Token Denegado");

            var persmisos = requirement.Permission.Split("-");
            string _type = persmisos[1];
            string _value = persmisos[0];

            if (!context.User.HasClaim(c => c.Type == _type && c.Value.Contains(_value, StringComparison.OrdinalIgnoreCase)))
            {
                var routeValues = (context.Resource as HttpContext).Request.RouteValues;
                string actionName = "";
                string ctrlName = "";
                if (routeValues != null)
                {
                    actionName = routeValues["action"].ToString();
                    ctrlName = routeValues["controller"].ToString();
                }
                context.Fail();
                throw new OperationAuthorizerException((int)HttpStatusCode.Forbidden, $"Denegado, No cuenta con la politica {_value} que permite la acción sobre el metodo {actionName} del controlador {ctrlName}");

            }
            context.Succeed(requirement);
            return Task.CompletedTask;

        }
    }
}
