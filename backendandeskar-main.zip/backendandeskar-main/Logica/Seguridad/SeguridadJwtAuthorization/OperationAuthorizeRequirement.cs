﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica.Seguridad.SeguridadJwtAuthorization
{
    public class OperationAuthorizeRequirement : IAuthorizationRequirement
    {
        public OperationAuthorizeRequirement(string permission) =>
        Permission = permission;

        public string Permission { get; }
    }
}
