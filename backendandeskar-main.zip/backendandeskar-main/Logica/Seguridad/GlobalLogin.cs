﻿using ILogica.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica.Seguridad
{
    public class GlobalLogin: IGlobalLogin
    {
        public  int IdUsuario { get; set; }
        public  int IdPerfil { get; set; }
        public  int IdAgencia { get; set; }
        public  int IdTrabajador { get; set; }
        
    }
}
