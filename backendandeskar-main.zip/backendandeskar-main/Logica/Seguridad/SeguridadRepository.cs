﻿using Azure.Core;
using Dapper;
using Entidades;
using ILogica;
using ILogica.Seguridad;
using Microsoft.IdentityModel.Tokens;
using Modelos.Request;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using Utilitarios.JWT;

namespace Logica.Seguridad
{
    public class SeguridadRepository : ISeguridadRepository
    {

        public LoginResponse LoginByDocumentoAgenciaClave(LoginRequest login)
        {
            TrabajadorEe trabajador = new LogTrabajador().ObtenerObjetoByDocumentoClave(login.Documento, login.Contraseña);
            if (trabajador == null || trabajador.IdTrabajador == 0) throw new Exception("Trabajador no encontrado");
            UsuarioEe usuario = new LogUsuario().ObtenerObjetobyIdTrabajadorIdAgencia(trabajador.IdTrabajador, login.IdAgencia);
            if (usuario == null || usuario.IdUsuario == 0) throw new Exception("Usuario No encontrado");
            AgenciaEe agencia = new LogAgencia().ObtenerObjeto(login.IdAgencia);
            if (agencia == null || agencia.IdAgencia == 0) throw new Exception("Agencia No encontrado");
            PerfilEe perfil = new LogPerfil().ObtenerObjeto(usuario.Fk_Perfil);
            if (perfil == null || perfil.IdPerfil == 0) throw new Exception("Perfil No encontrado");
            List<PerfilMenuRolEe> perfilmenu = new LogPerfilMenuRol().ListarByIdPerfil(perfil.IdPerfil);
            LoginResponse Response = new LoginResponse
            {
                Nombre_Completo = trabajador.Nombre_Completo,
                DocumentoIdentidad = trabajador.DocumentoIdentidad,
                Genero = trabajador.Genero,
                Agencia = agencia.NombreAgencia,
                IdUsuario = usuario.IdUsuario,
                Perfil = perfil.NombrePerfil,
                Token = new GeneradorToken().GenerarToken(trabajador, usuario, agencia, perfil, perfilmenu).Result,
                RefreshToken = new GeneradorToken().GenerateRefreshToken(trabajador, usuario).Result,
            };

            return Response;
        }

        public LoginResponse LoginByIdusuario(int Idusuario)
        {
            UsuarioEe usuario = new LogUsuario().ObtenerObjeto(Idusuario);
            if (usuario == null || usuario.IdUsuario == 0) throw new Exception("Usuario No encontrado");
            TrabajadorEe trabajador = new LogTrabajador().ObtenerObjeto(usuario.FK_Trabajador);
            if (trabajador == null || trabajador.IdTrabajador == 0) throw new Exception("Trabajador no encontrado");
            AgenciaEe agencia = new LogAgencia().ObtenerObjeto(usuario.FK_Agencia);
            if (agencia == null || agencia.IdAgencia == 0) throw new Exception("Agencia No encontrado");
            PerfilEe perfil = new LogPerfil().ObtenerObjeto(usuario.Fk_Perfil);
            if (perfil == null || perfil.IdPerfil == 0) throw new Exception("Perfil No encontrado");
            List<PerfilMenuRolEe> perfilmenu = new LogPerfilMenuRol().ListarByIdPerfil(perfil.IdPerfil);
            LoginResponse Response = new LoginResponse
            {
                Nombre_Completo = trabajador.Nombre_Completo,
                DocumentoIdentidad = trabajador.DocumentoIdentidad,
                Genero = trabajador.Genero,
                Agencia = agencia.NombreAgencia,
                IdUsuario = usuario.IdUsuario,
                Perfil = perfil.NombrePerfil,
                Token = new GeneradorToken().GenerarToken(trabajador, usuario, agencia, perfil, perfilmenu).Result,
                RefreshToken = new GeneradorToken().GenerateRefreshToken(trabajador, usuario).Result,
            };
            return Response;
        }

        public LoginResponse RefreshToken(TokenRefreshRequest obj)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            tokenHandler.ValidateToken(obj.RefreshToken, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(JwtConfig.JwtSecret)),
                ValidateIssuer = JwtConfig.JwtValidateIssuer,
                ValidateAudience = JwtConfig.JwtValidateAudience,
                // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                ClockSkew = TimeSpan.Zero
            }, out SecurityToken validatedToken);

            var jwtToken = (JwtSecurityToken)validatedToken;
            var UsuarioId = jwtToken.Claims.Where(x => x.Type == "IdUsuario").Select(x => x.Value).FirstOrDefault();
            return LoginByIdusuario(ConvertForce.toInt(UsuarioId));
        }


        public List<AgenciaEe> ListarAgenciaByDocumentoTrabajador(string Documento)
        {
            
            return new LogAgencia().ListarAgenciaByDocumentoTrabajador(Documento);

        }
    }
}
