﻿using ILogica.Seguridad;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using Modelos.Response;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using Utilitarios.JWT;

namespace Logica.Seguridad
{
    public class OperationAuthorizeTokenRepository : IOperationAuthorizeTokenRepository
    {
        public ClaimsPrincipal ValidateToken(string jwtToken)
        {
            IdentityModelEventSource.ShowPII = true;

            SecurityToken validatedToken;
            TokenValidationParameters validationParameters = new TokenValidationParameters();

            validationParameters.ValidateLifetime = true;

            validationParameters.IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtConfig.JwtSecret));

            ClaimsPrincipal principal = new JwtSecurityTokenHandler().ValidateToken(jwtToken, validationParameters, out validatedToken);


            return principal;
        }

        public bool attachAccountToContext(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(JwtConfig.JwtSecret);
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero,
                    LifetimeValidator = (DateTime? notBefore, DateTime? expires, SecurityToken securityToken,
                                     TokenValidationParameters validationParameters) =>
                    {
                        return notBefore <= DateTime.UtcNow &&
                               expires > DateTime.UtcNow;
                    }
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var accountId = jwtToken.Claims.First(x => x.Type == "IdUsuario").Value;
                return accountId != "" ? true : false;
            }
            catch
            {
                return false;
                // do nothing if jwt validation fails
                // account is not attached to context so request won't have access to secure routes
            }

        }
        public LoginResponse attachTenantToContext(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(JwtConfig.JwtSecret);
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero,
                    LifetimeValidator = (DateTime? notBefore, DateTime? expires, SecurityToken securityToken,
                                     TokenValidationParameters validationParameters) =>
                    {
                        return notBefore <= DateTime.UtcNow &&
                               expires > DateTime.UtcNow;
                    }
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var IdTrabajador = jwtToken.Claims.Where(x => x.Type == "IdTrabajador").Select(x => x.Value).FirstOrDefault();
                var IdUsuario = jwtToken.Claims.Where(x => x.Type == "IdUsuario").Select(x => x.Value).FirstOrDefault();
                var NombreUsuario = jwtToken.Claims.Where(x => x.Type == "NombreUsuario").Select(x => x.Value).FirstOrDefault();
                var IdPerfil = jwtToken.Claims.Where(x => x.Type == "IdPerfil").Select(x => x.Value).FirstOrDefault();
                var NombrePerfil = jwtToken.Claims.Where(x => x.Type == "NombrePerfil").Select(x => x.Value).FirstOrDefault();
                var IdAgencia = jwtToken.Claims.Where(x => x.Type == "IdAgencia").Select(x => x.Value).FirstOrDefault();
                var NombreAgencia = jwtToken.Claims.Where(x => x.Type == "NombreAgencia").Select(x => x.Value).FirstOrDefault();
                if (string.IsNullOrWhiteSpace(IdUsuario) || string.IsNullOrWhiteSpace(IdPerfil))
                    return new LoginResponse();
       
                return new LoginResponse()
                {
                    IdUsuario = int.Parse(IdUsuario),
                    Nombre_Completo = NombreUsuario,
                    Agencia = NombreAgencia,
                    Perfil = NombrePerfil,
                    IdPerfil = ConvertForce.toInt(IdPerfil),
                    IdAgencia = ConvertForce.toInt(IdAgencia),
                    IdTrabajador = ConvertForce.toInt(IdTrabajador),
                };
            }
            catch
            {
                return new LoginResponse();

                // do nothing if jwt validation fails
                // account is not attached to context so request won't have access to secure routes
            }

        }
    }
}
