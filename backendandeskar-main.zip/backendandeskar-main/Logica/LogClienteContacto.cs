﻿using Entidades;
using ILogica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Logica
{
    public class LogClienteContacto: IClienteContacto
    {
        public ClienteContactoEe ObtenerObjeto(int Id)
        {
            var nt = DapperSQL.Objeto<ClienteContactoEe>($"select * from ClienteContacto where IdClienteContacto={Id}");

            return nt;

        }
        public int ObtenerObjetoId(int Id)
        {
            var nt = DapperSQL.Objeto<int>($"select IdClienteContacto from ClienteContacto where IdClienteContacto={Id}");

            return nt;

        }
        public List<ClienteContactoEe> ListaObjeto(GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var nt = DapperSQL.Lista<ClienteContactoEe>($@"select * from ClienteContacto {(estado != GlobalEnum.Estado.Todos ? $" where Activo={(int)estado}" : "")}");

            return new List<ClienteContactoEe>(nt);

        }
        public List<ClienteContactoEe> ListaObjetoByIds(List<int> Ids)
        {
            var nt = DapperSQL.Lista<ClienteContactoEe>($"select * from ClienteContacto where IdClienteContacto in ({string.Join(",", Ids)})");

            return nt;

        }
        public int Insert(ClienteContactoEe obj)
        {
            string cadena = $@"INSERT INTO ClienteContacto
                               ( IdCliente,NumeroDocumento,NombreContacto,TelefonoContacto{GlobalConstant.AuditoriaInsertColumna})
                               VALUES(@IdCliente,@NumeroDocumento,@NombreContacto,@TelefonoContacto{GlobalConstant.AuditoriaInsertValues});
                               SELECT SCOPE_IDENTITY()
                               ";
            return DapperSQL.Execute_Int(cadena, obj);
        }
        public bool Update(List<ClienteContactoEe> obj)
        {
            StringBuilder cadena = new StringBuilder();
            obj.ForEach(x =>
            {
                if (x.IdClienteContacto == 0)
                {
                    cadena.Append($@"INSERT INTO ClienteContacto
                               ( IdCliente,NumeroDocumento,NombreContacto,TelefonoContacto,Activo,UsuarioCreacion,FechaCreacion)
                               VALUES({x.IdCliente},'{x.NumeroDocumento}','{x.NombreContacto}','{x.TelefonoContacto}',1,{x.UsuarioCreacion},getdate());
                               ");
                }
                else
                {
                    cadena.Append($@"UPDATE ClienteContacto
                               SET IdCliente={x.IdCliente},
                                   NumeroDocumento='{x.NumeroDocumento}',
                                   NombreContacto='{x.NombreContacto}',
                                   TelefonoContacto='{x.TelefonoContacto}'
                                   ,UsuarioUltimaModificacion = {x.UsuarioUltimaModificacion},FechaUltimaModificacion = getdate()
                               WHERE IdClienteContacto={x.IdClienteContacto};
                               select 1;");
                }

            });
            return DapperSQL.Execute_Int(cadena.ToString(), null) == 1;
        }
        public bool Delete(ClienteContactoEe obj)
        {
            string cadena = $@"UPDATE ClienteContacto
                                SET Activo = CASE 
                                             WHEN Activo = 1 THEN 0 
                                             ELSE 1 
                                             END
                                    {GlobalConstant.AuditoriaUpdate}
                                WHERE IdClienteContacto=@IdClienteContacto;
                               select 1;";
            return DapperSQL.Execute_Int(cadena, obj) == 1;
        }
        public List<ClienteContactoEe> ListarByIdCliente(int IdCliente, GlobalEnum.Estado estado = GlobalEnum.Estado.Activo)
        {
            var nt = DapperSQL.Lista<ClienteContactoEe>($@"select * from ClienteContacto where idcliente={IdCliente} {(estado != GlobalEnum.Estado.Todos ? $" and Activo={(int)estado}" : "")}");

            return new List<ClienteContactoEe>(nt);

        }
    }
}
