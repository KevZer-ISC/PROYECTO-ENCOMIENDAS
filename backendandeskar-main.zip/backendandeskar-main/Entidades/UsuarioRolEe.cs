﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class UsuarioRolEe
    {
        public int FK_usuario { get; set; }
        public int FK_rol { get; set; }
    }
}
