﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DocumentoReferenciaEe
    {
        public int idDocumento_Referencia { get; set; }
        public string Descripcion_DocumentoReferencia { get; set; }
    }
}
