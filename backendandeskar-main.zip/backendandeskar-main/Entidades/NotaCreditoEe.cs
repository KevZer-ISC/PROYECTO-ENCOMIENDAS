﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public   class NotaCreditoEe
    {
        public int idNotaCredito { get; set; }
        public int FK_Orden { get; set; }
        public int FK_Usuario { get; set; }
        public DateTime FechaRegistro { get; set; }
        public string Serie { get; set; }
        public string NumeroOrden { get; set; }
        public int FK_comprobante { get; set; }
    }
}
