﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TrayectoriaEe:AuditoriaEe
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int FK_Origen { get; set; }
        public int FK_Destino { get; set; }
        public int TotalTiempoAcumulado { get; set; }
        public int TotalOficinas { get; set; }
        public byte Orientacion_Id { get; set; }
    }
}
