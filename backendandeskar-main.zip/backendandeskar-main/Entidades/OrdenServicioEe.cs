﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class OrdenServicioEe
    {
        public int Id_Orden { get; set; }
        public string Serie { get; set; }
        public string Correlativo { get; set; }
        public int IdOrigen { get; set; }
        public int IdDestino { get; set; }
        public int IdTipoServicio { get; set; }
        public int? IdTipoRecepcion { get; set; }
        public int IdTipoEntrega { get; set; }
        public int? IdRemitente { get; set; }
        public int IdDestinatario { get; set; }
        public bool PersonaContacto { get; set; }
        public int IdPersonaContacto { get; set; }
        public string DireccionRecepcion { get; set; }
        public string DireccionEntrega { get; set; }
        public int IdFormaPago { get; set; }
        public int? IdResponsablePago { get; set; }
        public decimal? TotalUnidades { get; set; }
        public decimal? TotalPeso { get; set; }
        public decimal? TotalBulto { get; set; }
        public decimal? TotalVolumen { get; set; }
        public decimal TotalDescuento { get; set; }
        public decimal TotalImporte { get; set; }
        public decimal? IGV { get; set; }
        public decimal? SubTotal { get; set; }
        public DateTime FechaOrden { get; set; }
        public int? IdUsuario { get; set; }
        public int? IdEstado { get; set; }
        public bool? Anulado { get; set; }
        public DateTime? FechaAnulacion { get; set; }
        public int? IdUsuarioAnula { get; set; }
    }
}
