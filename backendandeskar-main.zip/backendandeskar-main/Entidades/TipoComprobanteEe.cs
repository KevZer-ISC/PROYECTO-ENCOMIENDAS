﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TipoComprobanteEe
    {
        public int IdTipoComprobante { get; set; }
        public string DescripcionTipoComprobante { get; set; }
        public string CodSunat { get; set; }
        public bool? Activo { get; set; }
        public DateTime? FechaCreacion { get; set; }
    }
}
