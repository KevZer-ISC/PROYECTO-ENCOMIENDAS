﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Entidades
{
    public class TrabajadorEe:AuditoriaEe
    {
        public int IdTrabajador { get; set; }
        public string Nombre_Completo { get; set; }
        public string Genero { get; set; }
        public int Estado { get; set; }
        public int TipoDocumento { get; set; }
        public string DocumentoIdentidad { get; set; }
        public string Clave { get; set; }
        public DateTime FechaContratacion { get; set; }
      
        /*Datos Complemetarios*/
        public string ClaveSinEncriptar { get { return Clave; } }
        public string ClaveEncriptada { get { return new Encriptacion().Encriptar(Clave); } }

    }
}
