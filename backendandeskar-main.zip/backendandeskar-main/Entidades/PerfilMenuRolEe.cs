﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PerfilMenuRolEe
    {
        public int IdMenu { get; set; }
        public int IdPerfil { get; set; }
        public string IdsRol { get; set; }
    }
}
