﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DetallePagoEe
    {
        public int id_DetallePago { get; set; }
        public int PK_OrdeServicio { get; set; }
        public int PK_Comprobante { get; set; }
        public DateTime FechaPago { get; set; }
        public int TipoPago { get; set; }
        public int TipoTarjeta { get; set; }
        public int MontoPagado { get; set; }
        public string Lote { get; set; }
        public string Digito { get; set; }
        public string Referencia { get; set; }
        public decimal Monto { get; set; }
    }
}
