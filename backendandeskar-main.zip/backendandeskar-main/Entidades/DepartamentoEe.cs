﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DepartamentoEe
    {
        public int IdDepartamento { get; set; }
        public string NombreDepartamento { get; set; }
    }
}
