﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Utilitarios.GlobalConstant;

namespace Entidades
{
    public class ClienteContactoEe : AuditoriaEe
    {
        public long IdClienteContacto { get; set; }
        [Alias(AliasCabecera)]
        public int IdCliente { get; set; }
        public string NumeroDocumento { get; set; }
        public string NombreContacto { get; set; }
        public string TelefonoContacto { get; set; }

    }
}
