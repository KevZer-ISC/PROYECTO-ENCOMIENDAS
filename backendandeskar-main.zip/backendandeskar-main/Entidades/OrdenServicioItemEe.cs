﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using static Utilitarios.GlobalConstant;

namespace Entidades
{
    public class OrdenServicioItemEe
    {
        public int id_Item { get; set; }
        [Alias(AliasCabecera)]
        public int FK_OrdenServicio { get; set; }
        public string Descripcion { get; set; }
        public int Estado { get; set; }
        public string Unidad { get; set; }
        public int Numero { get; set; }
        public double Peso { get; set; }
        public double Factor { get; set; }
        public double PrecioUnitario { get; set; }
        public double PrecioTotal { get; set; }
    }
}
