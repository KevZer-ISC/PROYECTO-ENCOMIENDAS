﻿namespace Entidades
{
    public class TipoDocumentoEe
    {
        public int idTipoDocumento { get; set; }
        public string Descripcion_TipoDocumento { get; set; }
        public string Tipo { get; set; }

    }
}