﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class FormaPagoEe:AuditoriaEe
    {
        public int IdFormaPago { get; set; }
        public string DescripcionFormaPago { get; set; }
        public bool? RemitenteJuridico { get; set; }
        public bool? ConsignadoJuridico { get; set; }
        public bool? RemitenteNatural { get; set; }
        public bool? ConsignadoNatural { get; set; }
        
    }
}
