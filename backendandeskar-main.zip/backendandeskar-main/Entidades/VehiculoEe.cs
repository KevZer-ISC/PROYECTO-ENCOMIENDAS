﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class VehiculoEe
    {
        public int Id_Vehiculo { get; set; }
        public bool FK_VehiculoTipo { get; set; }
        public int FK_Usuario { get; set; }
        public DateTime Fecha_Registro { get; set; }
        public int ejes { get; set; }
        public int Fecha_Inscripción { get; set; }
        public string Placa { get; set; }
        public string Serie_Vehiculo { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Estado { get; set; }
        public bool id_Estado_Vehiculo { get; set; }
        public int FK_Chofer { get; set; }
        public string Serie_Motor { get; set; }
    }
}
