﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Entidades
{
    public class UsuarioEe
    {
        public int IdUsuario { get; set; }
        public int FK_Trabajador { get; set; }
        public int FK_Agencia { get; set; }
        public int Fk_Perfil { get; set; }

    }
}
