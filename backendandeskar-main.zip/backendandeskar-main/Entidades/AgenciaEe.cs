﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class AgenciaEe:AuditoriaEe
    {
        public int IdAgencia { get; set; }
        public string NombreAgencia { get; set; }
        public string DireccionAgencia { get; set; }
        public string HorarioInicio { get; set; }
        public string HorarioTermino { get; set; }
        public int FK_EstadoAgencia { get; set; } 
    }
}
