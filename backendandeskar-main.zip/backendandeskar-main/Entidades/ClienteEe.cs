﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ClienteEe : AuditoriaEe
    {
        public int IdCliente { get; set; }
        public int? FK_Departamento { get; set; }
        public int? FK_TipoDocumento { get; set; }
        public int? FK_Sucursal { get; set; }
        public string Documento { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string NombreCompleto { get; set; }
        public string Direccion { get; set; }
        public string Ubigeo { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string Contacto { get; set; }
        public bool Credito { get; set; }
        public List<ClienteDireccionEe> Direcciones { get; set; }
        public List<ClienteContactoEe> Contactos{ get; set; }
    }
}
