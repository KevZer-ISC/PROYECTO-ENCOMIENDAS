﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RolEe
    {
        public int IdRol { get; set; }
        public string Rol { get; set; }
    }
}
