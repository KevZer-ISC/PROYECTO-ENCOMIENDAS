﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ComprobanteEe
    {
        public int Id_Comprobante { get; set; }
        public int FK_Orden { get; set; }
        public int FK_Cajero { get; set; }
        public DateTime FechaRegistro { get; set; }
        public string Serie { get; set; }
        public string Numero { get; set; }
    }
}
