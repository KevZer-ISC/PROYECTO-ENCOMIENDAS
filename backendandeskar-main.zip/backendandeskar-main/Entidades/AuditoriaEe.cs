﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class AuditoriaEe
    {
            public DateTime FechaCreacion { get; set; }
            public int UsuarioCreacion { get; set; }
            public DateTime? FechaUltimaModificacion { get; set; }
            public int UsuarioUltimaModificacion { get; set; }
            public bool Activo{ get; set; }
     }
}
