﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class OrdenServicioConsignadoEe
    {
        public int FK_OrdenServicio { get; set; }
        public int FK_Consignado { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int FK_Usuario { get; set; }
        public int Estado_Baja { get; set; }
    }
}
