﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProgramacionEe
    {
        public int Id_Programacion { get; set; }
        public DateTime Fecha_Registro { get; set; }
        public int FK_Usuario { get; set; }
        public bool FK_TipoProgramacion { get; set; }
        public DateTime FechaViaje { get; set; }
        public int FK_Piloto { get; set; }
        public int FK_Copiloto { get; set; }
        public int FK_Vehiculo { get; set; }
    }
}
