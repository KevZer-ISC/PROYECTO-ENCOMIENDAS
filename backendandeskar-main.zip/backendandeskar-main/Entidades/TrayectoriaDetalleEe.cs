﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Utilitarios.GlobalConstant;

namespace Entidades
{
    public class TrayectoriaDetalleEe:AuditoriaEe
    {
        public int Id { get; set; }
        [Alias(AliasCabecera)]
        public int Trayectoria_Id { get; set; }
        public int Orden { get; set; }
        public int PasaPor_IdSucursalVenta { get; set; }
        public int? TiempoLlegadaMinutos { get; set; }
        public int? TiempoEstibaDesestibaMinutos { get; set; }
        public int? TotalTiempoAcumulado { get; set; }
        public short TrayectoriaTipo_Id { get; set; }
    }
}
