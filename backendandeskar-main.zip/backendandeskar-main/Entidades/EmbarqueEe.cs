﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class EmbarqueEe
    {
        public int id_Embarque { get; set; }
        public int FK_Orden { get; set; }
        public int FK_Usuario { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int Ruta_Origen { get; set; }
        public int Ruta_Destino { get; set; }
        public bool FK_TipoProgramacion { get; set; }
        public int FK_Programacion { get; set; }
        public bool FK_Estado_Embarque { get; set; }
    }
}
