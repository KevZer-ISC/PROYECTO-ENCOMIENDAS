﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;
using static Utilitarios.GlobalConstant;

namespace Entidades
{
    public class ClienteDireccionEe : AuditoriaEe
    {
        public long IdClienteDireccion { get; set; }
        [Alias(AliasCabecera)]
        public int IdCliente { get; set; }
        public string Direccion { get; set; }
    }
}
