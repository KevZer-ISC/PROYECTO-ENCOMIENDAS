﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TipoVehiculoEe
    {
        public int Id_TipoVehiculo { get; set; }
        public string ConsumoCombustible { get; set; }
        public string Descripcion { get; set; }
    }
}
