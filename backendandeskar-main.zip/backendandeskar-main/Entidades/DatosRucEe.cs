﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DatosRucEe
    {
        public string razonSocial { get; set; }
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string estado { get; set; }
        public string condicion { get; set; }
        public string direccion { get; set; }
        public string ubigeo { get; set; }
        public string viaTipo { get; set; }
        public string viaNombre { get; set; }
        public string zonaCodigo { get; set; }
        public string zonaTipo { get; set; }
        public string numero { get; set; }
        public string interior { get; set; }
        public string lote { get; set; }
        public string dpto { get; set; }
        public string manzana { get; set; }
        public string kilometro { get; set; }
        public string distrito { get; set; }
        public string provincia { get; set; }
        public string departamento { get; set; }
        public bool EsAgenteRetencion { get; set; }
        public string tipo { get; set; }
        public string actividadEconomica { get; set; }
        public string numeroTrabajadores { get; set; }
        public string tipoFacturacion { get; set; }
        public string tipoContabilidad { get; set; }
        public string comercioExterior { get; set; }
    }
}
