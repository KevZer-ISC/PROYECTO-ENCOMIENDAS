﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class AgenciaTipoComprobanteEe
    {
        public int IdAgenciaComprobante { get; set; }
        public int? IdAgencia { get; set; }
        public int? IdTipoComprobante { get; set; }
        public string Serie { get; set; }
        public long Correlativo { get; set; }
        public bool? Activo { get; set; }
        public DateTime? FecCreacion { get; set; }
    }
}
