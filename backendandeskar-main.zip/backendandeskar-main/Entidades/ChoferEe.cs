﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ChoferEe:AuditoriaEe
    {
        public int ID_Chofer { get; set; }
        public int FK_Trabajador { get; set; }
        public string NumeroLicenciaConducir { get; set; }
        public DateTime FechaExpiracionLicencia { get; set; }
        public string TipoLicencia { get; set; }
        public string Estado { get; set; }
        public DateTime Horario { get; set; }
    }
}
