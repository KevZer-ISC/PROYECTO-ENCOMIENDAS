﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios
{
    public class GlobalExceptionValidate : Exception
    {
        public GlobalExceptionValidate(string message) : base(message)
        {

        }
    }
}
