﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios
{
    public static class GlobalConstant
    {
        public const string POLICY_PREFIX = "OperationAuthorize";
        public const string AliasCabecera = "IdPadre";
        public const string RucFullConsulta = "https://api.apis.net.pe/v2/sunat/ruc/full?numero=";
        public const string ReniecConsulta = "https://api.apis.net.pe/v2/reniec/dni?numero=";
        public const string TokenConsultas = "apis-token-9471.ZLNOuVk4NJ0kg6Hq0ce4vuXPyRgJOck1";
        #region Roles
        public const string RlInsertar = "Insertar";
        public const string RlActualizar = "Actualizar";
        public const string RlEliminar = "Eliminar";
        public const string RlVisualizar = "Visualizar";
        public const string RlAutorizar = "Autorizar";
        #endregion
        #region Menus
        public const string MnOperaciones = "Operaciones";
        public const string MnPersonal = "Personal";
        public const string MnNuevaOrden = "Nueva Orden";
        public const string MnOrdenServicio = "Orden Servicio";
        public const string MnGuiaTransportista = "Guia Transportista";
        public const string MnTrabajador = "Trabajador";
        #endregion
        #region Auditoria
        public const string AuditoriaUpdate = ",UsuarioUltimaModificacion = @UsuarioUltimaModificacion,FechaUltimaModificacion = @FechaUltimaModificacion";
        public const string AuditoriaInsertColumna = ",Activo,UsuarioCreacion,FechaCreacion";
        public const string AuditoriaInsertValues = ",@Activo,@UsuarioCreacion,@FechaCreacion";
        #endregion
        #region alias
        [AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = false)]
        public sealed class AliasAttribute : Attribute
        {
            public string Name { get; }
            public AliasAttribute(string name) => Name = name;
        }
        #endregion
    }
}
