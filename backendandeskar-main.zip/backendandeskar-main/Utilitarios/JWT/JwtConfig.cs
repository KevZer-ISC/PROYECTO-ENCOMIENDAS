﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios.JWT
{
    public static class JwtConfig
    {
        private static IConfiguration _config;
        public static void JwtConfigHelper(IConfiguration config)
        {
            _config = config;
        }
        public static string Repositorio { get { return _config.GetSection("Repositorio:Dominio").Value; } }
        public static string JwtSecret { get { return _config.GetSection("JwtConfig:Secret").Value; } }
        public static bool JwtRequireExpirationTime { get { return ConvertForce.toBoolean(_config.GetSection("JwtConfig:RequireExpirationTime").Value); } }
        public static bool JwtValidateIssuer { get { return ConvertForce.toBoolean(_config.GetSection("JwtConfig:ValidateIssuer").Value); } }
        public static bool JwtValidateAudience { get { return ConvertForce.toBoolean(_config.GetSection("JwtConfig:ValidateAudience").Value); } }
        public static bool JwtValidateLifetime { get { return ConvertForce.toBoolean(_config.GetSection("JwtConfig:ValidateLifetime").Value); } }

    }
}
