﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios
{
    public static class GlobalLogin
    {
        public static int IdUsuario { get; set; }
        public static int IdPerfil { get; set; }
        public static int IdAgencia { get; set; }
        public static int IdTrabajador { get; set; }
        public static void GlobalLoginCargar(int _IdUsuario, int _IdPerfil, int _IdAgencia, int _IdTrabajador)
        {
            IdUsuario = _IdUsuario;
            IdPerfil = _IdPerfil;
            IdAgencia = _IdAgencia;
            IdTrabajador = _IdTrabajador;

        }
    }

}
