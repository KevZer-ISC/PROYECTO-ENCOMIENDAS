﻿using FluentValidation.Results;

namespace Utilitarios.Exceptions
{
    public class TechnicalException : Exception
    {
        public int customCode { get; set; }
        public TechnicalException(ValidationResult value, int Status = -200) : base(value.Errors[0].ErrorMessage)
        {
            customCode = int.TryParse(value.Errors[0].ErrorCode, out int result) ? result : Status;
        }
        public TechnicalException(string message) : base(message)
        {
        }

        public TechnicalException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
