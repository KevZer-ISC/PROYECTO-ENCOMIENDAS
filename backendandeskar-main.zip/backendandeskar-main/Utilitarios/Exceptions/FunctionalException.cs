﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using FluentValidation.Results;

namespace Utilitarios.Exceptions
{
    public class FunctionalException : Exception
    {
        public int status { get; set; }
        public int customCode { get; set; }
        public FunctionalException(ValidationResult value, int Status = 412) : base(value.Errors[0].ErrorMessage)
        {
            customCode = int.TryParse(value.Errors[0].ErrorCode, out int result) ? result : Status;
        }
        public FunctionalException(int statusCode, string message) : base(message)
        {
            status = statusCode;
        }
        public FunctionalException(int statusCode, string message, int customCode) : base(message)
        {
            status = statusCode;
            this.customCode = customCode;
        }
        public FunctionalException(string message, int customCode) : base(message)
        {
            this.customCode = customCode;
        }
        public FunctionalException(string message) : base(message)
        {
        }
        public FunctionalException(string message, Exception innerException) : base(message, innerException)
        {
        }
        protected FunctionalException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
