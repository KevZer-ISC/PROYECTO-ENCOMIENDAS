﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios
{
    public class GlobalEnum
    {
        public enum Estado
        {
            Inactivo = 0,
            Activo = 1,
            Todos = 2

        }
        public enum TipoComprobante { 
        Ninguno=0,
        BE=1,
        FE=2,
        OS=3,
        }
        public enum TipoEntrega
        {
            Ninguno = 0,
            Agencia = 1,
            Delivery = 2,

        }
        public enum Orientacion { 
        Ninguno=0,
        Norte=1,
        Sur=2
        }
        public enum TrayectoriaTipo
        {
            Ninguno = 0,
            Inicial = 1,
            Intermedio = 2,
            Final = 3
        }
    }
}
