﻿namespace Utilitarios
{
    public class Base
    {
        public static string ConnectionString { get; set; }

    }
}