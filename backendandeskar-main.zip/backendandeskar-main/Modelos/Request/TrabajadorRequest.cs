﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class TrabajadorRequest:TrabajadorEe
    {
        public List< UsuarioEe> Usuarios { get; set; }
    }
}
