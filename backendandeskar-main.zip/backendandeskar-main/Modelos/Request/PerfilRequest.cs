﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class PerfilRequest : PerfilEe
    {
        public List<MenuRequest> ItemMenu { get; set; }

    }
}
