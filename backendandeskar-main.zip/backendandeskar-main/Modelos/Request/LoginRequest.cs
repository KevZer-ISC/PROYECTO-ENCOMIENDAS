﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class LoginRequest
    {
        public string Documento { get; set; }
        public string Contraseña{ get; set; }
        public int IdAgencia { get; set; }
    }
}
