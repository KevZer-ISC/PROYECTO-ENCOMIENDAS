﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class OrdenServicioRequest
    {
        public int Idorigen { get; set; }
        public int Iddestino { get; set; }
        public int Idtiposervicio { get; set; }
        public int IdTipoRecepcion { get; set; }
        public int IdtipoEntrega { get; set; }
        public int Idremitente { get; set; }
        public int Iddestinatario { get; set; }
        public bool Personacontacto { get; set; }
        public int IdpersonaContacto { get; set; }
        public string DireccionRecepcion { get; set; }
        public string DireccionEntrega { get; set; }
        public int IdformaPago { get; set; }
        public int IdresponsablePago { get; set; }
        public decimal TotalUnidades { get; set; }
        public decimal Totalpeso { get; set; }
        public decimal TotalBulto { get; set; }
        public decimal TotalVolumen { get; set; }
        public decimal Totaldescuento { get; set; }
        public decimal TotalImporte { get; set; }
        public decimal? IGV { get; set; }
        public decimal? SubTotal { get; set; }
        public DateTime FechaOrden { get; set; }
        public int IdUsuario { get; set; }
    }
}
