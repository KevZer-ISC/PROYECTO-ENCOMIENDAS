﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class ClienteRequest
    {
        public int Id { get; set; }
        public string Documento { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string RazonSocial { get; set; }
        public int Departamento { get; set; }
        public string Direccion { get; set; }
        public string Ubigeo { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public int Oficina { get; set; }
        public string Contacto { get; set; }
        public bool Credito { get; set; }
        public int TipoDocumento { get; set; }
        public List<DireccionesClienteRequest> Direcciones { get; set; }
        public List<ContactosClienteRequest> Contactos { get; set; }
    }

}
