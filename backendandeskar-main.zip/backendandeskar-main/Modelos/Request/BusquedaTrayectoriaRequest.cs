﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Modelos.Request
{
    public class BusquedaTrayectoriaRequest
    {
        public int IdOrigen { get; set; }
        public int IdDestino { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;
        public GlobalEnum.Estado estado { get; set; } = GlobalEnum.Estado.Activo;
    }
}
