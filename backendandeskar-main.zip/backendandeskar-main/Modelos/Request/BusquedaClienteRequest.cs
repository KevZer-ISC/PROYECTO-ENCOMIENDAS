﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Modelos.Request
{
    public class BusquedaClienteRequest
    {
        public int IdTipoDocumento { get; set; }
        public string Documento { get; set; }
        public GlobalEnum.Estado estado { get; set; } = GlobalEnum.Estado.Activo;
    }
}
