﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class DireccionesClienteRequest
    {
        public int IdDireccion { get; set; }
        public int IdCliente { get; set; }
        public string Direccion { get; set; }

    }
}
