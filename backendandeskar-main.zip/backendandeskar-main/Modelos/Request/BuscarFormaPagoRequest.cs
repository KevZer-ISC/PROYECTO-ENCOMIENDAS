﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class BuscarFormaPagoRequest
    {
    public int IdCliente { get; set; }
        public string Pagador { get; set; }
    }
}
