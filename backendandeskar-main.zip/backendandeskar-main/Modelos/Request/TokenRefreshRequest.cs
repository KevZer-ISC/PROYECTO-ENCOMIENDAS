﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class TokenRefreshRequest
    {
        [JsonIgnore]
        public int UsuarioId { get; set; }
        public string RefreshToken { get; set; }
    }
}
