﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Request
{
    public class MenuRequest : MenuEe
    {
        public List<RolEe> ItemRol { get; set; } = new List<RolEe>();

    }
}
