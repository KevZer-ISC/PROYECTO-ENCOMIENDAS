﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Response
{
    public class ClienteResponse
    {
        public int Id { get; set; }
 
        public DepartamentoEe Departamento { get; set; }
        public TipoDocumentoEe TipoDocumento { get; set; }
        public string Documento { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string NombreCompleto { get; set; }
        public string Ubigeo { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string Contacto { get; set; }
        public string Direccion { get; set; }
        public bool Credito { get; set; }
        public bool Activo { get; set; }


    }
}
