﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Response
{
    public class MenuResponse : MenuEe
    {
        public MenuEe Padre { get; set; }
        public List<MenuResponse> items { get; set; }
    }
}
