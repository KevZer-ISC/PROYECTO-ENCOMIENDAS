﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Response
{
    public class MenuRolResponse : MenuEe
    {
        public List<MenuRolResponse> Items { get; set; }
        public List<RolEe> Roles { get; set; }
    }
}
