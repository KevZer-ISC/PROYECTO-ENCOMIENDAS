﻿using Entidades;
using Modelos.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Response
{
    public class ClienteNoDeseadoResponse:ClienteNoDeseadoRequest
    {
        public bool Activo { get; set; }
        public TipoDocumentoEe TipoDocumento { get; set; }
    }
}
