﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios;

namespace Modelos.Response
{
    public class TrayectoriaResponse
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public ComunResponse Origen { get; set; }
        public ComunResponse Destino { get; set; }
        public int TotalTiempoAcumulado { get; set; }
        public int TotalOficinas { get; set; }
        public GlobalEnum.Orientacion Orientacion { get; set; }
        public List<TrayectoriaDetalleResponse> Detalle { get; set; }
    }
    public class TrayectoriaDetalleResponse
    {
        public int Id { get; set; }
        public int Orden { get; set; }
        public ComunResponse PasaPorIdSucursalVenta { get; set; } = new ComunResponse();
        public string? TiempoLlegada { get; set; }
        public string? TiempoEstibaDesestiba { get; set; }
        public int? TotalTiempoAcumulado { get; set; }
        public GlobalEnum.TrayectoriaTipo TrayectoriaTipo { get; set; }
    }
}
