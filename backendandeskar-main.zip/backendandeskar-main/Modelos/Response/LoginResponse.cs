﻿using Entidades;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Response
{
    public class LoginResponse
    {
        public int IdUsuario { get; set; }
        
        public int? IdPerfil { get; set; }
        public int? IdAgencia { get; set; }
        public int? IdTrabajador { get; set; }
        public string Nombre_Completo { get; set; }
        public string Genero { get; set; }
        public string DocumentoIdentidad { get; set; }
        public string Agencia { get; set; }
        public string Perfil { get; set; }
        public string Token { get; set; }
        public string RefreshToken { get; set; }
    }

}
